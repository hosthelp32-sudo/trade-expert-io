package com.tradeexpert.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * The bot console card, as in the videos: the bot picture fills the top with the name and the
 * account status over it, a scanline texture, a drag grip and a close button. Below it the console
 * lines are typed out letter by letter, under a red section label. A chart scanner signal adds its
 * execution and the reason ("why") to the same lines. The footer has "Powered by TradeExpert" and
 * the stop and clear buttons. The colour follows the app's accent colour and cycles.
 */
class ConsoleCard {

    static final int DEFAULT_ACCENT = 0xFF10B981;   // the web app's default colour
    static final int FRAME = DEFAULT_ACCENT;         // the bubble ring uses this too
    static final int BODY = 0xFF07090D;
    static final int BTN = 0xFF141820;
    static final int BTN_EDGE = 0xFF3A3F4A;

    private static final int SPAN = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE;

    /** One console line. A section label (sep) is written at once. */
    private static final class Row {
        String text;
        final boolean sep;
        int shown;
        TextView view;

        Row(String text, boolean sep) {
            this.text = text;
            this.sep = sep;
            this.shown = sep ? text.length() : 0;
        }
    }

    /** Three small dots at the top corner: the card's drag grip. */
    private static final class GripView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;

        GripView(Context c, float d) {
            super(c);
            this.d = d;
            p.setColor(FRAME);
        }

        void setColour(int c) {
            p.setColor(c);
            invalidate();
        }

        @Override
        protected void onDraw(Canvas cv) {
            float r = 1.6f * d, gap = 5f * d;
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    cv.drawCircle(r + col * gap, r + row * gap, r, p);
                }
            }
        }
    }

    /** Faint horizontal scanlines over the picture. */
    private static final class ScanView extends View {
        private final Paint p = new Paint();
        private final float step;

        ScanView(Context c, float d) {
            super(c);
            step = 3f * d;
            p.setColor(0x14FFFFFF);
            p.setStrokeWidth(Math.max(1f, d * 0.5f));
        }

        @Override
        protected void onDraw(Canvas cv) {
            for (float y = 0; y < getHeight(); y += step) {
                cv.drawLine(0, y, getWidth(), y, p);
            }
        }
    }

    final FrameLayout root;
    /** The picture at the top: drag the card by it. */
    final View header;
    private final Context ctx;
    private final float d;
    private final LinearLayout content;
    private final TextView nameTv, statusTv, stopBtn, poweredTv;
    private final ImageView picture;
    private final GradientDrawable frameBg, closeRing;
    private final GripView grip;
    private final ScrollView logScroll;
    private final LinearLayout logBox;
    private final Handler main = new Handler(Looper.getMainLooper());
    /** The rows on the card, in order: the bot's lines, then the chart scanner's. */
    private final List<Row> rows = new ArrayList<>();
    private final List<Row> botRows = new ArrayList<>();
    private final List<Row> scanRows = new ArrayList<>();
    private boolean typingScheduled = false;
    private String lastImg = "";
    private Bitmap shownBitmap = null;
    private boolean lastRunning = false;
    private boolean dismissed = false;
    /** The accent parts of the card (corner brackets and the divider) that follow the colour. */
    private final List<View> accents = new ArrayList<>();

    // the app's colours: accent, secondary (0 = none) and cycle speed
    private int accent = DEFAULT_ACCENT;
    private int secondary = 0;
    private float speed = 0.3f;
    private boolean cycling = false;

    private final Runnable cycler = new Runnable() {
        @Override
        public void run() {
            double t = (Math.sin(SystemClock.uptimeMillis() / 1000.0 * 2 * Math.PI * speed) + 1) / 2;
            setTint(mix(accent, otherColour(), (float) t));
            main.postDelayed(this, 50);
        }
    };

    ConsoleCard(Context c, Runnable onClose) {
        ctx = c;
        d = c.getResources().getDisplayMetrics().density;

        content = new LinearLayout(c);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setClipToOutline(true);
        content.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        frameBg = box(BODY, dp(12), FRAME, dp(2));
        content.setBackground(frameBg);

        // top: the bot picture fills it; the name and status sit over its lower edge
        FrameLayout pic = new FrameLayout(c);
        pic.setBackgroundColor(0xFF05090F);
        header = pic;
        picture = new ImageView(c);
        picture.setScaleType(ImageView.ScaleType.CENTER_CROP);
        picture.setImageResource(R.drawable.app_logo);
        pic.addView(picture, new FrameLayout.LayoutParams(-1, -1));

        View shade = new View(c);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x00070910, 0xE6070910, BODY}));
        pic.addView(shade, new FrameLayout.LayoutParams(-1, dp(130), Gravity.BOTTOM));
        pic.addView(new ScanView(c, d), new FrameLayout.LayoutParams(-1, -1));

        LinearLayout info = new LinearLayout(c);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(14), 0, dp(14), dp(12));
        nameTv = text("BOT", 22, 0xFFFFFFFF, true);
        nameTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        nameTv.setSingleLine(true);
        nameTv.setEllipsize(TextUtils.TruncateAt.END);
        info.addView(nameTv);
        statusTv = text("● ACCOUNT CONNECTED", 11, FRAME, true);
        statusTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        statusTv.setLetterSpacing(0.06f);
        info.addView(statusTv);
        pic.addView(info, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        grip = new GripView(c, d);
        FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(dp(16), dp(16), Gravity.TOP | Gravity.START);
        gp.setMargins(dp(12), dp(12), 0, 0);
        pic.addView(grip, gp);

        closeRing = box(0xAA000000, dp(15), FRAME, dp(1));
        TextView close = text("✕", 12, 0xFFFFFFFF, true);
        close.setGravity(Gravity.CENTER);
        close.setBackground(closeRing);
        close.setOnClickListener(v -> onClose.run());
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.TOP | Gravity.END);
        cp.setMargins(0, dp(10), dp(10), 0);
        pic.addView(close, cp);
        content.addView(pic, new LinearLayout.LayoutParams(-1, dp(190)));

        // a thin accent line under the picture
        View divider = new View(c);
        accents.add(divider);
        content.addView(divider, new LinearLayout.LayoutParams(-1, dp(2)));

        // the console: black panel with the section label and the typed lines
        LinearLayout panel = new LinearLayout(c);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xFF000000);
        panel.setPadding(dp(14), dp(10), dp(14), dp(8));
        logBox = new LinearLayout(c);
        logBox.setOrientation(LinearLayout.VERTICAL);
        logScroll = new ScrollView(c);
        logScroll.setVerticalScrollBarEnabled(false);
        logScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        logScroll.addView(logBox, new FrameLayout.LayoutParams(-1, -2));
        panel.addView(logScroll, new LinearLayout.LayoutParams(-1, dp(130)));
        content.addView(panel, new LinearLayout.LayoutParams(-1, -2));

        // footer: "Powered by TradeExpert" (clear), stop and clear buttons
        LinearLayout footer = new LinearLayout(c);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.setBackgroundColor(0xFF0B0E14);
        footer.setPadding(dp(14), dp(6), dp(8), dp(8));
        poweredTv = text("Powered by TradeExpert", 11, 0xFFFFFFFF, true);
        poweredTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        footer.addView(poweredTv, new LinearLayout.LayoutParams(0, -2, 1f));
        stopBtn = iconButton("▢", "toggle");
        footer.addView(stopBtn, buttonParams(0));
        footer.addView(clearButton(), buttonParams(6));
        content.addView(footer, new LinearLayout.LayoutParams(-1, -2));

        root = new FrameLayout(c);
        root.addView(content, new FrameLayout.LayoutParams(-1, -2));
        // corner brackets around the card
        bracket(Gravity.TOP | Gravity.START);
        bracket(Gravity.TOP | Gravity.END);
        bracket(Gravity.BOTTOM | Gravity.START);
        bracket(Gravity.BOTTOM | Gravity.END);
        setTint(FRAME);
    }

    /** Stop the colour cycle (the card is being removed). */
    void stop() {
        cycling = false;
        main.removeCallbacks(cycler);
    }

    /** The bot picture arrived (or changed): show it on the card. */
    void refreshPicture() {
        Bitmap bm = BotPicture.bitmap;
        if (bm != null && bm != shownBitmap) {
            shownBitmap = bm;
            picture.setImageBitmap(bm);
        }
    }

    /**
     * Fill the card from the web data: the name, the picture and the colour, and the bot's lines
     * while the bot runs. The page's own console is not used.
     */
    void update(String json) {
        try {
            JSONObject o = new JSONObject(json);
            String name = o.optString("name", "");
            nameTv.setText(name.isEmpty() ? "BOT" : name.toUpperCase());
            boolean running = o.optBoolean("running", false);
            stopBtn.setText(running ? "▢" : "▷");
            statusTv.setText(running ? "● ACCOUNT CONNECTED" : "○ STANDBY");
            if (BotPicture.bitmap != null) refreshPicture();
            else loadImage(o.optString("img", ""));
            setAccent(o.optString("accent", ""), o.optString("secondary", ""), (float) o.optDouble("speed", 0.3));

            if (running != lastRunning) {
                lastRunning = running;
                dismissed = false;
            }
            botRows.clear();
            if (running && !dismissed) {
                String bot = name.isEmpty() ? "BOT" : name;
                botRows.add(new Row("Bot console", true));
                botRows.add(new Row(bot + " is connected", false));
                botRows.add(new Row("Servers online and EA is active", false));
                botRows.add(new Row("Waiting for a new live signal...", false));
            }
            sync();
        } catch (Exception ignored) {
        }
    }

    /**
     * A chart scanner signal: the card writes the execution (BUY or SELL, the symbol), the levels
     * and the reason ("why") on the console, typed out as the video shows.
     */
    void showScan(JSONObject r) {
        String sig = r.optString("signal", "").toUpperCase();
        if (sig.isEmpty()) return;
        dropScanRows();
        String sym = r.optString("symbol", "").toUpperCase();
        scanRows.add(new Row("Chart scanner", true));
        scanRows.add(new Row("Executing " + sig + (sym.isEmpty() ? "" : " " + sym), false));
        scanRows.add(new Row("Entry " + r.optString("entry", "-")
                + " · SL " + r.optString("stopLoss", "-")
                + " · TP " + r.optString("takeProfit", "-"), false));
        String why = r.optString("analysis", "");
        if (why.isEmpty()) why = r.optString("reason", "");
        why = why.trim().replaceAll("\\s+", " ");
        if (why.length() > 260) why = why.substring(0, 257) + "...";
        if (!why.isEmpty()) scanRows.add(new Row("Why: " + why, false));
        sync();
    }

    /** Make the list on the card match the bot's lines and the scanner's lines. */
    private void sync() {
        List<Row> incoming = new ArrayList<>(botRows);
        incoming.addAll(scanRows);

        // a line still being written grows in place and keeps its typed letters
        int same = 0;
        while (same < rows.size() && same < incoming.size()) {
            Row have = rows.get(same);
            Row want = incoming.get(same);
            if (have.sep != want.sep) break;
            if (have.text.equals(want.text)) {
                same++;
            } else if (!have.sep && want.text.startsWith(have.text)) {
                have.text = want.text;
                same++;
            } else {
                break;
            }
        }
        while (rows.size() > same) {
            Row r = rows.remove(rows.size() - 1);
            if (r.view != null) logBox.removeView(r.view);
            r.view = null;
        }
        for (int i = same; i < incoming.size(); i++) {
            Row r = incoming.get(i);
            r.view = makeView(r);
            logBox.addView(r.view, new LinearLayout.LayoutParams(-1, -2));
            rows.add(r);
        }
        scheduleTyping();
        logScroll.fullScroll(View.FOCUS_DOWN);
    }

    /** Take the scanner's lines off the card (a new signal writes them again from the start). */
    private void dropScanRows() {
        for (Row r : scanRows) {
            rows.remove(r);
            if (r.view != null) logBox.removeView(r.view);
            r.view = null;
        }
        scanRows.clear();
    }

    /** Take the app's colours. A change repaints the lines; the frame keeps cycling. */
    private void setAccent(String accentHex, String secondaryHex, float sp) {
        int a = parse(accentHex, DEFAULT_ACCENT);
        int s = parse(secondaryHex, 0);
        float newSpeed = sp > 0 ? Math.min(sp, 3f) : 0.3f;
        boolean changed = a != accent || s != secondary;
        accent = a;
        secondary = s;
        speed = newSpeed;
        BubbleService.setRingColours(accent, otherColour());
        if (changed) repaintAll();
        if (!cycling) {
            cycling = true;
            main.post(cycler);
        }
    }

    /** The second colour of the cycle: the app's secondary colour, or a light tint of the accent. */
    private int otherColour() {
        return secondary != 0 ? secondary : mix(accent, 0xFFFFFFFF, 0.45f);
    }

    /** The corner bracket: an L of two thin bars at one corner. */
    private void bracket(int gravity) {
        int len = dp(16), t = dp(2), m = dp(4);
        boolean top = (gravity & Gravity.TOP) != 0;
        boolean start = (gravity & Gravity.START) != 0;
        View h = new View(ctx);
        View v = new View(ctx);
        accents.add(h);
        accents.add(v);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(len, t, gravity);
        FrameLayout.LayoutParams vp = new FrameLayout.LayoutParams(t, len, gravity);
        hp.setMargins(start ? m : 0, top ? m : 0, start ? 0 : m, top ? 0 : m);
        vp.setMargins(start ? m : 0, top ? m : 0, start ? 0 : m, top ? 0 : m);
        root.addView(h, hp);
        root.addView(v, vp);
    }

    /** Paint the frame, the grip, the close ring, the status and the accent parts in one colour. */
    private void setTint(int c) {
        frameBg.setStroke(dp(2), c);
        closeRing.setStroke(dp(1), c);
        statusTv.setTextColor(c);
        grip.setColour(c);
        for (View v : accents) v.setBackgroundColor(c);
    }

    private void repaintAll() {
        for (Row r : rows) {
            if (r.view != null) paint(r, (TextView) r.view);
        }
    }

    private TextView makeView(Row r) {
        TextView t = new TextView(ctx);
        t.setTextSize(12);
        t.setTypeface(Typeface.MONOSPACE);
        t.setLineSpacing(0, 1.15f);
        t.setPadding(0, dp(2), 0, dp(2));
        if (r.sep) {
            t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            t.setLetterSpacing(0.12f);
            t.setTextSize(11);
            t.setPadding(0, dp(6), 0, dp(3));
        }
        paint(r, t);
        return t;
    }

    /** Write the typed part of the line: ">> " in the accent colour, then the text. */
    private void paint(Row r, TextView t) {
        int n = Math.min(r.shown, r.text.length());
        boolean typing = n < r.text.length();
        SpannableStringBuilder sb = new SpannableStringBuilder();
        if (r.sep) {
            sb.append(r.text.toUpperCase());
            sb.setSpan(new ForegroundColorSpan(accent), 0, sb.length(), SPAN);
        } else {
            sb.append(">> ");
            sb.setSpan(new ForegroundColorSpan(accent), 0, 2, SPAN);
            sb.setSpan(new StyleSpan(Typeface.BOLD), 0, 2, SPAN);
            int start = sb.length();
            sb.append(r.text, 0, n);
            sb.setSpan(new ForegroundColorSpan(mix(accent, 0xFFFFFFFF, 0.25f)), start, sb.length(), SPAN);
            if (typing) {
                sb.append("▌");
                sb.setSpan(new ForegroundColorSpan(accent), sb.length() - 1, sb.length(), SPAN);
            }
        }
        t.setText(sb);
    }

    private void scheduleTyping() {
        if (typingScheduled) return;
        typingScheduled = true;
        main.post(typer);
    }

    /** Types the lines letter by letter, a few letters per frame, so the card never freezes. */
    private final Runnable typer = new Runnable() {
        @Override
        public void run() {
            Row cur = null;
            int pending = 0;
            for (Row r : rows) {
                if (r.shown >= r.text.length()) continue;
                if (cur == null) cur = r;
                pending += r.text.length() - r.shown;
            }
            if (cur == null || cur.view == null) {
                typingScheduled = false;
                return;
            }
            int step = pending > 300 ? 12 : pending > 120 ? 6 : 3;
            cur.shown = Math.min(cur.text.length(), cur.shown + step);
            paint(cur, (TextView) cur.view);
            logScroll.fullScroll(View.FOCUS_DOWN);
            main.postDelayed(this, 16);
        }
    };

    /** Clear the card's lines until the bot is switched off and on again. */
    private void clearLines() {
        dismissed = true;
        botRows.clear();
        dropScanRows();
        for (Row r : rows) {
            if (r.view != null) logBox.removeView(r.view);
        }
        rows.clear();
    }

    private void loadImage(String img) {
        if (img == null || img.isEmpty() || img.equals(lastImg)) return;
        lastImg = img;
        if (img.startsWith("data:image")) {
            try {
                byte[] b = android.util.Base64.decode(img.substring(img.indexOf(',') + 1), android.util.Base64.DEFAULT);
                picture.setImageBitmap(BitmapFactory.decodeByteArray(b, 0, b.length));
            } catch (Exception ignored) {
            }
            return;
        }
        if (!img.startsWith("http")) return;
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(img).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                try (InputStream in = c.getInputStream()) {
                    Bitmap bm = BitmapFactory.decodeStream(in);
                    if (bm != null) main.post(() -> picture.setImageBitmap(bm));
                }
            } catch (Exception ignored) {
            }
        }).start();
    }

    private static int parse(String hex, int fallback) {
        try {
            return Color.parseColor(hex);
        } catch (Exception e) {
            return fallback;
        }
    }

    /** Colour a (0 = first, 1 = second). */
    static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private TextView iconButton(final String label, final String which) {
        TextView b = text(label, 13, 0xFFEDEDED, false);
        b.setGravity(Gravity.CENTER);
        b.setBackground(box(BTN, dp(7), BTN_EDGE, dp(1)));
        b.setOnClickListener(v -> PageHost.clickButton(which));
        return b;
    }

    private TextView clearButton() {
        TextView b = text("🗑", 13, 0xFFEDEDED, false);
        b.setGravity(Gravity.CENTER);
        b.setBackground(box(BTN, dp(7), BTN_EDGE, dp(1)));
        b.setOnClickListener(v -> clearLines());
        return b;
    }

    private LinearLayout.LayoutParams buttonParams(int leftDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(30), dp(30));
        lp.leftMargin = dp(leftDp);
        return lp;
    }

    private int dp(float v) {
        return (int) (v * d + 0.5f);
    }

    private GradientDrawable box(int fill, int radiusPx, int stroke, int strokePx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radiusPx);
        if (stroke != 0) g.setStroke(strokePx, stroke);
        return g;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }
}
