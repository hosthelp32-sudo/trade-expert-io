(function () {
  if (window.__teBridge) return;
  window.__teBridge = true;

  // the web app's own console and floating bubble are not shown in the app: the app's pop-out console is used
  try {
    var hideWeb = document.createElement('style');
    // the web console window, and the gold bubble that opens it (fixed, bottom 80 / right 16)
    hideWeb.textContent = '[aria-label="Bot console"],.fixed[style*="bottom: 80px"][style*="right: 16px"]{display:none!important}';
    (document.head || document.documentElement).appendChild(hideWeb);
  } catch (e) {}

  // Report a trade to the app (the pop-out console writes it): placed or not, and why not.
  function readReply(res) {
    return res.clone().json().catch(function () { return null; });
  }
  var announced = {};
  var lastScan = null;
  function cleanWhy(t) {
    return String(t || '').replace(/\s+/g, ' ').trim().slice(0, 240);
  }
  function whyFor(sig) {
    if (!lastScan) return '';
    return lastScan.signal === String(sig.direction || '').toUpperCase() ? lastScan.why : '';
  }
  function sigOf(row) {
    return { symbol: row.symbol, direction: row.direction, stopLoss: row.stop_loss, takeProfit: row.take_profit };
  }
  // A signal arrived (website, chart scanner or self-host): the console opens and writes it at once
  function signalReceived(sig, id) {
    if (id) {
      if (announced[id]) return;
      announced[id] = 1;
    }
    try {
      AndroidNotify.signalReceived(JSON.stringify({
        phase: 'received', symbol: String(sig.symbol || ''), direction: String(sig.direction || '').toUpperCase(),
        stopLoss: sig.stopLoss, takeProfit: sig.takeProfit, why: sig.why || ''
      }));
    } catch (e) {}
  }
  function sendReport(ok, sig, placed, message) {
    try {
      AndroidNotify.tradeExecuted(JSON.stringify({
        ok: !!ok, symbol: String(sig.symbol || ''), direction: String(sig.direction || '').toUpperCase(),
        stopLoss: sig.stopLoss, takeProfit: sig.takeProfit, placed: Number(placed) || 0, why: sig.why || '',
        message: ok ? '' : String(message || 'Trade not placed')
      }));
    } catch (e) {}
  }

  // 0) The chart scanner's result: when it found a signal, send it to the app (the signal card shows the why)
  var _fetch = window.fetch;
  if (_fetch) {
    window.fetch = function (input, init) {
      var p = _fetch.apply(this, arguments);
      try {
        var url = typeof input === 'string' ? input : (input && input.url) || '';
        // the chart scanner's EXECUTE TRADE: placed or not (with the reason), reported to the console
        if (url.indexOf('/functions/v1/copy-trade') > -1 && init && typeof init.body === 'string') {
          var sent = null;
          try { sent = JSON.parse(init.body); } catch (e) {}
          if (sent && sent.action === 'open' && sent.source === 'ai_scanner') {
            sent.why = whyFor(sent);
            signalReceived(sent);
            p.then(readReply).then(function (j) {
              var placed = Number(j && j.result && j.result.placed) || 0;
              var ok = !!j && j.success !== false && placed > 0;
              sendReport(ok, sent, placed, j && (j.error || j.message));
            }).catch(function () {});
          }
        }
        // a signal from the website (dispatched to the account): placed or not, reported to the console
        if (url.indexOf('/functions/v1/dispatch-signal') > -1 && init && typeof init.body === 'string') {
          var want = null;
          try { want = JSON.parse(init.body); } catch (e) {}
          if (want && want.signal_id) {
            signalById(want.signal_id).then(function (row) {
              if (row) signalReceived(sigOf(row), want.signal_id);
            });
            p.then(readReply).then(function (j) {
              var placed = Number(j && j.placed) || 0;
              return signalById(want.signal_id).then(function (row) {
                if (!row) return;
                sendReport(placed > 0, sigOf(row), placed, j && (j.error || j.message));
              });
            }).catch(function () {});
          }
        }
        // the chart scanner's result: keep its signal and reason, for the trade that follows
        if (url.indexOf('/functions/v1/scan-chart') > -1) {
          p.then(readReply).then(function (j) {
            var r = j && j.result;
            if (r && r.ok && (r.signal === 'BUY' || r.signal === 'SELL')) {
              lastScan = { signal: String(r.signal).toUpperCase(), why: cleanWhy(r.analysis || r.reason || '') };
            }
          }).catch(function () {});
        }
      } catch (e) {}
      return p;
    };
  }

  // 1) The web app's bot switch: the page saves "1" (ON) or "0" (OFF) in ea_bot_running.
  var lastOn = null;
  function checkBot() {
    var on = false;
    try { on = localStorage.getItem('ea_bot_running') === '1'; } catch (e) {}
    if (on === lastOn) return;
    lastOn = on;
    try { AndroidNotify.botState(on); } catch (e) {}
  }

  // 2) The web console: its name, picture and lines (the same lines and order as on the page).
  var lastConsole = '', lastOpenTry = 0;
  function botInfo() {
    try {
      var bots = JSON.parse(localStorage.getItem('ea_bots') || '[]');
      var b = bots[parseInt(localStorage.getItem('ea_active_bot') || '0', 10) || 0] || {};
      var ea = b.ea || {};
      var img = ea.image_url || ea.image || ea.logo_url || ea.picture || ea.img || b.image_url || b.img || b.picture || '';
      return { name: String(ea.name || b.name || 'BOT'), img: String(img || '') };
    } catch (e) { return { name: 'BOT', img: '' }; }
  }
  function pageImage() {
    var ims = document.querySelectorAll('img.object-cover');
    for (var i = 0; i < ims.length; i++) {
      var src = String(ims[i].src || '');
      if (src && src.indexOf('data:') !== 0 && ims[i].width > 120) return src;
    }
    return '';
  }
  function reportConsole() {
    try {
      var info = botInfo();
      if (!info.img) info.img = pageImage();
      // the app's colour (the card and the bubble follow it), and its colour speed
      var accent = '', secondary = '', speed = 0.3;
      try {
        accent = localStorage.getItem('ea_accent_color') || '';
        var sec = localStorage.getItem('ea_accent_secondary');
        secondary = (sec && sec !== 'null') ? sec : '';
        speed = parseFloat(localStorage.getItem('ea_color_speed')) || 0.3;
      } catch (e) {}
      var data = JSON.stringify({ name: info.name, img: info.img, running: lastOn === true,
                                  accent: accent, secondary: secondary, speed: speed,
                                  account: accountOn === true });
      if (data !== lastConsole) {
        // sent as the page writes it: the card types the same letters, one by one
        lastConsole = data;
        AndroidNotify.consoleData(data);
      }
    } catch (e) {}
  }


  // 3) New signals: a notification for each signal created after the page opened
  var REST = 'https://zueqlxkqwigjlpgazeiz.supabase.co/rest/v1/';
  var ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp1ZXFseGtxd2lnamxwZ2F6ZWl6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI5NTU1MTgsImV4cCI6MjA4ODUzMTUxOH0.ZH9u7B90bndQVe_VT5cxmU1XCHL-yqfiBhtHn0T3ZfE';
  var seen = {}, since = new Date().toISOString(), firstRun = true;
  var accountOn = null;
  function session() {
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (k && k.indexOf('auth-token') > -1) {
          var o = JSON.parse(localStorage.getItem(k));
          var t = o.access_token || (o.currentSession && o.currentSession.access_token);
          var u = (o.user && o.user.id) || (o.currentSession && o.currentSession.user && o.currentSession.user.id);
          if (t && u) return { token: t, uid: u };
        }
      }
    } catch (e) {}
    return null;
  }
  // the signal's symbol, direction and levels (by id), for the console report
  function signalById(id) {
    var s = session();
    if (!s) return Promise.resolve(null);
    return fetch(REST + 'signals?select=id,symbol,direction,take_profit,stop_loss&id=eq.' + encodeURIComponent(id),
          { headers: { apikey: ANON, Authorization: 'Bearer ' + s.token } })
      .then(function (r) { return r.ok ? r.json() : []; })
      .then(function (rows) { return Array.isArray(rows) && rows[0] ? rows[0] : null; })
      .catch(function () { return null; });
  }
  function activeEa() {
    try {
      var bots = JSON.parse(localStorage.getItem('ea_bots') || '[]');
      var b = bots[parseInt(localStorage.getItem('ea_active_bot') || '0', 10) || 0];
      return (b && (b.ea_id || (b.ea && b.ea.id))) || '';
    } catch (e) { return ''; }
  }
  // The newest signals for the active bot, by the server's own clock (the phone's clock is not used).
  // The first check only remembers what is already there; after that each new signal is announced once.
  // every bot the user has activated (the web app checks them all the same way)
  function botEaIds() {
    try {
      var bots = JSON.parse(localStorage.getItem('ea_bots') || '[]');
      return bots.map(function (b) { return b && (b.ea_id || (b.ea && b.ea.id)); })
                 .filter(function (x) { return !!x; });
    } catch (e) { return []; }
  }
  function pollSignals() {
    var s = session(), ids = botEaIds();
    if (!s || ids.length === 0) return;
    fetch(REST + 'signals?select=id,symbol,direction,action,lot_size,entry_price,take_profit,stop_loss,created_at' +
          '&ea_id=in.(' + ids.map(encodeURIComponent).join(',') + ')&order=created_at.desc&limit=30',
          { headers: { apikey: ANON, Authorization: 'Bearer ' + s.token } })
      .then(function (r) { return r.ok ? r.json() : []; })
      .then(function (rows) {
        if (!Array.isArray(rows)) return;
        // oldest first, so the console writes them in order
        rows.slice().reverse().forEach(function (r) {
          if (seen[r.id]) return;
          seen[r.id] = 1;
          if (firstRun) return;
          signalReceived(sigOf(r), r.id);
          var title = ((r.action || 'SIGNAL') + ' ' + (r.symbol || '') + ' ' + (r.direction || '')).trim();
          var body = 'Lot ' + (r.lot_size || '-') + (r.entry_price ? ' \u00b7 @ ' + r.entry_price : '');
          try { AndroidNotify.show(title, body); } catch (e) {}
        });
        firstRun = false;
      })
      .catch(function () {});
  }
  setInterval(pollSignals, 4000);
  setTimeout(pollSignals, 1500);

  // 4) Whether the MetaTrader account is connected (the page's own "Account connected" state)
  function checkAccount() {
    var s = session();
    if (!s) return;
    fetch(REST + 'mt_credentials?select=id&user_id=eq.' + s.uid +
          '&copy_trade_enabled=eq.true&is_connected=eq.true&limit=1',
          { headers: { apikey: ANON, Authorization: 'Bearer ' + s.token } })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (rows) {
        if (!Array.isArray(rows)) return;
        // the web app's own test: an account with copy trading on and connected
        accountOn = rows.length > 0;
      })
      .catch(function () {});
  }
  setInterval(checkAccount, 10000);
  setTimeout(checkAccount, 2000);

  // 5) Dropdowns (the broker, server and account type lists): the phone's own dropdown does not open
  //    in the app, so a tap opens a simple list at the bottom of the screen, and the choice is sent to the page.
  var pickerEl = null;
  function closePicker() {
    if (pickerEl) { pickerEl.remove(); pickerEl = null; }
  }
  function setSelectValue(sel, val) {
    var d = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value');
    d.set.call(sel, val);
    sel.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function openPicker(sel) {
    closePicker();
    var box = document.createElement('div');
    box.setAttribute('id', 'te-picker');
    box.setAttribute('style', 'position:fixed;left:0;right:0;bottom:0;max-height:60vh;overflow:auto;' +
      'background:#0b0e14;border-top:2px solid #10b981;border-radius:16px 16px 0 0;' +
      'z-index:2147483647;padding:8px 0;font-family:monospace;box-shadow:0 -8px 30px rgba(0,0,0,.6);');
    for (var i = 0; i < sel.options.length; i++) {
      (function (o) {
        var b = document.createElement('button');
        b.type = 'button';
        b.textContent = o.text;
        var on = o.value === sel.value;
        b.setAttribute('style', 'display:block;width:100%;text-align:left;padding:14px 20px;background:none;' +
          'border:0;font-size:16px;color:' + (on ? '#10b981' : '#e5e7eb') + ';font-weight:' + (on ? '700' : '400') + ';');
        b.addEventListener('click', function (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          setSelectValue(sel, o.value);
          closePicker();
        });
        box.appendChild(b);
      })(sel.options[i]);
    }
    box.addEventListener('click', function (ev) {
      if (ev.target === box) closePicker();
    });
    document.body.appendChild(box);
    pickerEl = box;
  }
  function selectTap(ev) {
    var t = ev.target;
    while (t && t.tagName !== 'SELECT') t = t.parentNode;
    if (!t || t.disabled) return;
    ev.preventDefault();
    ev.stopPropagation();
    openPicker(t);
  }
  document.addEventListener('touchstart', selectTap, { capture: true, passive: false });
  document.addEventListener('mousedown', selectTap, true);

  setInterval(checkBot, 1000);
  setInterval(reportConsole, 300);
  checkBot();
})();
