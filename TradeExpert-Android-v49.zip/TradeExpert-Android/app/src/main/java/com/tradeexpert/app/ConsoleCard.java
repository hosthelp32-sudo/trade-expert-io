package com.tradeexpert.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * The bot console card, as in the videos: the bot picture fills the top with the name and the
 * account status over it, a scanline texture, a drag grip and a close button. Below it the console
 * lines are typed out letter by letter, under a red section label. A chart scanner signal adds its
 * execution and the reason ("why") to the same lines. The footer has "Powered by TradeExpert" and
 * the stop and clear buttons. The colour follows the app's accent colour and cycles.
 */
class ConsoleCard {

    static final int DEFAULT_ACCENT = 0xFF10B981;   // the web app's default colour
    static final int FRAME = DEFAULT_ACCENT;         // the bubble ring uses this too
    static final int BODY = 0xFF07090D;
    static final int MUTED = 0xFFB8BDC7;
    static final int BTN = 0xFF141820;
    static final int BTN_EDGE = 0xFF3A3F4A;

    private static final int SPAN = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE;

    /** One console line. A section label (sep) is written at once. */
    private static final class Row {
        String text;
        final boolean sep;
        int shown;
        TextView view;
        int color;          // a fixed colour for this line (0 = the accent)
        boolean cycle;      // the colour keeps changing (the signal line)

        Row(String text, boolean sep) {
            this.text = text;
            this.sep = sep;
            this.shown = sep ? text.length() : 0;
        }
    }

    /** Three small dots at the top corner: the card's drag grip. */
    private static final class GripView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;

        GripView(Context c, float d) {
            super(c);
            this.d = d;
            p.setColor(FRAME);
        }

        void setColour(int c) {
            p.setColor(c);
            invalidate();
        }

        @Override
        protected void onDraw(Canvas cv) {
            float r = 1.6f * d, gap = 5f * d;
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    cv.drawCircle(r + col * gap, r + row * gap, r, p);
                }
            }
        }
    }

    /** Faint horizontal scanlines over the picture. */
    private static final class ScanView extends View {
        private final Paint p = new Paint();
        private final float step;

        ScanView(Context c, float d) {
            super(c);
            step = 3f * d;
            p.setColor(0x14FFFFFF);
            p.setStrokeWidth(Math.max(1f, d * 0.5f));
        }

        @Override
        protected void onDraw(Canvas cv) {
            for (float y = 0; y < getHeight(); y += step) {
                cv.drawLine(0, y, getWidth(), y, p);
            }
        }
    }

    final FrameLayout root;
    /** The picture at the top: drag the card by it. */
    final View header;
    private final Context ctx;
    private final float d;
    private final LinearLayout content;
    private final TextView nameTv, statusTv, stopBtn, poweredTv;
    private final ImageView picture;
    private final GradientDrawable frameBg, closeRing;
    private final GripView grip;
    private final ScrollView logScroll;
    private final LinearLayout logBox;
    private final Handler main = new Handler(Looper.getMainLooper());
    /** The rows on the card, in order: the bot's lines, then the chart scanner's. */
    private final List<Row> rows = new ArrayList<>();
    private final List<Row> botRows = new ArrayList<>();
    private final List<Row> scanRows = new ArrayList<>();
    private boolean typingScheduled = false;
    private String lastImg = "";
    private Bitmap shownBitmap = null;
    private boolean lastRunning = false;
    private boolean dismissed = false;
    /** Whether the MetaTrader account is connected (from the web app). */
    private boolean accountConnected = false;
    /** The bot's name and running state, and whether a signal asked for its lines to be written. */
    private String curName = "BOT";
    private boolean curRunning = false;
    private boolean forceBot = false;
    /** The accent parts of the card (corner brackets and the divider) that follow the colour. */
    private final List<View> accents = new ArrayList<>();

    // the app's colours: accent, secondary (0 = none) and cycle speed
    private int accent = DEFAULT_ACCENT;
    private int secondary = 0;
    private float speed = 0.3f;
    private boolean cycling = false;

    /** The ring of light round the card: its colours run round the edge and keep changing. */
    private final RingLight ringLight;
    private final Runnable ringTick = new Runnable() {
        @Override
        public void run() {
            if (!content.isAttachedToWindow()) return;
            content.invalidate();
            content.postDelayed(this, 40);
        }
    };

    static final class RingLight extends Drawable {
        private final Paint glow, line;
        private final Matrix m = new Matrix();
        private final RectF r = new RectF();
        private final float d, rad;

        RingLight(float density) {
            d = density;
            rad = 12 * d;
            glow = new Paint(Paint.ANTI_ALIAS_FLAG);
            glow.setStyle(Paint.Style.STROKE);
            glow.setStrokeWidth(9 * d);
            glow.setMaskFilter(new BlurMaskFilter(6 * d, BlurMaskFilter.Blur.NORMAL));
            glow.setAlpha(170);
            line = new Paint(Paint.ANTI_ALIAS_FLAG);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(2 * d);
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            float inset = 5 * d;
            r.set(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset);
            long t = SystemClock.uptimeMillis();
            float turn = (t % 6000) / 6000f * 360f;         // one lap every 6 s
            float hue = (t % 14000) / 14000f * 360f;        // the colours cycle over 14 s
            int[] cols = new int[]{
                    Color.HSVToColor(new float[]{hue, 0.9f, 1f}),
                    Color.HSVToColor(new float[]{(hue + 120) % 360, 0.9f, 1f}),
                    Color.HSVToColor(new float[]{(hue + 240) % 360, 0.9f, 1f}),
                    Color.HSVToColor(new float[]{hue, 0.9f, 1f})};
            SweepGradient sg = new SweepGradient(r.centerX(), r.centerY(), cols, null);
            m.setRotate(turn, r.centerX(), r.centerY());
            sg.setLocalMatrix(m);
            glow.setShader(sg);
            line.setShader(sg);
            c.drawRoundRect(r, rad, rad, glow);
            c.drawRoundRect(r, rad, rad, line);
        }

        @Override public void setAlpha(int alpha) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    private final Runnable cycler = new Runnable() {
        @Override
        public void run() {
            double t = (Math.sin(SystemClock.uptimeMillis() / 1000.0 * 2 * Math.PI * speed) + 1) / 2;
            setTint(mix(accent, otherColour(), (float) t));
            main.postDelayed(this, 50);
        }
    };

    ConsoleCard(Context c, Runnable onClose) {
        ctx = c;
        d = c.getResources().getDisplayMetrics().density;

        content = new LinearLayout(c);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setClipToOutline(true);
        content.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        frameBg = box(BODY, dp(12), FRAME, dp(2));
        ringLight = new RingLight(d);
        content.setBackground(new LayerDrawable(new Drawable[]{frameBg, ringLight}));
        content.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View v) { content.post(ringTick); }
            @Override public void onViewDetachedFromWindow(View v) { }
        });

        // top: the bot picture fills it; the name and status sit over its lower edge
        FrameLayout pic = new FrameLayout(c);
        pic.setBackgroundColor(0xFF05090F);
        header = pic;
        picture = new ImageView(c);
        picture.setScaleType(ImageView.ScaleType.CENTER_CROP);
        picture.setImageResource(R.drawable.app_logo);
        pic.addView(picture, new FrameLayout.LayoutParams(-1, -1));

        // a soft fade only at the bottom, so the picture itself stays clear
        View shade = new View(c);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x00070910, 0x00070910, 0xCC07090D}));
        pic.addView(shade, new FrameLayout.LayoutParams(-1, dp(96), Gravity.BOTTOM));

        LinearLayout info = new LinearLayout(c);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(14), 0, dp(14), dp(12));
        nameTv = text("BOT", 22, 0xFFFFFFFF, true);
        nameTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        nameTv.setSingleLine(true);
        nameTv.setEllipsize(TextUtils.TruncateAt.END);
        info.addView(nameTv);
        statusTv = text("● ACCOUNT CONNECTED", 11, FRAME, true);
        statusTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        statusTv.setLetterSpacing(0.06f);
        info.addView(statusTv);
        pic.addView(info, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        grip = new GripView(c, d);
        FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(dp(16), dp(16), Gravity.TOP | Gravity.START);
        gp.setMargins(dp(12), dp(12), 0, 0);
        pic.addView(grip, gp);

        closeRing = box(0xAA000000, dp(15), FRAME, dp(1));
        TextView close = text("✕", 12, 0xFFFFFFFF, true);
        close.setGravity(Gravity.CENTER);
        close.setBackground(closeRing);
        close.setOnClickListener(v -> onClose.run());
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.TOP | Gravity.END);
        cp.setMargins(0, dp(10), dp(10), 0);
        pic.addView(close, cp);
        content.addView(pic, new LinearLayout.LayoutParams(-1, dp(190)));

        // a thin accent line under the picture
        View divider = new View(c);
        accents.add(divider);
        content.addView(divider, new LinearLayout.LayoutParams(-1, dp(2)));

        // the console: black panel with the section label and the typed lines
        LinearLayout panel = new LinearLayout(c);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xFF000000);
        panel.setPadding(dp(14), dp(10), dp(14), dp(8));
        logBox = new LinearLayout(c);
        logBox.setOrientation(LinearLayout.VERTICAL);
        logScroll = new ScrollView(c);
        logScroll.setVerticalScrollBarEnabled(false);
        logScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        logScroll.addView(logBox, new FrameLayout.LayoutParams(-1, -2));
        panel.addView(logScroll, new LinearLayout.LayoutParams(-1, dp(130)));
        content.addView(panel, new LinearLayout.LayoutParams(-1, -2));

        // footer: "Powered by TradeExpert" (clear), stop and clear buttons
        LinearLayout footer = new LinearLayout(c);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.setBackgroundColor(0xFF0B0E14);
        footer.setPadding(dp(14), dp(6), dp(8), dp(8));
        poweredTv = text("Powered by TradeExpert", 11, 0xFFFFFFFF, true);
        poweredTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        footer.addView(poweredTv, new LinearLayout.LayoutParams(0, -2, 1f));
        stopBtn = iconButton("▢", "toggle");
        footer.addView(stopBtn, buttonParams(0));
        footer.addView(clearButton(), buttonParams(6));
        content.addView(footer, new LinearLayout.LayoutParams(-1, -2));

        root = new FrameLayout(c);
        root.addView(content, new FrameLayout.LayoutParams(-1, -2));
        // corner brackets around the card
        bracket(Gravity.TOP | Gravity.START);
        bracket(Gravity.TOP | Gravity.END);
        bracket(Gravity.BOTTOM | Gravity.START);
        bracket(Gravity.BOTTOM | Gravity.END);
        setTint(FRAME);
    }

    /** Stop the colour cycle (the card is being removed). */
    void stop() {
        cycling = false;
        main.removeCallbacks(cycler);
    }

    /** The bot picture arrived (or changed): show it on the card. */
    void refreshPicture() {
        Bitmap bm = BotPicture.bitmap;
        if (bm != null && bm != shownBitmap) {
            shownBitmap = bm;
            picture.setImageBitmap(bm);
        }
    }

    /**
     * Fill the card from the web data: the name, the picture and the colour, and the bot's lines
     * while the bot runs. The page's own console is not used.
     */
    void update(String json) {
        try {
            JSONObject o = new JSONObject(json);
            String name = o.optString("name", "");
            nameTv.setText(name.isEmpty() ? "BOT" : name.toUpperCase());
            boolean running = o.optBoolean("running", false);
            stopBtn.setText(running ? "▢" : "▷");
            // the account's own connection (not the bot's running state)
            accountConnected = o.optBoolean("account", false);
            // the status line shows only when the account is connected
            statusTv.setText("● ACCOUNT CONNECTED");
            statusTv.setVisibility(accountConnected ? View.VISIBLE : View.GONE);
            if (BotPicture.bitmap != null) refreshPicture();
            else loadImage(o.optString("img", ""));
            setAccent(o.optString("accent", ""), o.optString("secondary", ""), (float) o.optDouble("speed", 0.3));

            if (running != lastRunning) {
                forceBot = false;
                lastRunning = running;
                dismissed = false;
            }
            curName = name.isEmpty() ? "BOT" : name;
            curRunning = running;
            rebuildBot();
            sync();
        } catch (Exception ignored) {
        }
    }

    /**
     * The chart scanner's trades were placed (after EXECUTE TRADE): the console writes only the
     * signal, the stop loss, the take profit and the number of trades, typed out one by one.
     */
    /**
     * The bot's lines: written when the bot runs, when the trading account is connected, and before
     * a signal is sent (the bot writes its lines first, then the signal).
     */
    private void rebuildBot() {
        botRows.clear();
        if (!((curRunning || forceBot || accountConnected) && !dismissed)) return;
        botRows.add(new Row("Bot console", true));
        if (curRunning || forceBot) {
            botRows.add(new Row(curName + " is connected", false));
            botRows.add(new Row("Servers online and EA is active", false));
            botRows.add(new Row("Waiting for a new live signal...", false));
        } else {
            botRows.add(new Row("Trading account is connected", false));
            botRows.add(new Row(curName + " is on standby", false));
            botRows.add(new Row("Start the bot to receive live signals", false));
        }
    }

    void showTrade(JSONObject t) {
        String dir = t.optString("direction", "").toUpperCase();
        String sym = t.optString("symbol", "").toUpperCase();
        String phase = t.optString("phase", "");
        int placed = t.optInt("placed", 0);
        boolean received = "received".equals(phase);
        boolean ok = !received && t.optBoolean("ok", placed > 0) && placed > 0;
        if (received) {
            // the bot writes its lines, then the signal and its levels
            forceBot = true;
            rebuildBot();
        }
        dropScanRows();
        Row sigRow = new Row((dir + " " + sym).trim(), false);
        sigRow.cycle = true;
        scanRows.add(sigRow);
        if (received || ok) {
            Row sl = new Row("SL " + (t.has("stopLoss") ? t.optString("stopLoss") : "-"), false);
            sl.color = 0xFFFF4D4D;     // stop loss: red
            scanRows.add(sl);
            Row tp = new Row("TP " + (t.has("takeProfit") ? t.optString("takeProfit") : "-"), false);
            tp.color = 0xFF3DDC84;     // take profit: green
            scanRows.add(tp);
        }
        if (received) {
            // the trades follow
        } else if (ok) {
            scanRows.add(new Row(placed + " TRADE EXECUTED", false));
        } else {
            // not placed: the reason (for example not enough money) is written on the console
            String msg = t.optString("message", "").trim();
            if (msg.isEmpty()) msg = "Trade not placed";
            if (msg.length() > 140) msg = msg.substring(0, 137) + "...";
            scanRows.add(new Row("TRADE NOT PLACED", false));
            scanRows.add(new Row(msg, false));
        }
        sync();
    }

    /** Make the list on the card match the bot's lines and the scanner's lines. */
    private void sync() {
        List<Row> incoming = new ArrayList<>(botRows);
        incoming.addAll(scanRows);

        // a line still being written grows in place and keeps its typed letters
        int same = 0;
        while (same < rows.size() && same < incoming.size()) {
            Row have = rows.get(same);
            Row want = incoming.get(same);
            if (have.sep != want.sep) break;
            if (have.text.equals(want.text)) {
                same++;
            } else if (!have.sep && want.text.startsWith(have.text)) {
                have.text = want.text;
                same++;
            } else {
                break;
            }
        }
        while (rows.size() > same) {
            Row r = rows.remove(rows.size() - 1);
            if (r.view != null) logBox.removeView(r.view);
            r.view = null;
        }
        for (int i = same; i < incoming.size(); i++) {
            Row r = incoming.get(i);
            r.view = makeView(r);
            logBox.addView(r.view, new LinearLayout.LayoutParams(-1, -2));
            rows.add(r);
        }
        scheduleTyping();
        scheduleCycle();
        logScroll.fullScroll(View.FOCUS_DOWN);
    }

    private boolean cycleOn = false;

    /** Repaints the lines whose colour keeps changing (the signal line) while they are on the card. */
    private void scheduleCycle() {
        if (cycleOn) return;
        cycleOn = true;
        main.post(cycleTick);
    }

    private final Runnable cycleTick = new Runnable() {
        @Override
        public void run() {
            boolean any = false;
            for (Row r : rows) {
                if (r.cycle && r.view != null) {
                    paint(r, r.view);
                    any = true;
                }
            }
            if (any) {
                main.postDelayed(this, 60);
            } else {
                cycleOn = false;
            }
        }
    };

    /** Take the scanner's lines off the card (a new signal writes them again from the start). */
    private void dropScanRows() {
        for (Row r : scanRows) {
            rows.remove(r);
            if (r.view != null) logBox.removeView(r.view);
            r.view = null;
        }
        scanRows.clear();
    }

    /** Take the app's colours. A change repaints the lines; the frame keeps cycling. */
    private void setAccent(String accentHex, String secondaryHex, float sp) {
        int a = parse(accentHex, DEFAULT_ACCENT);
        int s = parse(secondaryHex, 0);
        float newSpeed = sp > 0 ? Math.min(sp, 3f) : 0.3f;
        boolean changed = a != accent || s != secondary;
        accent = a;
        secondary = s;
        speed = newSpeed;
        BubbleService.setRingColours(accent, otherColour());
        if (changed) repaintAll();
        if (!cycling) {
            cycling = true;
            main.post(cycler);
        }
    }

    /** The second colour of the cycle: the app's secondary colour, or a light tint of the accent. */
    private int otherColour() {
        return secondary != 0 ? secondary : mix(accent, 0xFFFFFFFF, 0.45f);
    }

    /** The corner bracket: an L of two thin bars at one corner. */
    private void bracket(int gravity) {
        int len = dp(16), t = dp(2), m = dp(4);
        boolean top = (gravity & Gravity.TOP) != 0;
        boolean start = (gravity & Gravity.START) != 0;
        View h = new View(ctx);
        View v = new View(ctx);
        accents.add(h);
        accents.add(v);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(len, t, gravity);
        FrameLayout.LayoutParams vp = new FrameLayout.LayoutParams(t, len, gravity);
        hp.setMargins(start ? m : 0, top ? m : 0, start ? 0 : m, top ? 0 : m);
        vp.setMargins(start ? m : 0, top ? m : 0, start ? 0 : m, top ? 0 : m);
        root.addView(h, hp);
        root.addView(v, vp);
    }

    /** Paint the frame, the grip, the close ring, the status and the accent parts in one colour. */
    private void setTint(int c) {
        frameBg.setStroke(dp(2), c);
        closeRing.setStroke(dp(1), c);
        statusTv.setTextColor(accountConnected ? c : MUTED);
        grip.setColour(c);
        for (View v : accents) v.setBackgroundColor(c);
    }

    private void repaintAll() {
        for (Row r : rows) {
            if (r.view != null) paint(r, (TextView) r.view);
        }
    }

    private TextView makeView(Row r) {
        TextView t = new TextView(ctx);
        t.setTextSize(12);
        t.setTypeface(Typeface.MONOSPACE);
        t.setLineSpacing(0, 1.15f);
        t.setPadding(0, dp(2), 0, dp(2));
        if (r.sep) {
            t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            t.setLetterSpacing(0.12f);
            t.setTextSize(11);
            t.setPadding(0, dp(6), 0, dp(3));
        }
        paint(r, t);
        return t;
    }

    /** Write the typed part of the line: ">> " in the accent colour, then the text. */
    private void paint(Row r, TextView t) {
        int n = Math.min(r.shown, r.text.length());
        boolean typing = n < r.text.length();
        SpannableStringBuilder sb = new SpannableStringBuilder();
        if (r.sep) {
            sb.append(r.text.toUpperCase());
            sb.setSpan(new ForegroundColorSpan(accent), 0, sb.length(), SPAN);
        } else {
            // the line's colour: a fixed one (SL red, TP green), or a colour that keeps changing (the signal)
            int base = r.cycle
                    ? Color.HSVToColor(new float[]{(SystemClock.uptimeMillis() % 3000) / 3000f * 360f, 0.85f, 1f})
                    : r.color != 0 ? r.color : mix(accent, 0xFFFFFFFF, 0.25f);
            boolean own = r.cycle || r.color != 0;
            sb.append(">> ");
            sb.setSpan(new ForegroundColorSpan(own ? base : accent), 0, 2, SPAN);
            sb.setSpan(new StyleSpan(Typeface.BOLD), 0, 2, SPAN);
            int start = sb.length();
            sb.append(r.text, 0, n);
            sb.setSpan(new ForegroundColorSpan(base), start, sb.length(), SPAN);
            if (typing) {
                sb.append("▌");
                sb.setSpan(new ForegroundColorSpan(own ? base : accent), sb.length() - 1, sb.length(), SPAN);
            }
        }
        t.setText(sb);
    }

    private void scheduleTyping() {
        if (typingScheduled) return;
        typingScheduled = true;
        main.post(typer);
    }

    /** Types the lines letter by letter, a few letters per frame, so the card never freezes. */
    private final Runnable typer = new Runnable() {
        @Override
        public void run() {
            Row cur = null;
            int pending = 0;
            for (Row r : rows) {
                if (r.shown >= r.text.length()) continue;
                if (cur == null) cur = r;
                pending += r.text.length() - r.shown;
            }
            if (cur == null || cur.view == null) {
                typingScheduled = false;
                return;
            }
            int step = pending > 300 ? 3 : pending > 120 ? 2 : 1;
            cur.shown = Math.min(cur.text.length(), cur.shown + step);
            paint(cur, (TextView) cur.view);
            logScroll.fullScroll(View.FOCUS_DOWN);
            main.postDelayed(this, 30);
        }
    };

    /** Clear the card's lines until the bot is switched off and on again. */
    private void clearLines() {
        dismissed = true;
        botRows.clear();
        dropScanRows();
        for (Row r : rows) {
            if (r.view != null) logBox.removeView(r.view);
        }
        rows.clear();
    }

    private void loadImage(String img) {
        if (img == null || img.isEmpty() || img.equals(lastImg)) return;
        lastImg = img;
        if (img.startsWith("data:image")) {
            try {
                byte[] b = android.util.Base64.decode(img.substring(img.indexOf(',') + 1), android.util.Base64.DEFAULT);
                picture.setImageBitmap(BitmapFactory.decodeByteArray(b, 0, b.length));
            } catch (Exception ignored) {
            }
            return;
        }
        if (!img.startsWith("http")) return;
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(img).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                try (InputStream in = c.getInputStream()) {
                    Bitmap bm = BitmapFactory.decodeStream(in);
                    if (bm != null) main.post(() -> picture.setImageBitmap(bm));
                }
            } catch (Exception ignored) {
            }
        }).start();
    }

    private static int parse(String hex, int fallback) {
        try {
            return Color.parseColor(hex);
        } catch (Exception e) {
            return fallback;
        }
    }

    /** Colour a (0 = first, 1 = second). */
    static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private TextView iconButton(final String label, final String which) {
        TextView b = text(label, 13, 0xFFEDEDED, false);
        b.setGravity(Gravity.CENTER);
        b.setBackground(box(BTN, dp(7), BTN_EDGE, dp(1)));
        b.setOnClickListener(v -> PageHost.clickButton(which));
        return b;
    }

    private TextView clearButton() {
        TextView b = text("🗑", 13, 0xFFEDEDED, false);
        b.setGravity(Gravity.CENTER);
        b.setBackground(box(BTN, dp(7), BTN_EDGE, dp(1)));
        b.setOnClickListener(v -> clearLines());
        return b;
    }

    private LinearLayout.LayoutParams buttonParams(int leftDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(30), dp(30));
        lp.leftMargin = dp(leftDp);
        return lp;
    }

    private int dp(float v) {
        return (int) (v * d + 0.5f);
    }

    private GradientDrawable box(int fill, int radiusPx, int stroke, int strokePx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radiusPx);
        if (stroke != 0) g.setStroke(strokePx, stroke);
        return g;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }
}
