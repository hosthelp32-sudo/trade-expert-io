package com.tradeexpert.app;

import android.animation.ObjectAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;

/**
 * The bot over other apps and inside the app.
 * Bot ON: the console card opens at once. Its X closes it to the bubble. Tapping the bubble opens the card.
 * Bot OFF: the card and the bubble both disappear.
 */
public class BubbleService extends Service {

    static final int BG = 0xFF0A0D14;      // app background
    static final int BLUE = 0xFF3B82F6;    // app blue
    private static final String CHANNEL = "tx_running";
    private static final int NOTIF_ID = 7;

    static BubbleService instance;
    static volatile boolean botOn = false;
    static volatile boolean appVisible = false;
    static volatile String consoleJson = "";

    private WindowManager wm;
    private FrameLayout bubble;
    private WindowManager.LayoutParams bubbleLp;
    private ObjectAnimator cycle;
    private ConsoleCard card;
    private ImageView bubbleImg;
    private WindowManager.LayoutParams cardLp;
    private boolean cardOpen = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        NotificationChannel ch = new NotificationChannel(CHANNEL, "Running", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);

        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Trade Expert")
                .setContentText("Running in the background. Tap to open.")
                .setOngoing(true)
                .setContentIntent(open)
                .build();
        startForeground(NOTIF_ID, n);

        cardOpen = botOn;   // bot already ON when the service starts: the console opens at once
        refresh();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    /**
     * The bot switch. ON: the console opens at once. OFF: everything disappears.
     * The page calls this from a background thread, so the screen work runs on the main thread.
     */
    static void setBotOn(final Context c, final boolean on) {
        new Handler(Looper.getMainLooper()).post(() -> {
            botOn = on;
            if (instance == null) {
                if (on) c.startForegroundService(new Intent(c, BubbleService.class));
                return;
            }
            instance.cardOpen = on;   // ON: console open now; OFF: nothing
            instance.refresh();
        });
    }

    /**
     * The app on screen: the page shows its own bot button and console, so the app's
     * display and card are hidden (one console only). Over other apps they show.
     */
    static void setAppVisible(final boolean visible) {
        new Handler(Looper.getMainLooper()).post(() -> {
            appVisible = visible;
            if (instance != null) instance.refresh();
        });
    }

    /** The bot console data from the page (also from a background thread). */
    static void setConsole(final String json) {
        new Handler(Looper.getMainLooper()).post(() -> {
            consoleJson = json;
            if (instance != null) instance.pushConsole();
        });
    }

    private void pushConsole() {
        if (card != null) card.update(consoleJson);
    }

    /** Show exactly one of: the card (when open) or the bubble (when closed); nothing when the bot is OFF. */
    void refresh() {
        if (!botOn || appVisible) {
            removeCard();
            removeBubble();
            return;
        }
        if (cardOpen) {
            removeBubble();
            addCard();
        } else {
            removeCard();
            addBubble();
        }
    }

    private void addCard() {
        if (card != null || !Settings.canDrawOverlays(this)) return;
        float d = getResources().getDisplayMetrics().density;
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int w = Math.min((int) (300 * d), screenW - (int) (16 * d));

        card = new ConsoleCard(this, () -> {
            cardOpen = false;
            refresh();
        });
        cardLp = new WindowManager.LayoutParams(
                w, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        cardLp.gravity = Gravity.TOP | Gravity.START;
        cardLp.x = (screenW - w) / 2;
        cardLp.y = (int) (getResources().getDisplayMetrics().heightPixels * 0.16f);

        // drag the card by its header
        card.header.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = cardLp.x;
                        sy = cardLp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        cardLp.x = sx + (int) (e.getRawX() - tx);
                        cardLp.y = sy + (int) (e.getRawY() - ty);
                        try {
                            wm.updateViewLayout(card.root, cardLp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });

        try {
            wm.addView(card.root, cardLp);
            card.update(consoleJson);
        } catch (Exception e) {
            Log.e("TradeExpert", "card not shown", e);
            card = null;
        }
    }

    private void removeCard() {
        if (card != null) {
            try {
                wm.removeView(card.root);
            } catch (Exception ignored) {
            }
            card = null;
        }
    }

    private void addBubble() {
        if (bubble != null || !Settings.canDrawOverlays(this)) return;
        float d = getResources().getDisplayMetrics().density;
        int size = (int) (64 * d);
        int screenW = getResources().getDisplayMetrics().widthPixels;

        bubble = new FrameLayout(this);
        int ring = (int) (2 * d);

        // the web's gold ring (135deg gold -> dim gold) with a glow
        GradientDrawable rg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{ConsoleCard.FRAME, 0xFF2F6FD6});
        rg.setShape(GradientDrawable.OVAL);
        View ringView = new View(this);
        ringView.setBackground(rg);
        bubble.addView(ringView, new FrameLayout.LayoutParams(size, size));

        // the bot picture (the same picture as the web floating button)
        bubbleImg = new ImageView(this);
        bubbleImg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bubbleImg.setClipToOutline(true);
        bubbleImg.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
        GradientDrawable imgBg = new GradientDrawable();
        imgBg.setShape(GradientDrawable.OVAL);
        imgBg.setColor(0xFF030807);
        bubbleImg.setBackground(imgBg);
        bubbleImg.setPadding(ring, ring, ring, ring);
        applyBotPicture();
        bubble.addView(bubbleImg, new FrameLayout.LayoutParams(size, size));

        // the pulsing gold status dot (bottom-right), like the web
        View dot = new View(this);
        GradientDrawable dg = new GradientDrawable();
        dg.setShape(GradientDrawable.OVAL);
        dg.setColor(ConsoleCard.FRAME);
        dg.setStroke((int) (2 * d), 0xFF0A0D14);
        dot.setBackground(dg);
        int ds = (int) (16 * d);
        bubble.addView(dot, new FrameLayout.LayoutParams(ds, ds, Gravity.BOTTOM | Gravity.END));

        cycle = ObjectAnimator.ofFloat(dot, View.ALPHA, 1f, 0.35f, 1f);
        cycle.setDuration(1600);
        cycle.setRepeatCount(ObjectAnimator.INFINITE);
        cycle.setInterpolator(new LinearInterpolator());

        bubbleLp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = screenW - size;
        bubbleLp.y = (int) (220 * d);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float touchX, touchY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = bubbleLp.x;
                        startY = bubbleLp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - touchX;
                        float dy = e.getRawY() - touchY;
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true;
                        bubbleLp.x = startX + (int) dx;
                        bubbleLp.y = startY + (int) dy;
                        try {
                            wm.updateViewLayout(bubble, bubbleLp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            // tap: open the console
                            cardOpen = true;
                            refresh();
                        } else {
                            bubbleLp.x = (bubbleLp.x + size / 2 < screenW / 2) ? 0 : screenW - size;
                            try {
                                wm.updateViewLayout(bubble, bubbleLp);
                            } catch (Exception ignored) {
                            }
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });

        try {
            wm.addView(bubble, bubbleLp);
            cycle.start();
        } catch (Exception e) {
            Log.e("TradeExpert", "bubble not shown", e);
            bubble = null;
        }
    }

    private void applyBotPicture() {
        if (bubbleImg == null) return;
        Bitmap bm = ConsoleCard.botBitmap;
        if (bm != null) {
            bubbleImg.setImageBitmap(bm);
        } else {
            bubbleImg.setImageResource(R.drawable.app_logo);
        }
    }

    /** Called when the bot picture arrives: the bubble and the card show it. */
    static void onBotPicture() {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (instance != null) instance.applyBotPicture();
        });
    }

    private void removeBubble() {
        if (cycle != null) cycle.cancel();
        if (bubble != null) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubble = null;
        }
    }

    @Override
    public void onDestroy() {
        removeCard();
        removeBubble();
        instance = null;
        super.onDestroy();
    }
}
