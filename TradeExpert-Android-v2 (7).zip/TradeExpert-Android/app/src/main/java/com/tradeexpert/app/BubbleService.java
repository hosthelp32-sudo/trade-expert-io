package com.tradeexpert.app;

import android.animation.ObjectAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;

/**
 * The Trade Expert bubble over other apps: the logo in a dark circle with a blue ring,
 * and a blue dot that cycles around it. Tap to open the app. It hides while the app is on screen.
 */
public class BubbleService extends Service {

    static final int BG = 0xFF0A0D14;      // app background
    static final int BLUE = 0xFF3B82F6;    // app blue
    private static final String CHANNEL = "tx_running";
    private static final int NOTIF_ID = 7;

    static BubbleService instance;
    static volatile boolean botOn = false;

    private WindowManager wm;
    private FrameLayout bubble;
    private WindowManager.LayoutParams lp;
    private ObjectAnimator cycle;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        NotificationChannel ch = new NotificationChannel(CHANNEL, "Running", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);

        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Trade Expert")
                .setContentText("Running in the background. Tap to open.")
                .setOngoing(true)
                .setContentIntent(open)
                .build();
        startForeground(NOTIF_ID, n);

        if (botOn) show();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    /** The bot switch: the bubble shows while the bot is ON and hides when it is OFF. */
    static void setBotOn(Context c, boolean on) {
        botOn = on;
        if (instance == null) {
            if (on) {
                c.startForegroundService(new Intent(c, BubbleService.class));
            }
            return;
        }
        if (on) {
            instance.show();
        } else {
            instance.hide();
        }
    }

    void show() {
        if (bubble != null || !botOn || !Settings.canDrawOverlays(this)) return;
        float d = getResources().getDisplayMetrics().density;
        int size = (int) (64 * d);
        int screenW = getResources().getDisplayMetrics().widthPixels;

        bubble = new FrameLayout(this);

        // dark circle with a blue ring (the app's colours)
        View ring = new View(this);
        GradientDrawable rg = new GradientDrawable();
        rg.setShape(GradientDrawable.OVAL);
        rg.setColor(BG);
        rg.setStroke((int) (2 * d), BLUE);
        ring.setBackground(rg);
        bubble.addView(ring, new FrameLayout.LayoutParams(size, size));

        // the logo
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.app_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        int pad = (int) (10 * d);
        logo.setPadding(pad, pad, pad, pad);
        bubble.addView(logo, new FrameLayout.LayoutParams(size, size));

        // the blue dot that cycles around the ring
        FrameLayout orbit = new FrameLayout(this);
        View dot = new View(this);
        GradientDrawable dg = new GradientDrawable();
        dg.setShape(GradientDrawable.OVAL);
        dg.setColor(BLUE);
        dot.setBackground(dg);
        int ds = (int) (7 * d);
        orbit.addView(dot, new FrameLayout.LayoutParams(ds, ds, Gravity.CENTER_HORIZONTAL | Gravity.TOP));
        bubble.addView(orbit, new FrameLayout.LayoutParams(size, size));

        cycle = ObjectAnimator.ofFloat(orbit, View.ROTATION, 0f, 360f);
        cycle.setDuration(2400);
        cycle.setRepeatCount(ObjectAnimator.INFINITE);
        cycle.setInterpolator(new LinearInterpolator());

        lp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = screenW - size;
        lp.y = (int) (220 * d);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float touchX, touchY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = lp.x;
                        startY = lp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - touchX;
                        float dy = e.getRawY() - touchY;
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true;
                        lp.x = startX + (int) dx;
                        lp.y = startY + (int) dy;
                        wm.updateViewLayout(bubble, lp);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            openApp();
                        } else {
                            lp.x = (lp.x + size / 2 < screenW / 2) ? 0 : screenW - size;
                            wm.updateViewLayout(bubble, lp);
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });

        try {
            wm.addView(bubble, lp);
            cycle.start();
        } catch (Exception e) {
            bubble = null;
        }
    }

    void hide() {
        if (cycle != null) cycle.cancel();
        if (bubble != null) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubble = null;
        }
    }

    private void openApp() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(i);
    }

    @Override
    public void onDestroy() {
        hide();
        instance = null;
        super.onDestroy();
    }
}
