package com.tradeexpert.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Trade Expert: shows the platform in the app.
 * The platform is the app's own copy of the site (assets/app/index.html).
 */
public class MainActivity extends Activity {

    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + APP_HOST + "/ea-app/activate";

    private WebView webView;
    private String bridgeJs = "";

    private String readAsset(String name) {
        try (java.io.InputStream in = getAssets().open(name)) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);
        bridgeJs = readAsset("te_bridge.js");
        webView.addJavascriptInterface(new TeBridge(this), "AndroidNotify");

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                inject(view, url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                inject(view, url);
            }

            private void inject(WebView view, String url) {
                if (bridgeJs.isEmpty() || url == null) return;
                if (APP_HOST.equals(Uri.parse(url).getHost())) {
                    view.evaluateJavascript(bridgeJs, null);
                }
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!APP_HOST.equals(uri.getHost())) return null;
                String path = uri.getPath() == null ? "" : uri.getPath();
                String file = path.substring(path.lastIndexOf('/') + 1);
                if (file.contains(".")) {
                    try {
                        return new WebResourceResponse(mimeOf(file), "UTF-8", getAssets().open("app" + path));
                    } catch (Exception ignored) {
                        // not a file we have: fall through to the app page
                    }
                }
                try {
                    // every other address is the app page (the site uses client-side pages)
                    return new WebResourceResponse("text/html", "UTF-8", getAssets().open("app/index.html"));
                } catch (Exception e) {
                    return null;
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (APP_HOST.equals(uri.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(START_URL);
        }

        // the bubble over other apps: ask for permission once, then start the background service
        if (!android.provider.Settings.canDrawOverlays(this)) {
            startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }
        startForegroundService(new Intent(this, BubbleService.class));
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private static String mimeOf(String file) {
        String f = file.toLowerCase();
        if (f.endsWith(".js")) return "application/javascript";
        if (f.endsWith(".css")) return "text/css";
        if (f.endsWith(".png")) return "image/png";
        if (f.endsWith(".jpg") || f.endsWith(".jpeg")) return "image/jpeg";
        if (f.endsWith(".svg")) return "image/svg+xml";
        if (f.endsWith(".json")) return "application/json";
        if (f.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }
}
