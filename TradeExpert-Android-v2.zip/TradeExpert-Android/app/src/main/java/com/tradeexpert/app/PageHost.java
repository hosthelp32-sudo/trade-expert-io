package com.tradeexpert.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.InputStream;

/**
 * The one page (the Trade Expert web app). The app screen and the floating window show this same page,
 * so the console is always the real web console.
 */
final class PageHost {

    static final String APP_HOST = "appassets.androidplatform.net";
    static final String START_URL = "https://" + APP_HOST + "/ea-app/activate";

    static WebView web;
    private static String bridgeJs = "";

    private PageHost() {}

    /** The page (created once; it keeps running while the bot is ON). */
    static synchronized WebView get(Context c) {
        if (web != null) return web;
        final Context app = c.getApplicationContext();
        bridgeJs = readAsset(app, "te_bridge.js");

        WebView w = new WebView(app);
        w.setBackgroundColor(0xFF0A0D14);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        w.addJavascriptInterface(new TeBridge(app), "AndroidNotify");

        w.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                inject(view, url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                inject(view, url);
            }

            private void inject(WebView view, String url) {
                if (bridgeJs.isEmpty() || url == null) return;
                if (APP_HOST.equals(Uri.parse(url).getHost())) {
                    view.evaluateJavascript(bridgeJs, null);
                }
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!APP_HOST.equals(uri.getHost())) return null;
                String path = uri.getPath() == null ? "" : uri.getPath();
                String file = path.substring(path.lastIndexOf('/') + 1);
                if (file.contains(".")) {
                    try {
                        return new WebResourceResponse(mimeOf(file), "UTF-8", app.getAssets().open("app" + path));
                    } catch (Exception ignored) {
                        // not a file we have: fall through to the app page
                    }
                }
                try {
                    return new WebResourceResponse("text/html", "UTF-8", app.getAssets().open("app/index.html"));
                } catch (Exception e) {
                    return null;
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (APP_HOST.equals(uri.getHost())) return false;
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, uri);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    app.startActivity(i);
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        w.loadUrl(START_URL);
        web = w;
        return w;
    }

    /** Put the page in a parent (the app screen or the floating window). */
    static void attach(WebView w, ViewGroup parent) {
        detach(w);
        parent.addView(w, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        w.onResume();
        w.resumeTimers();
    }

    static void detach(WebView w) {
        ViewParent p = w.getParent();
        if (p instanceof ViewGroup) ((ViewGroup) p).removeView(w);
    }

    /** Tap on the floating display: opens the real web console (the page's own bot button). */
    static void clickBubble() {
        WebView w = web;
        if (w == null) return;
        w.post(() -> w.evaluateJavascript(
                "(function(){var b=document.querySelector('.float-bubble');if(b)b.click();})();", null));
    }

    /** Over other apps: show only the console (the rest of the page is hidden). */
    static void overlayOn(WebView w) {
        w.evaluateJavascript(
                "(function(){if(!document.getElementById('te-overlay')){var st=document.createElement('style');"
                + "st.id='te-overlay';st.textContent='html,body,#root{background:transparent!important}"
                + "#root *{visibility:hidden!important}"
                + "[aria-label=\"Bot console\"],[aria-label=\"Bot console\"] *{visibility:visible!important}"
                + "[aria-label=\"Bot console\"]{position:fixed!important;left:0!important;top:0!important;"
                + "width:100vw!important;height:100vh!important;max-height:100vh!important;"
                + "max-width:100vw!important;border-radius:0!important;opacity:1!important;transform:none!important}';"
                + "document.head.appendChild(st);}"
                + "window.dispatchEvent(new Event('resize'));})();", null);
    }

    /** Back in the app: the page is shown as normal. */
    static void overlayOff(WebView w) {
        w.evaluateJavascript(
                "(function(){var st=document.getElementById('te-overlay');if(st)st.remove();})();", null);
    }

    /** The app is on screen (true) or not (false). */
    static void setVisible(boolean visible) {
        WebView w = web;
        if (w == null) return;
        w.evaluateJavascript("window.__teVisible=" + visible + ";", null);
    }

    private static String readAsset(Context c, String name) {
        try (InputStream in = c.getAssets().open(name)) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private static String mimeOf(String file) {
        String f = file.toLowerCase();
        if (f.endsWith(".js")) return "application/javascript";
        if (f.endsWith(".css")) return "text/css";
        if (f.endsWith(".png")) return "image/png";
        if (f.endsWith(".jpg") || f.endsWith(".jpeg")) return "image/jpeg";
        if (f.endsWith(".svg")) return "image/svg+xml";
        if (f.endsWith(".json")) return "application/json";
        if (f.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }
}
