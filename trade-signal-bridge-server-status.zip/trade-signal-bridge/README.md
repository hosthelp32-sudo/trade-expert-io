# Trade Signal Bridge — MetaTrader 5 integration

Self-hosted chart-scanner signal portal with a live console, MetaTrader 5 account-status check, and an optional MT5 desktop-terminal execution adapter.

## Important platform requirement
The official `MetaTrader5` Python package connects to a **running MetaTrader 5 desktop terminal on Windows**. A mobile MT5 app alone cannot provide this Python connection. If your app is hosted on Linux or a cloud server, run the MT5 bridge on the Windows computer where the terminal is logged in, or use a separately designed secure bridge.

## Install (Windows)
1. Install MetaTrader 5 desktop from your broker and log into the intended account.
2. In MT5, confirm the account/server shown in the terminal and enable **Algo Trading** only if you intend to use automated trading.
3. Install Python 3.10+ (64-bit) on the same Windows machine.
4. Unzip this project, open a terminal in its folder, and run:

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
```

5. Edit `.env`. For an already logged-in terminal, you can leave `MT5_LOGIN`, `MT5_PASSWORD`, and `MT5_SERVER` blank and set `MT5_TERMINAL_PATH` if auto-detection fails. Otherwise set login/server details in `.env`. Never commit `.env`.
6. Run:

```powershell
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000/portal` and `http://127.0.0.1:8000/console`. The console now shows a live MT5 connection status, account login/server, and free margin, and refreshes status every 10 seconds. Check `/api/account` for the connection diagnostic.

## Execution modes
- `EXECUTION_MODE=simulation` (default): checks MT5 connection and reports whether the account is connected, but does not send orders.
- `EXECUTION_MODE=live`: enables order submission through MT5. Use only after testing on a demo account and verifying symbol names, lot sizes, SL/TP, and broker settings.

The executor validates symbol availability, broker volume min/max/step, trading permissions, and estimated free margin before each order. The console reports the actual count confirmed by the terminal and the broker's rejection reason where available. Broker fills, slippage, partial fills, and account conditions are outside this application's control.

## Webhook signal format

`POST /webhook/signal` with header `X-Webhook-Token` and JSON:

```json
{
  "action": "BUY",
  "symbol": "XAUUSD",
  "sl": 2300.0,
  "tp": 2320.0,
  "lot_size": 0.01,
  "trades": 2
}
```

Symbols must be included in `ALLOWED_SYMBOLS`, and requested trades cannot exceed `MAX_TRADES_PER_SIGNAL`. Some brokers use suffixes/prefixes (for example `XAUUSD.a`); use the exact symbol from MT5 Market Watch and add it to the allowlist.

## Pop-up behavior
The browser console shows an in-page bubble and may show browser notifications after permission is granted. It must be open and connected in that browser. A server cannot force a browser pop-up onto a device whose user has not opened the console.

## Security
Do not expose this app directly to the public internet without HTTPS, user authentication, and a properly secured webhook. The portal's token is for trusted/local use. Never commit `.env`, account passwords, or broker credentials to GitHub. Prefer demo trading until you have verified every setting.
