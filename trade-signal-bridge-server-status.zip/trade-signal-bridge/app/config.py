import os
from dotenv import load_dotenv

load_dotenv()

def _int_env(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default

WEBHOOK_TOKEN = os.getenv("WEBHOOK_TOKEN", "change-me")
ALLOWED_SYMBOLS = {
    s.strip().upper()
    for s in os.getenv("ALLOWED_SYMBOLS", "XAUUSD,EURUSD,GBPUSD").split(",")
    if s.strip()
}
MAX_TRADES_PER_SIGNAL = max(1, _int_env("MAX_TRADES_PER_SIGNAL", 10))
EXECUTION_MODE = os.getenv("EXECUTION_MODE", "simulation").lower()
CONSOLE_MAX_EVENTS = max(20, _int_env("CONSOLE_MAX_EVENTS", 200))
