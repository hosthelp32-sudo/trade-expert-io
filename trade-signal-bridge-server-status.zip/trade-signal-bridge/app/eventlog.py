from collections import deque
from datetime import datetime, timezone
import asyncio
import json
from .config import CONSOLE_MAX_EVENTS

_events = deque(maxlen=CONSOLE_MAX_EVENTS)
_subscribers: set[asyncio.Queue] = set()

def recent_events():
    return list(_events)

async def publish(event: dict):
    event = {"time": datetime.now(timezone.utc).isoformat(), **event}
    _events.append(event)
    print(json.dumps(event, ensure_ascii=False), flush=True)
    stale = []
    for queue in list(_subscribers):
        try:
            queue.put_nowait(event)
        except asyncio.QueueFull:
            stale.append(queue)
    for queue in stale:
        _subscribers.discard(queue)
    return event

def subscribe():
    queue = asyncio.Queue(maxsize=100)
    _subscribers.add(queue)
    return queue

def unsubscribe(queue):
    _subscribers.discard(queue)
