import asyncio
import json
from pathlib import Path
from fastapi import FastAPI, Header, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
from .config import ALLOWED_SYMBOLS, MAX_TRADES_PER_SIGNAL, WEBHOOK_TOKEN
from .eventlog import publish, recent_events, subscribe, unsubscribe
from .executor import TradeExecutor, mt5_connection
from .models import Signal

app = FastAPI(title="Trade Signal Bridge", version="0.1.0")
executor = TradeExecutor()
WEB_DIR = Path(__file__).parent / "static"

@app.get("/api/account")
async def account_status():
    return mt5_connection()

@app.get("/health")
async def health():
    return {"ok": True, "service": "trade-signal-bridge"}

@app.get("/", response_class=HTMLResponse)
async def dashboard():
    return (WEB_DIR / "index.html").read_text(encoding="utf-8")

@app.get("/portal", response_class=HTMLResponse)
async def portal():
    return (WEB_DIR / "portal.html").read_text(encoding="utf-8")

@app.get("/console", response_class=HTMLResponse)
async def console():
    return (WEB_DIR / "console.html").read_text(encoding="utf-8")

@app.get("/api/events")
async def events():
    return recent_events()

@app.post("/webhook/signal")
async def receive_signal(signal: Signal, x_webhook_token: str | None = Header(default=None)):
    if not x_webhook_token or x_webhook_token != WEBHOOK_TOKEN:
        await publish({"level": "ERROR", "status": "REJECTED", "message": "Signal rejected: invalid or missing webhook token."})
        raise HTTPException(status_code=401, detail="Invalid webhook token")

    await publish({
        "level": "INFO",
        "status": "RECEIVED",
        "action": signal.action,
        "symbol": signal.symbol,
        "sl": signal.sl,
        "tp": signal.tp,
        "requested": signal.trades,
        "signal_id": signal.signal_id,
        "message": f"Signal received: {signal.action} {signal.symbol}; requested {signal.trades} trade(s).",
    })

    if signal.symbol not in ALLOWED_SYMBOLS:
        event = await publish({
            "level": "WARNING", "status": "REJECTED", "action": signal.action,
            "symbol": signal.symbol, "requested": signal.trades, "lot_size": signal.lot_size, "executed": 0,
            "message": f"Rejected: {signal.symbol} is not in ALLOWED_SYMBOLS ({', '.join(sorted(ALLOWED_SYMBOLS))}).",
        })
        return {"ok": False, "status": "REJECTED", "reason": event["message"]}

    if signal.trades > MAX_TRADES_PER_SIGNAL:
        event = await publish({
            "level": "WARNING", "status": "REJECTED", "action": signal.action,
            "symbol": signal.symbol, "requested": signal.trades, "lot_size": signal.lot_size, "executed": 0,
            "message": f"Rejected: requested {signal.trades} trades exceeds configured maximum of {MAX_TRADES_PER_SIGNAL}.",
        })
        return {"ok": False, "status": "REJECTED", "reason": event["message"]}

    try:
        result = await executor.execute(signal, signal.trades)
        event = await publish({
            "level": "INFO" if result.status in ("SIMULATED", "CONNECTED_SIMULATION", "EXECUTED") else "WARNING" if result.status in ("PARTIAL", "REJECTED", "NOT_CONNECTED") else "ERROR",
            "status": result.status,
            "action": signal.action,
            "symbol": signal.symbol,
            "sl": signal.sl,
            "tp": signal.tp,
            "requested": signal.trades,
            "executed": result.executed,
            "signal_id": signal.signal_id,
            "message": result.message,
        })
        return {"ok": result.status == "SIMULATED", "status": result.status, "requested": signal.trades,
                "executed": result.executed, "message": event["message"]}
    except Exception as exc:
        await publish({
            "level": "ERROR", "status": "FAILED", "action": signal.action,
            "symbol": signal.symbol, "requested": signal.trades, "lot_size": signal.lot_size, "executed": 0,
            "message": f"Execution failed: {type(exc).__name__}: {exc}",
        })
        raise HTTPException(status_code=500, detail="Execution failed; inspect the console log")



@app.post("/portal/send-signal")
async def portal_send_signal(signal: Signal):
    # Portal-originated signals are broadcast to connected bot consoles.
    await publish({
        "level": "INFO", "status": "RECEIVED", "source": "PORTAL",
        "action": signal.action, "symbol": signal.symbol, "sl": signal.sl,
        "tp": signal.tp, "lot_size": getattr(signal, "lot_size", None),
        "requested": signal.trades, "signal_id": signal.signal_id,
        "message": f"PORTAL SIGNAL: {signal.action} {signal.symbol}; {signal.trades} trade(s).",
    })
    if signal.symbol not in ALLOWED_SYMBOLS:
        event = await publish({
            "level": "WARNING", "status": "REJECTED", "source": "PORTAL",
            "action": signal.action, "symbol": signal.symbol, "requested": signal.trades,
            "executed": 0, "message": f"Rejected: {signal.symbol} is not in ALLOWED_SYMBOLS.",
        })
        return {"ok": False, "status": "REJECTED", "reason": event["message"]}
    if signal.trades > MAX_TRADES_PER_SIGNAL:
        event = await publish({
            "level": "WARNING", "status": "REJECTED", "source": "PORTAL",
            "action": signal.action, "symbol": signal.symbol, "requested": signal.trades,
            "executed": 0, "message": f"Rejected: requested {signal.trades} trades exceeds maximum {MAX_TRADES_PER_SIGNAL}.",
        })
        return {"ok": False, "status": "REJECTED", "reason": event["message"]}
    result = await executor.execute(signal, signal.trades)
    event = await publish({
        "level": "INFO" if result.status in ("SIMULATED", "CONNECTED_SIMULATION", "EXECUTED") else "WARNING" if result.status in ("PARTIAL", "REJECTED", "NOT_CONNECTED") else "ERROR",
        "status": result.status, "source": "PORTAL", "action": signal.action,
        "symbol": signal.symbol, "sl": signal.sl, "tp": signal.tp,
        "requested": signal.trades, "executed": result.executed,
        "message": result.message,
    })
    return {"ok": result.status == "SIMULATED", "status": result.status,
            "requested": signal.trades, "executed": result.executed,
            "message": event["message"]}

@app.websocket("/ws/events")
async def websocket_events(websocket: WebSocket):
    await websocket.accept()
    queue = subscribe()
    try:
        for event in recent_events():
            await websocket.send_text(json.dumps(event))
        while True:
            event = await queue.get()
            await websocket.send_text(json.dumps(event))
    except WebSocketDisconnect:
        pass
    finally:
        unsubscribe(queue)
