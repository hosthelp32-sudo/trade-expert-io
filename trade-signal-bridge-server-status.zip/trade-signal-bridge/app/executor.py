"""MetaTrader 5 adapter.

The MetaTrader5 Python package connects to a running MetaTrader 5 desktop terminal.
Real orders are disabled unless EXECUTION_MODE=live is explicitly configured.
"""
from dataclasses import dataclass
import os
from .config import EXECUTION_MODE

@dataclass
class ExecutionResult:
    status: str
    executed: int
    message: str

def _mt5():
    try:
        import MetaTrader5 as mt5
        return mt5, None
    except Exception as exc:
        return None, f"MetaTrader5 Python package is unavailable: {exc}"

def mt5_connection():
    mt5, error = _mt5()
    if error:
        return {"connected": False, "message": error}
    terminal_path = os.getenv("MT5_TERMINAL_PATH", "").strip() or None
    login = os.getenv("MT5_LOGIN", "").strip()
    password = os.getenv("MT5_PASSWORD", "")
    server = os.getenv("MT5_SERVER", "").strip()
    try:
        kwargs = {}
        if terminal_path:
            kwargs["path"] = terminal_path
        if login:
            kwargs["login"] = int(login)
        if password:
            kwargs["password"] = password
        if server:
            kwargs["server"] = server
        if not mt5.initialize(**kwargs):
            code, detail = mt5.last_error()
            return {"connected": False, "message": f"MT5 initialize failed ({code}): {detail}"}
        account = mt5.account_info()
        terminal = mt5.terminal_info()
        if account is None:
            code, detail = mt5.last_error()
            return {"connected": False, "message": f"MT5 terminal opened but account_info failed ({code}): {detail}"}
        return {
            "connected": True,
            "message": "Connected to MetaTrader 5",
            "login": str(account.login),
            "server": str(account.server),
            "currency": str(account.currency),
            "balance": float(account.balance),
            "equity": float(account.equity),
            "margin_free": float(account.margin_free),
            "trade_allowed": bool(getattr(terminal, "trade_allowed", False)) if terminal else False,
        }
    except Exception as exc:
        return {"connected": False, "message": f"MT5 connection check failed: {type(exc).__name__}: {exc}"}

class TradeExecutor:
    async def execute(self, signal, requested_count: int) -> ExecutionResult:
        if EXECUTION_MODE != "live":
            # Still verify/report connection so the console does not falsely claim
            # an account is disconnected just because live orders are disabled.
            status = mt5_connection()
            if status["connected"]:
                return ExecutionResult(
                    status="CONNECTED_SIMULATION", executed=0,
                    message=f"MetaTrader 5 account connected ({status['login']} @ {status['server']}). Simulation mode: no orders sent."
                )
            return ExecutionResult(status="NOT_CONNECTED", executed=0,
                                   message=f"MetaTrader 5 account not connected: {status['message']}")
        mt5, error = _mt5()
        if error:
            return ExecutionResult("NOT_CONNECTED", 0, error)
        status = mt5_connection()
        if not status["connected"]:
            return ExecutionResult("NOT_CONNECTED", 0, f"MetaTrader 5 account not connected: {status['message']}")
        try:
            symbol = signal.symbol
            if not mt5.symbol_select(symbol, True):
                return ExecutionResult("REJECTED", 0, f"Symbol {symbol} unavailable in this MT5 account/Market Watch.")
            info = mt5.symbol_info(symbol)
            tick = mt5.symbol_info_tick(symbol)
            if info is None or tick is None:
                return ExecutionResult("REJECTED", 0, f"Cannot read symbol information/tick for {symbol}.")
            volume = float(signal.lot_size)
            if volume < info.volume_min or volume > info.volume_max:
                return ExecutionResult("REJECTED", 0, f"Lot size {volume} outside {symbol} broker limits {info.volume_min}–{info.volume_max}.")
            step = float(info.volume_step or 0.01)
            steps = round((volume - float(info.volume_min)) / step)
            normalized = round(float(info.volume_min) + steps * step, 8)
            if abs(normalized - volume) > 1e-8:
                return ExecutionResult("REJECTED", 0, f"Lot size {volume} does not match broker volume step {step} for {symbol}.")
            terminal = mt5.terminal_info()
            account = mt5.account_info()
            if not terminal or not account or not getattr(terminal, "trade_allowed", False) or not getattr(account, "trade_allowed", False):
                return ExecutionResult("REJECTED", 0, "Trading is disabled in the MT5 terminal or account. Enable Algo Trading and verify broker permissions.")
            order_type = mt5.ORDER_TYPE_BUY if signal.action == "BUY" else mt5.ORDER_TYPE_SELL
            price = tick.ask if signal.action == "BUY" else tick.bid
            request_base = {
                "action": mt5.TRADE_ACTION_DEAL, "symbol": symbol, "volume": volume,
                "type": order_type, "price": price, "deviation": int(os.getenv("MT5_DEVIATION_POINTS", "20")),
                "magic": int(os.getenv("MT5_MAGIC", "260615")), "comment": "Trade Signal Bridge",
                "type_time": mt5.ORDER_TIME_GTC,
            }
            if signal.sl is not None:
                request_base["sl"] = float(signal.sl)
            if signal.tp is not None:
                request_base["tp"] = float(signal.tp)
            executed = 0
            failures = []
            for index in range(requested_count):
                # Recheck the account before each order and estimate margin for that order.
                current_account = mt5.account_info()
                current_tick = mt5.symbol_info_tick(symbol)
                if current_account is None or current_tick is None:
                    failures.append(f"Trade {index+1}: account or price feed unavailable.")
                    break
                current_price = current_tick.ask if signal.action == "BUY" else current_tick.bid
                margin = mt5.order_calc_margin(order_type, symbol, volume, current_price)
                if margin is None:
                    failures.append(f"Trade {index+1}: margin calculation failed ({mt5.last_error()}).")
                    break
                if current_account.margin_free < margin:
                    failures.append(f"Trade {index+1}: insufficient free margin; required estimate {margin:.2f}, free {current_account.margin_free:.2f} {current_account.currency}.")
                    break
                req = dict(request_base)
                req["price"] = current_price
                result = mt5.order_send(req)
                if result is None:
                    failures.append(f"Trade {index+1}: order_send failed ({mt5.last_error()}).")
                    break
                if result.retcode not in (mt5.TRADE_RETCODE_DONE, getattr(mt5, "TRADE_RETCODE_DONE_PARTIAL", -1), getattr(mt5, "TRADE_RETCODE_PLACED", -2)):
                    failures.append(f"Trade {index+1}: broker rejected order (retcode={result.retcode}, {result.comment}).")
                    break
                executed += 1
            if executed == requested_count:
                return ExecutionResult("EXECUTED", executed, f"Broker confirmed {executed}/{requested_count} {signal.action} {symbol} trade(s), lot size {volume} each.")
            if executed:
                return ExecutionResult("PARTIAL", executed, f"Broker confirmed {executed}/{requested_count} trade(s). " + " ".join(failures))
            return ExecutionResult("FAILED", 0, f"No trades confirmed. " + " ".join(failures))
        except Exception as exc:
            return ExecutionResult("FAILED", 0, f"MT5 execution error: {type(exc).__name__}: {exc}")
