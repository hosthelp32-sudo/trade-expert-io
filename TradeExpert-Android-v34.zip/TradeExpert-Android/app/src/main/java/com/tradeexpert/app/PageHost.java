package com.tradeexpert.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.io.InputStream;
import java.util.Collections;

/**
 * The one page (the Trade Expert web app). It is created by the background service, so it keeps
 * running (the bot, the console data and the signals) when the app is closed. The app screen shows it
 * while the app is open.
 */
final class PageHost {

    static final String APP_HOST = "appassets.androidplatform.net";
    static final String START_URL = "https://" + APP_HOST + "/ea-app/activate";

    static WebView web;
    private static String bridgeJs = "";
    /** The page's pending file choice (upload / camera), answered by MainActivity. */
    static ValueCallback<Uri[]> pendingFiles;
    static final int REQ_FILE = 41;
    /** True while the app screen shows the page: the web console and bubble must stay hidden. */
    private static volatile boolean onScreen = false;

    private PageHost() {}

    static synchronized WebView get(Context c) {
        if (web != null) return web;
        final Context app = c.getApplicationContext();
        bridgeJs = readAsset(app, "te_bridge.js");

        WebView w = new WebView(app);
        w.setBackgroundColor(0xFF0A0D14);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        w.addJavascriptInterface(new TeBridge(app), "AndroidNotify");
        // install the bridge before the page's scripts run (the page keeps its own reference to fetch)
        try {
            if (!bridgeJs.isEmpty() && WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(w, bridgeJs,
                        Collections.singleton("https://" + APP_HOST));
            }
        } catch (Exception ignored) {
            // the page-start injection below still runs
        }

        // the page's UPLOAD and CAMERA buttons are file inputs: the WebView needs this to open them
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             WebChromeClient.FileChooserParams params) {
                Activity a = MainActivity.current;
                if (pendingFiles != null) pendingFiles.onReceiveValue(null);
                pendingFiles = null;
                if (a == null) {
                    callback.onReceiveValue(null);
                    return true;
                }
                pendingFiles = callback;
                try {
                    a.startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    pendingFiles = null;
                    callback.onReceiveValue(null);
                }
                return true;
            }
        });

        w.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                inject(view, url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                inject(view, url);
            }

            private void inject(WebView view, String url) {
                if (bridgeJs.isEmpty() || url == null) return;
                if (APP_HOST.equals(Uri.parse(url).getHost())) {
                    view.evaluateJavascript(bridgeJs, null);
                    // a fresh page load drops the earlier hide rule: apply it again while the app is on screen
                    if (onScreen) view.evaluateJavascript(visibilityJs(true), null);
                }
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!APP_HOST.equals(uri.getHost())) return null;
                String path = uri.getPath() == null ? "" : uri.getPath();
                try {
                    if (path.contains(".") && path.lastIndexOf('.') > path.lastIndexOf('/')) {
                        return new WebResourceResponse(mimeOf(path), "UTF-8", app.getAssets().open("app" + path));
                    }
                } catch (Exception ignored) {
                    // not a file we have: show the app page
                }
                try {
                    return new WebResourceResponse("text/html", "UTF-8", app.getAssets().open("app/index.html"));
                } catch (Exception e) {
                    return null;
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (APP_HOST.equals(uri.getHost())) return false;
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, uri);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    app.startActivity(i);
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        w.loadUrl(START_URL);
        web = w;
        return w;
    }

    /** Show the page in a parent (the app screen). */
    static void attach(WebView w, ViewGroup parent) {
        detach(w);
        parent.addView(w, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        w.onResume();
        w.resumeTimers();
    }

    /** Take the page off the screen; it keeps running. */
    static void detach(WebView w) {
        ViewParent p = w.getParent();
        if (p instanceof ViewGroup) ((ViewGroup) p).removeView(w);
    }

    /**
     * Press one of the web console's buttons. The web labels are "Stop EA" / "Start EA" (the bot switch)
     * and "Script" (clears the EA console). "live" is an indicator on the web, so it is not pressed.
     */
    static void clickButton(final String which) {
        WebView w = web;
        if (w == null) return;
        final String pattern = "toggle".equals(which) ? "^(stop|start) ea$" : "^script$";
        final String js = "(function(re){var r=new RegExp(re,'i');"
                + "var b=[].slice.call(document.querySelectorAll('button')).find(function(x){"
                + "return r.test(x.textContent.trim());});if(b)b.click();})('" + pattern + "');";
        w.post(() -> w.evaluateJavascript(js, null));
    }

    /** The app on screen (true): the page's own console and bot button are hidden (the app shows the card). */
    /** True while the app screen is open: the floating bubble stays off it (the pop-out console works). */
    static boolean isOnScreen() {
        return onScreen;
    }

    static void setVisible(boolean visible) {
        onScreen = visible;
        BubbleService.onAppScreenChanged();
        WebView w = web;
        if (w == null) return;
        w.post(() -> w.evaluateJavascript(visibilityJs(visible), null));
    }

    /** Script that hides (true) or shows (false) the page's own console and bubble. Safe to run many times. */
    private static String visibilityJs(boolean visible) {
        return "(function(v){var st=document.getElementById('te-hide');"
                + "if(v&&!st){st=document.createElement('style');st.id='te-hide';"
                + "st.textContent='[aria-label=\"Bot console\"],.float-bubble{display:none!important}';"
                + "document.head.appendChild(st);}"
                + "if(!v&&st){st.remove();}window.__teVisible=v;})(" + visible + ");";
    }

    private static String readAsset(Context c, String name) {
        try (InputStream in = c.getAssets().open(name)) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private static String mimeOf(String path) {
        String f = path.toLowerCase();
        if (f.endsWith(".js")) return "application/javascript";
        if (f.endsWith(".css")) return "text/css";
        if (f.endsWith(".png")) return "image/png";
        if (f.endsWith(".jpg") || f.endsWith(".jpeg")) return "image/jpeg";
        if (f.endsWith(".svg")) return "image/svg+xml";
        if (f.endsWith(".json")) return "application/json";
        if (f.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }
}
