package com.tradeexpert.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import androidx.core.app.NotificationCompat;

/**
 * Keeps Trade Expert running in the background and shows a bubble over other apps.
 * Tap the bubble to open the app. The bubble hides while the app is on screen.
 */
public class BubbleService extends Service {

    private static final String CHANNEL = "tx_running";
    private static final int NOTIF_ID = 7;

    static BubbleService instance;
    static volatile boolean appVisible = false;
    static volatile boolean botOn = false;

    private WindowManager wm;
    private ImageView bubble;
    private WindowManager.LayoutParams lp;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        NotificationChannel ch = new NotificationChannel(
                CHANNEL, "Running", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);

        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
        if (!appVisible && botOn) showBubble();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    private Notification buildNotification() {
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Trade Expert")
                .setContentText("Running in the background. Tap to open.")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
                .build();
    }

    /** The bot switch: bubble ON when the bot is ON, OFF when it is OFF. */
    static void setBotOn(Context c, boolean on) {
        botOn = on;
        if (instance == null) {
            if (on) {
                try {
                    c.startForegroundService(new Intent(c, BubbleService.class));
                } catch (Exception ignored) {
                }
            }
            return;
        }
        if (on && !appVisible) {
            instance.showBubble();
        } else {
            instance.hideBubble();
        }
    }

    /** Called by MainActivity when the app comes to the front or goes to the background. */
    static void setAppVisible(boolean visible) {
        appVisible = visible;
        if (instance == null) return;
        if (visible) {
            instance.hideBubble();
        } else {
            instance.showBubble();
        }
    }

    void showBubble() {
        if (bubble != null || !botOn || !Settings.canDrawOverlays(this)) return;

        final float d = getResources().getDisplayMetrics().density;
        final int size = (int) (56 * d);
        final int screenW = getResources().getDisplayMetrics().widthPixels;

        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setColor(0xFF0A0D14);
        ring.setStroke((int) (2 * d), 0xFF3B82F6);

        bubble = new ImageView(this);
        bubble.setBackground(ring);
        bubble.setImageResource(R.drawable.ic_launcher_foreground);
        int pad = (int) (8 * d);
        bubble.setPadding(pad, pad, pad, pad);

        lp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = screenW - size;
        lp.y = (int) (220 * d);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float touchX, touchY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = lp.x;
                        startY = lp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - touchX;
                        float dy = e.getRawY() - touchY;
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true;
                        lp.x = startX + (int) dx;
                        lp.y = startY + (int) dy;
                        wm.updateViewLayout(v, lp);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            openApp();
                        } else {
                            lp.x = (lp.x + size / 2 < screenW / 2) ? 0 : screenW - size;
                            wm.updateViewLayout(v, lp);
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });

        try {
            wm.addView(bubble, lp);
        } catch (Exception e) {
            bubble = null;
        }
    }

    void hideBubble() {
        if (bubble != null) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubble = null;
        }
    }

    private void openApp() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(i);
    }

    @Override
    public void onDestroy() {
        hideBubble();
        instance = null;
        super.onDestroy();
    }
}
