package com.tradeexpert.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * The web bot console, in the app's floating card. Same colours as the web (gold on black),
 * the same top bar (grip, title, round close button), the same EA CONSOLE lines.
 */
class ConsoleCard {

    static final int GOLD = 0xFFF5C518;          // the web app's default accent (GOLD_FALLBACK)
    static final int GOLD_DIM = 0xFFB8900F;
    static final int ERR = 0xFFFF5A5F;

    /** The bot picture, shared with the floating bot button. */
    static volatile Bitmap botBitmap = null;

    final LinearLayout root;
    final View header;
    private final Context ctx;
    private final float d;
    private final TextView titleTv;
    private final LinearLayout logBox;
    private final ScrollView logScroll;
    private final Handler main = new Handler(Looper.getMainLooper());
    private String lastLines = "";
    private String lastImg = "";

    ConsoleCard(Context c, Runnable onClose) {
        ctx = c;
        d = c.getResources().getDisplayMetrics().density;

        root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(gradient(new int[]{0xFF030807, 0xFF010504}, dp(8), alpha(GOLD, 0.67f)));
        root.setClipToOutline(true);
        root.setOutlineProvider(ViewOutlineProvider.BACKGROUND);

        // top bar: grip, title, round close button (drag by this bar)
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(12), 0, dp(10), 0);
        header = bar;

        LinearLayout grip = new LinearLayout(c);
        grip.setOrientation(LinearLayout.VERTICAL);
        grip.setGravity(Gravity.CENTER);
        for (int i = 0; i < 2; i++) {
            View line = new View(c);
            line.setBackground(box(GOLD, 2, 0));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(16), dp(2));
            lp.topMargin = i == 0 ? 0 : dp(3);
            grip.addView(line, lp);
        }
        bar.addView(grip, new LinearLayout.LayoutParams(dp(20), dp(16)));

        titleTv = text("TradeExpert", 11, GOLD, true);
        titleTv.setGravity(Gravity.CENTER);
        titleTv.setSingleLine(true);
        titleTv.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleTv.setLetterSpacing(0.08f);
        titleTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        bar.addView(titleTv, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView close = text("\u2715", 12, GOLD, true);
        close.setGravity(Gravity.CENTER);
        close.setBackground(box(0x99000000, 16, alpha(GOLD, 0.45f)));
        close.setOnClickListener(v -> onClose.run());
        bar.addView(close, new LinearLayout.LayoutParams(dp(30), dp(30)));
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(40)));

        // the web console's buttons (presses the page's own buttons)
        LinearLayout btns = new LinearLayout(c);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setPadding(dp(12), dp(10), dp(12), dp(4));
        btns.addView(button("STOP EA"), btnParams(0));
        btns.addView(button("SCRIPT"), btnParams(6));
        btns.addView(button("+ LIVE"), btnParams(6));
        root.addView(btns, new LinearLayout.LayoutParams(-1, -2));

        logBox = new LinearLayout(c);
        logBox.setOrientation(LinearLayout.VERTICAL);
        logBox.setPadding(dp(12), dp(8), dp(12), dp(10));
        logScroll = new ScrollView(c);
        logScroll.addView(logBox, new ScrollView.LayoutParams(-1, -2));
        root.addView(logScroll, new LinearLayout.LayoutParams(-1, dp(240)));
    }

    private int dp(float v) {
        return (int) (v * d + 0.5f);
    }

    static int alpha(int color, float a) {
        return (color & 0x00FFFFFF) | (((int) (a * 255f)) << 24);
    }

    private GradientDrawable box(int fill, int radiusPx, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radiusPx);
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private GradientDrawable gradient(int[] colors, int radiusPx, int stroke) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors);
        g.setCornerRadius(radiusPx);
        g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        return t;
    }

    private TextView button(String label) {
        TextView b = text(label, 10, GOLD, true);
        b.setGravity(Gravity.CENTER);
        b.setLetterSpacing(0.08f);
        b.setPadding(dp(4), dp(9), dp(4), dp(9));
        b.setBackground(box(alpha(GOLD, 0.08f), dp(6), alpha(GOLD, 0.55f)));
        b.setOnClickListener(v -> MainActivity.clickButton(label));
        return b;
    }

    private LinearLayout.LayoutParams btnParams(int leftDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.leftMargin = dp(leftDp);
        return p;
    }

    /** Fill the card from the page's console data (JSON from te_bridge.js). */
    void update(String json) {
        try {
            JSONObject o = new JSONObject(json);
            String name = o.optString("name", "");
            titleTv.setText(name.isEmpty() ? "TradeExpert" : name.toUpperCase());
            loadImage(o.optString("img", ""));

            JSONArray lines = o.optJSONArray("lines");
            String key = lines == null ? "" : lines.toString();
            if (key.equals(lastLines)) return;
            lastLines = key;
            logBox.removeAllViews();
            if (lines == null || lines.length() == 0) {
                logBox.addView(logLine("> waiting for trades", GOLD));
            } else {
                for (int i = 0; i < lines.length(); i++) {
                    String t = lines.optString(i, "");
                    logBox.addView(logLine("> " + t, t.contains("ERROR") || t.contains("FAIL") ? ERR : GOLD));
                }
            }
            logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
        } catch (Exception ignored) {
        }
    }

    private TextView logLine(String s, int color) {
        TextView t = text(s, 11, color, false);
        t.setTypeface(Typeface.MONOSPACE);
        t.setLineSpacing(0, 1.3f);
        t.setPadding(0, dp(2), 0, dp(2));
        return t;
    }

    private void loadImage(String img) {
        if (img == null || img.isEmpty() || img.equals(lastImg)) return;
        lastImg = img;
        if (img.startsWith("data:image")) {
            try {
                byte[] b = Base64.decode(img.substring(img.indexOf(',') + 1), Base64.DEFAULT);
                setBot(BitmapFactory.decodeByteArray(b, 0, b.length));
            } catch (Exception ignored) {
            }
            return;
        }
        if (!img.startsWith("http")) return;
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(img).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                try (InputStream in = c.getInputStream()) {
                    Bitmap bm = BitmapFactory.decodeStream(in);
                    if (bm != null) main.post(() -> setBot(bm));
                }
            } catch (Exception ignored) {
            }
        }).start();
    }

    private static void setBot(Bitmap bm) {
        botBitmap = bm;
        BubbleService.onBotPicture();
    }
}
