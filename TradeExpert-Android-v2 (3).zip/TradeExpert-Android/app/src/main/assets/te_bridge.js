(function () {
  if (window.__teBridge) return;
  window.__teBridge = true;

  var REST = 'https://zueqlxkqwigjlpgazeiz.supabase.co/rest/v1/';
  var ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp1ZXFseGtxd2lnamxwZ2F6ZWl6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI5NTU1MTgsImV4cCI6MjA4ODUzMTUxOH0.ZH9u7B90bndQVe_VT5cxmU1XCHL-yqfiBhtHn0T3ZfE';

  function ls(k) { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } }

  // who is signed in (Supabase keeps the session in localStorage)
  function session() {
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (k && k.indexOf('auth-token') > -1) {
          var o = JSON.parse(localStorage.getItem(k));
          var t = o.access_token || (o.currentSession && o.currentSession.access_token);
          var u = (o.user && o.user.id) || (o.currentSession && o.currentSession.user && o.currentSession.user.id);
          if (t && u) return { token: t, uid: u };
        }
      }
    } catch (e) {}
    return null;
  }

  // the bot the user picked (ea_bots / ea_active_bot)
  function activeEa() {
    try {
      var bots = JSON.parse(ls('ea_bots') || '[]');
      var b = bots[parseInt(ls('ea_active_bot') || '0', 10) || 0];
      return (b && (b.ea_id || (b.ea && b.ea.id))) || '';
    } catch (e) { return ''; }
  }

  function get(path, s) {
    return fetch(REST + path, { headers: { apikey: ANON, Authorization: 'Bearer ' + s.token } })
      .then(function (r) { return r.ok ? r.json() : []; });
  }

  // 1) Bot ON/OFF: the bot run for this EA is "running" on the server
  var sentBot = null;
  function setBot(on) {
    if (on === sentBot) return;
    sentBot = on;
    try { AndroidNotify.botState(on); } catch (e) {}
  }
  function pollBot() {
    var s = session(), ea = activeEa();
    if (!s || !ea) { setBot(false); return; }
    get('client_bot_runs?select=status&user_id=eq.' + s.uid + '&ea_id=eq.' + ea + '&status=eq.running&limit=1', s)
      .then(function (rows) { setBot(Array.isArray(rows) && rows.length > 0); })
      .catch(function () {});
  }

  // 2) New signals: notify only signals created after the page opened
  var seen = {}, since = new Date().toISOString(), firstRun = true;
  function pollSignals() {
    var s = session(), ea = activeEa();
    if (!s || !ea) return;
    get('signals?select=id,symbol,direction,action,lot_size,entry_price,created_at&ea_id=eq.' + ea +
        '&created_at=gt.' + encodeURIComponent(since) + '&order=created_at.asc&limit=10', s)
      .then(function (rows) {
        if (!Array.isArray(rows)) return;
        rows.forEach(function (r) {
          if (seen[r.id]) return;
          seen[r.id] = 1;
          if (r.created_at && r.created_at > since) since = r.created_at;
          if (firstRun) return;
          var title = ((r.action || 'SIGNAL') + ' ' + (r.symbol || '') + ' ' + (r.direction || '')).trim();
          var body = 'Lot ' + (r.lot_size || '-') + (r.entry_price ? ' \u00b7 @ ' + r.entry_price : '');
          try { AndroidNotify.show(title, body); } catch (e) {}
        });
        firstRun = false;
      })
      .catch(function () {});
  }

  setTimeout(function () { pollBot(); pollSignals(); }, 1500);
  setInterval(pollBot, 5000);
  setInterval(pollSignals, 4000);
})();
