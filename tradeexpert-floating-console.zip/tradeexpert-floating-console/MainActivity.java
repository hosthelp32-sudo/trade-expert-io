package com.tradeexpert.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
import com.tradeexpert.overlay.FloatingConsolePlugin;

public class MainActivity extends BridgeActivity {
  @Override public void onCreate(Bundle savedInstanceState) {
    registerPlugin(FloatingConsolePlugin.class);
    super.onCreate(savedInstanceState);
  }
}
