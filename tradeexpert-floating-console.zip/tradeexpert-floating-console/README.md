# TradeExpert Floating Bot Console (Android)

Shows the bot console over other apps (like chat heads). Android only.

## Setup
1. Clone your GitHub repo, then:
   npm i @capacitor/core @capacitor/cli @capacitor/android
   npx cap init TradeExpert com.tradeexpert.app   (or copy capacitor.config.json)
   npm run build && npx cap add android
2. Copy `android-plugin/src/main/java/com/tradeexpert/overlay/` into
   `android/app/src/main/java/com/tradeexpert/overlay/`
3. Replace `android/app/src/main/java/com/tradeexpert/app/MainActivity.java` with `MainActivity.java`
4. Paste lines from `AndroidManifest-additions.xml` into `android/app/src/main/AndroidManifest.xml`
5. Copy `web/floatingConsole.ts` to `src/lib/floatingConsole.ts`. In BotConsoleContext:
   - on bot start: `popOutConsole(botName)`
   - on every new message: `sendConsoleLine(text)`
   - on bot stop: `closeConsole()`
6. npx cap sync android && cd android && ./gradlew assembleDebug
   APK: android/app/build/outputs/apk/debug/app-debug.apk

First launch asks for "Display over other apps" — turn it on.
Tap the gold TE bubble to open the console, drag bubble or header to move, ✕ to shrink.
