package com.tradeexpert.overlay;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "FloatingConsole")
public class FloatingConsolePlugin extends Plugin {
  @PluginMethod public void hasPermission(PluginCall call) {
    JSObject r = new JSObject(); r.put("granted", Settings.canDrawOverlays(getContext())); call.resolve(r);
  }
  @PluginMethod public void requestPermission(PluginCall call) {
    if (!Settings.canDrawOverlays(getContext())) {
      Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getContext().getPackageName()));
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(i);
    }
    call.resolve();
  }
  @PluginMethod public void show(PluginCall call) {
    if (!Settings.canDrawOverlays(getContext())) { call.reject("Overlay permission not granted"); return; }
    Intent i = new Intent(getContext(), FloatingConsoleService.class);
    i.setAction("SHOW");
    i.putExtra("botName", call.getString("botName", "TradeExpert Bot"));
    i.putExtra("url", call.getString("url", "https://tradeexpertea.com/ea-app/console-overlay"));
    if (Build.VERSION.SDK_INT >= 26) getContext().startForegroundService(i); else getContext().startService(i);
    call.resolve();
  }
  @PluginMethod public void log(PluginCall call) {
    Intent i = new Intent(getContext(), FloatingConsoleService.class);
    i.setAction("LOG"); i.putExtra("message", call.getString("message", ""));
    getContext().startService(i); call.resolve();
  }
  @PluginMethod public void hide(PluginCall call) {
    getContext().stopService(new Intent(getContext(), FloatingConsoleService.class)); call.resolve();
  }
}
