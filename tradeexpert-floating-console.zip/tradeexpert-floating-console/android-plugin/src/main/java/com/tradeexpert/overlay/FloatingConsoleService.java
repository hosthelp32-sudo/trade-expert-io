package com.tradeexpert.overlay;

import android.annotation.SuppressLint;
import android.app.*;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.webkit.WebView;
import android.widget.*;

public class FloatingConsoleService extends Service {
  private WindowManager wm; private View bubble, panel; private TextView feed; private ScrollView scroll;
  private WindowManager.LayoutParams bp, pp; private static final String CH = "te_console";

  @Override public IBinder onBind(Intent i) { return null; }

  @Override public int onStartCommand(Intent intent, int flags, int id) {
    startAsForeground();
    if (wm == null) { wm = (WindowManager) getSystemService(WINDOW_SERVICE); createBubble(); createPanel(); }
    if (intent != null) {
      if ("LOG".equals(intent.getAction())) append(intent.getStringExtra("message"));
      if ("SHOW".equals(intent.getAction())) append("> " + intent.getStringExtra("botName") + " ONLINE");
    }
    return START_STICKY;
  }

  private void startAsForeground() {
    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CH, "Bot console", NotificationManager.IMPORTANCE_LOW));
    Notification n = (Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this))
      .setContentTitle("TradeExpert bot running").setContentText("Bot console is floating")
      .setSmallIcon(android.R.drawable.ic_dialog_info).build();
    if (Build.VERSION.SDK_INT >= 34) startForeground(7, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
    else startForeground(7, n);
  }

  private int type() { return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE; }
  private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

  private GradientDrawable frame(int radius) {
    GradientDrawable g = new GradientDrawable(); g.setColor(Color.BLACK); g.setCornerRadius(dp(radius));
    g.setStroke(dp(2), Color.parseColor("#F5C542")); return g;
  }

  @SuppressLint("ClickableViewAccessibility")
  private void createBubble() {
    TextView b = new TextView(this); b.setText("TE"); b.setTextColor(Color.parseColor("#F5C542"));
    b.setTextSize(18); b.setGravity(Gravity.CENTER); b.setBackground(frame(32)); bubble = b;
    bp = new WindowManager.LayoutParams(dp(60), dp(60), type(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
    bp.gravity = Gravity.TOP | Gravity.START; bp.x = dp(16); bp.y = dp(200);
    attachDrag(bubble, bp, true); wm.addView(bubble, bp);
  }

  private void createPanel() {
    LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
    root.setBackground(frame(14)); root.setPadding(dp(10), dp(8), dp(10), dp(10));
    LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
    TextView title = new TextView(this); title.setText("BOT CONSOLE"); title.setTextColor(Color.parseColor("#F5C542"));
    title.setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
    header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
    TextView close = new TextView(this); close.setText("  ✕  "); close.setTextColor(Color.WHITE);
    close.setOnClickListener(v -> togglePanel(false)); header.addView(close);
    root.addView(header);
    scroll = new ScrollView(this); feed = new TextView(this); feed.setTextColor(Color.parseColor("#39FF88"));
    feed.setTypeface(android.graphics.Typeface.MONOSPACE); feed.setTextSize(12); scroll.addView(feed);
    root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    TextView foot = new TextView(this); foot.setText("Powered by TradeExpert"); foot.setTextColor(Color.GRAY);
    foot.setGravity(Gravity.CENTER); foot.setTextSize(10); root.addView(foot);
    panel = root;
    pp = new WindowManager.LayoutParams(dp(304), dp(420), type(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
    pp.gravity = Gravity.TOP | Gravity.START; pp.x = dp(30); pp.y = dp(120);
    attachDrag(header, pp, false); panel.setVisibility(View.GONE); wm.addView(panel, pp);
  }

  private void togglePanel(boolean open) {
    panel.setVisibility(open ? View.VISIBLE : View.GONE); bubble.setVisibility(open ? View.GONE : View.VISIBLE);
  }

  @SuppressLint("ClickableViewAccessibility")
  private void attachDrag(View handle, WindowManager.LayoutParams lp, boolean tapOpens) {
    final float[] s = new float[4]; final boolean[] moved = {false};
    handle.setOnTouchListener((v, e) -> {
      View target = tapOpens ? bubble : panel;
      switch (e.getAction()) {
        case MotionEvent.ACTION_DOWN: s[0]=lp.x; s[1]=lp.y; s[2]=e.getRawX(); s[3]=e.getRawY(); moved[0]=false; return true;
        case MotionEvent.ACTION_MOVE:
          float dx=e.getRawX()-s[2], dy=e.getRawY()-s[3];
          if (Math.abs(dx)>dp(4)||Math.abs(dy)>dp(4)) moved[0]=true;
          lp.x=(int)(s[0]+dx); lp.y=(int)(s[1]+dy); wm.updateViewLayout(target, lp); return true;
        case MotionEvent.ACTION_UP: if (tapOpens && !moved[0]) togglePanel(true); return true;
      }
      return false;
    });
  }

  private void append(String m) {
    if (feed == null || m == null) return;
    new Handler(Looper.getMainLooper()).post(() -> { feed.append(m + "\n"); scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN)); });
  }

  @Override public void onDestroy() {
    if (wm != null) { if (bubble != null) wm.removeView(bubble); if (panel != null) wm.removeView(panel); }
    super.onDestroy();
  }
}
