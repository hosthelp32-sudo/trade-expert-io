import { registerPlugin, Capacitor } from "@capacitor/core";

export interface FloatingConsolePlugin {
  hasPermission(): Promise<{ granted: boolean }>;
  requestPermission(): Promise<void>;
  show(o: { botName: string }): Promise<void>;
  log(o: { message: string }): Promise<void>;
  hide(): Promise<void>;
}
export const FloatingConsole = registerPlugin<FloatingConsolePlugin>("FloatingConsole");
export const isNativeAndroid = () => Capacitor.getPlatform() === "android";

/** Call when the bot starts. Falls back to the in-app console on web/iPhone. */
export async function popOutConsole(botName: string) {
  if (!isNativeAndroid()) return false;
  const { granted } = await FloatingConsole.hasPermission();
  if (!granted) { await FloatingConsole.requestPermission(); return false; }
  await FloatingConsole.show({ botName });
  return true;
}
/** Mirror each console line to the floating window. */
export const sendConsoleLine = (message: string) => isNativeAndroid() && FloatingConsole.log({ message });
export const closeConsole = () => isNativeAndroid() && FloatingConsole.hide();
