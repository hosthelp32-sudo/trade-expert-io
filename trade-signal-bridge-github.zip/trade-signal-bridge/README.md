# Trade Signal Bridge

A starter self-hostable webhook service for forwarding chart-scanner signals to a bot and showing clear execution status in a live console.

## What it does
- Accepts `BUY` / `SELL` signals from a chart scanner using `POST /webhook/signal`.
- Validates allowed symbols and the maximum number of trades per signal.
- Logs every received signal and result to the terminal and the web console.
- Shows rejected signals and broker/executor errors instead of silently failing.
- Includes a browser console at `/` and a pop-out console at `/console`.
- Ships in **simulation mode** by default. It does not place real-money trades until you connect and implement your broker adapter.

## Quick start
Requires Python 3.10+.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Open `http://127.0.0.1:8000`. The live console is at `http://127.0.0.1:8000/console`.

## Send a test signal
```bash
curl -X POST http://127.0.0.1:8000/webhook/signal \
  -H "Content-Type: application/json" \
  -H "X-Webhook-Token: change-me" \
  -d '{
    "action": "BUY",
    "symbol": "XAUUSD",
    "sl": 2300.0,
    "tp": 2320.0,
    "trades": 10
  }'
```

Expected result in simulation mode: the console reports that the signal was received and validated, then says it was **SIMULATED**, not executed at a broker.

## Chart scanner integration
Configure your scanner's webhook URL as `https://YOUR_HOST/webhook/signal` and send JSON with:
- `action`: `BUY` or `SELL`
- `symbol`: e.g. `XAUUSD`
- `sl`: stop-loss price (optional)
- `tp`: take-profit price (optional)
- `trades`: requested trade count (optional; defaults to 1)

Set the same `WEBHOOK_TOKEN` in the scanner header `X-Webhook-Token`. If your scanner cannot set headers, use a reverse proxy or adapt authentication before exposing this service publicly.

## Configuration
Copy `.env.example` to `.env` and adjust:
- `WEBHOOK_TOKEN`: shared secret for incoming signals.
- `ALLOWED_SYMBOLS`: comma-separated allowlist.
- `MAX_TRADES_PER_SIGNAL`: hard upper limit on requested trade count.
- `EXECUTION_MODE`: `simulation` by default.
- `CONSOLE_MAX_EVENTS`: number of recent events retained in memory.

## Connecting a real trading terminal
The included executor is intentionally simulation-only. To execute real trades, implement `TradeExecutor` in `app/executor.py` for your broker/terminal API and add its credentials through environment variables or a secret manager. Ensure it checks free margin, symbol availability, volume rules, market status, and broker responses. Report each rejected/failed order with its actual reason (for example, insufficient margin). Do not hard-code credentials or commit `.env`.

## Important
This repository does **not** connect to a broker or place real trades out of the box. “10 trades requested” is not the same as “10 trades executed”; the console must report the actual confirmed count. Test with a demo account before enabling live execution.
