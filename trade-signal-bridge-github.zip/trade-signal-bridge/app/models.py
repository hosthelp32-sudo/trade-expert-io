from typing import Literal, Optional
from pydantic import BaseModel, Field, field_validator

class Signal(BaseModel):
    action: Literal["BUY", "SELL"]
    symbol: str = Field(min_length=1, max_length=32)
    sl: Optional[float] = None
    tp: Optional[float] = None
    trades: int = Field(default=1, ge=1, le=1000)
    signal_id: Optional[str] = Field(default=None, max_length=128)

    @field_validator("symbol")
    @classmethod
    def normalize_symbol(cls, value: str) -> str:
        return value.strip().upper()
