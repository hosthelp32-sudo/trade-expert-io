from dataclasses import dataclass
from .config import EXECUTION_MODE

@dataclass
class ExecutionResult:
    status: str
    executed: int
    message: str

class TradeExecutor:
    async def execute(self, signal, requested_count: int) -> ExecutionResult:
        # Safe default: never places a real order.
        if EXECUTION_MODE != "simulation":
            return ExecutionResult(
                status="ERROR",
                executed=0,
                message=(
                    f"EXECUTION_MODE={EXECUTION_MODE!r} is not supported by the "
                    "built-in executor. Connect a broker adapter before live trading."
                ),
            )
        return ExecutionResult(
            status="SIMULATED",
            executed=0,
            message=(
                f"Signal validated; {requested_count} trade(s) requested. "
                "Simulation only: no broker orders were placed."
            ),
        )
