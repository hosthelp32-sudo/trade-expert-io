package com.tradeexpert.app;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.SweepGradient;
import android.os.SystemClock;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;

import org.json.JSONObject;

/**
 * The bot display and console card over the app and over other apps.
 * Bot ON: the console card pops out at once. Its ✕ closes it back to the bubble (bottom right).
 * Tapping the bubble pops the console card out. Bot OFF: both disappear.
 */
public class BubbleService extends Service {

    private static final String CHANNEL = "tx_running";
    private static final int NOTIF_ID = 7;
    static final int UNSET = Integer.MIN_VALUE;

    static BubbleService instance;
    static volatile boolean botOn = false;
    static volatile boolean consoleOpen = false;
    /** A trade was placed from the chart scanner: the console shows it even when the bot is off. */
    static volatile boolean tradeShown = false;
    static volatile String consoleJson = "";
    /** Where the card was last dragged to (kept while the bot is toggled). */
    static volatile int cardX = UNSET, cardY = UNSET;
    /** Where the bubble was last moved to (kept when the card opens and closes). */
    static volatile int bubbleX = UNSET, bubbleY = UNSET;
    /** The two colours of the bubble's moving ring: the app's colour and its second colour. */
    static volatile int ringA = ConsoleCard.DEFAULT_ACCENT, ringB = 0xFF8FE5C8;

    /** The trades were placed after EXECUTE TRADE: the console pops out and writes the signal and the count. */
    static void setTradeExecuted(final String json) {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (instance == null) return;
            tradeShown = true;
            consoleOpen = true;
            instance.refresh();
            if (instance.card != null) {
                try {
                    instance.card.showTrade(new JSONObject(json));
                } catch (Exception ignored) {
                }
            }
        });
    }

    /** Called by the console card when the app's colour changes. */
    static void setRingColours(int a, int b) {
        ringA = a;
        ringB = b;
    }

    /** The bubble's ring: a sweep of the app's colours that turns round and changes colour. */
    static final class RingView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final ValueAnimator spin;
        private float angle = 0f;
        private final float stroke;

        RingView(Context c, float strokePx) {
            super(c);
            stroke = strokePx;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(strokePx);
            paint.setStrokeCap(Paint.Cap.ROUND);
            spin = ValueAnimator.ofFloat(0f, 360f);
            spin.setDuration(2600);
            spin.setRepeatCount(ValueAnimator.INFINITE);
            spin.setInterpolator(new android.view.animation.LinearInterpolator());
            spin.addUpdateListener(a -> {
                angle = (float) a.getAnimatedValue();
                invalidate();
            });
        }

        void start() {
            if (!spin.isStarted()) spin.start();
        }

        void stop() {
            spin.cancel();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float r = Math.min(cx, cy) - stroke;
            // the colours slide from one to the other and back, every few seconds
            double t = (Math.sin(SystemClock.uptimeMillis() / 1000.0 * 2 * Math.PI / 4) + 1) / 2;
            int mid = ConsoleCard.mix(ringA, ringB, (float) t);
            SweepGradient sg = new SweepGradient(cx, cy, new int[]{ringA, mid, ringB, ringA}, null);
            Matrix m = new Matrix();
            m.postRotate(angle, cx, cy);
            sg.setLocalMatrix(m);
            paint.setShader(sg);
            canvas.drawCircle(cx, cy, r, paint);
        }
    }

    private WindowManager wm;
    private FrameLayout bubble;
    private WindowManager.LayoutParams bubbleLp;
    private ObjectAnimator pulse;
    private ImageView bubbleImg;
    private RingView ringView;
    private ConsoleCard card;
    private WindowManager.LayoutParams cardLp;
    private android.os.PowerManager.WakeLock wakeLock;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        NotificationChannel ch = new NotificationChannel(CHANNEL, "Running", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.app_logo)
                .setContentTitle("Trade Expert")
                .setContentText("Running in the background. Tap to open.")
                .setOngoing(true)
                .setContentIntent(open)
                .build();
        startForeground(NOTIF_ID, n);

        // the page runs here, in the background, so the bot and the console keep working
        try {
            PageHost.get(this);
        } catch (Exception e) {
            Log.e("TradeExpert", "page not started", e);
        }
        try {
            android.os.PowerManager pm = (android.os.PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "tradeexpert:page");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire();
        } catch (Exception e) {
            Log.e("TradeExpert", "wake lock not held", e);
        }

        refresh();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    /** The web bot switch (called from the page's background thread). */
    static void setBotOn(final Context c, final boolean on) {
        new Handler(Looper.getMainLooper()).post(() -> {
            botOn = on;
            consoleOpen = on;   // bot ON: the console pops out at once
            tradeShown = false;
            if (instance == null) {
                if (on) c.startForegroundService(new Intent(c, BubbleService.class));
                return;
            }
            instance.refresh();
        });
    }

    /** The web console's name, picture and lines. */
    static void setConsole(final String json) {
        try {
            // the bot picture (the bubble and the card both show it)
            BotPicture.load(new JSONObject(json).optString("img", ""));
        } catch (Exception ignored) {
        }
        new Handler(Looper.getMainLooper()).post(() -> {
            consoleJson = json;
            if (instance != null && instance.card != null) instance.card.update(json);
        });
    }

    /** The bot picture arrived. */
    static void onBotPicture() {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (instance != null) {
                instance.applyPicture();
                if (instance.card != null) instance.card.refreshPicture();
            }
        });
    }

    /** Console card open: the card. Closed: the bubble. Bot OFF: nothing. */
    void refresh() {
        if (!botOn && !tradeShown) {
            hideCard();
            removeBubble();
            return;
        }
        if (consoleOpen) {
            removeBubble();
            showCard();
        } else {
            hideCard();
            if (botOn) addBubble();
            else removeBubble();
        }
    }

    private void showCard() {
        if (card != null || !Settings.canDrawOverlays(this)) return;
        float d = getResources().getDisplayMetrics().density;
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int screenH = getResources().getDisplayMetrics().heightPixels;
        int w = Math.min((int) (285 * d), screenW - (int) (24 * d));

        card = new ConsoleCard(this, () -> {
            consoleOpen = false;
            tradeShown = false;
            refresh();
        });
        cardLp = new WindowManager.LayoutParams(
                w, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        cardLp.gravity = Gravity.TOP | Gravity.START;
        cardLp.x = cardX != UNSET ? cardX : (screenW - w) / 2;
        cardLp.y = cardY != UNSET ? cardY : (int) (screenH * 0.14f);
        keepOnScreen(cardLp, w, screenW, screenH);

        // drag by the header; the place is kept
        final ConsoleCard thisCard = card;
        card.header.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = cardLp.x;
                        sy = cardLp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        cardLp.x = sx + (int) (e.getRawX() - tx);
                        cardLp.y = sy + (int) (e.getRawY() - ty);
                        keepOnScreen(cardLp, cardLp.width,
                                getResources().getDisplayMetrics().widthPixels,
                                getResources().getDisplayMetrics().heightPixels);
                        try {
                            wm.updateViewLayout(thisCard.root, cardLp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        cardX = cardLp.x;
                        cardY = cardLp.y;
                        return true;
                    default:
                        return true;
                }
            }
        });

        try {
            wm.addView(card.root, cardLp);
            card.update(consoleJson);
        } catch (Exception e) {
            Log.e("TradeExpert", "console not shown", e);
            card = null;
        }
    }

    /** Keep the card inside the screen (its width and top edge), so it can always be dragged back. */
    private static void keepOnScreen(WindowManager.LayoutParams lp, int w, int screenW, int screenH) {
        int maxX = Math.max(0, screenW - w);
        lp.x = Math.max(0, Math.min(lp.x, maxX));
        lp.y = Math.max(0, Math.min(lp.y, Math.max(0, screenH - 120)));
    }

    private void hideCard() {
        if (card != null) {
            card.stop();
            try {
                wm.removeView(card.root);
            } catch (Exception ignored) {
            }
            card = null;
        }
    }

    private void addBubble() {
        if (bubble != null || !Settings.canDrawOverlays(this)) return;
        float d = getResources().getDisplayMetrics().density;
        int size = (int) (48 * d);
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int screenH = getResources().getDisplayMetrics().heightPixels;
        int ring = (int) (5 * d);

        bubble = new FrameLayout(this);
        ringView = new RingView(this, (int) (3 * d));
        bubble.addView(ringView, new FrameLayout.LayoutParams(size, size));

        bubbleImg = new ImageView(this);
        bubbleImg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bubbleImg.setClipToOutline(true);
        bubbleImg.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        GradientDrawable imgBg = new GradientDrawable();
        imgBg.setShape(GradientDrawable.OVAL);
        imgBg.setColor(0xFF030807);
        bubbleImg.setBackground(imgBg);
        bubbleImg.setPadding(ring, ring, ring, ring);
        applyPicture();
        bubble.addView(bubbleImg, new FrameLayout.LayoutParams(size, size));

        View dot = new View(this);
        GradientDrawable dg = new GradientDrawable();
        dg.setShape(GradientDrawable.OVAL);
        dg.setColor(ConsoleCard.FRAME);
        dg.setStroke((int) (2 * d), 0xFF0A0D14);
        dot.setBackground(dg);
        int ds = (int) (11 * d);
        bubble.addView(dot, new FrameLayout.LayoutParams(ds, ds, Gravity.BOTTOM | Gravity.END));
        pulse = ObjectAnimator.ofFloat(dot, View.ALPHA, 1f, 0.35f, 1f);
        pulse.setDuration(1600);
        pulse.setRepeatCount(ObjectAnimator.INFINITE);
        pulse.setInterpolator(new LinearInterpolator());

        bubbleLp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        // bottom right, above the navigation bar
        bubbleLp.x = bubbleX != UNSET ? bubbleX : screenW - size - (int) (12 * d);
        bubbleLp.y = bubbleY != UNSET ? bubbleY : screenH - size - (int) (120 * d);
        keepOnScreen(bubbleLp, size, screenW, screenH);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float touchX, touchY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = bubbleLp.x;
                        startY = bubbleLp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - touchX;
                        float dy = e.getRawY() - touchY;
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true;
                        bubbleLp.x = startX + (int) dx;
                        bubbleLp.y = startY + (int) dy;
                        keepOnScreen(bubbleLp, size, screenW, screenH);
                        try {
                            wm.updateViewLayout(bubble, bubbleLp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            // tap: the console card pops out
                            consoleOpen = true;
                            refresh();
                        } else {
                            // let go: it stays where it was left, at the nearest side of the screen
                            bubbleLp.x = (bubbleLp.x + size / 2 < screenW / 2) ? 0 : screenW - size;
                            keepOnScreen(bubbleLp, size, screenW, screenH);
                            bubbleX = bubbleLp.x;
                            bubbleY = bubbleLp.y;
                            try {
                                wm.updateViewLayout(bubble, bubbleLp);
                            } catch (Exception ignored) {
                            }
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });

        try {
            wm.addView(bubble, bubbleLp);
            pulse.start();
            ringView.start();
        } catch (Exception e) {
            Log.e("TradeExpert", "bubble not shown", e);
            bubble = null;
        }
    }

    private void applyPicture() {
        if (bubbleImg == null) return;
        Bitmap bm = BotPicture.bitmap;
        if (bm != null) {
            bubbleImg.setImageBitmap(bm);
        } else {
            bubbleImg.setImageResource(R.drawable.app_logo);
        }
    }

    private void removeBubble() {
        if (pulse != null) pulse.cancel();
        if (ringView != null) {
            ringView.stop();
            ringView = null;
        }
        if (bubble != null) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubble = null;
        }
    }

    @Override
    public void onDestroy() {
        hideCard();
        removeBubble();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        instance = null;
        super.onDestroy();
    }
}
