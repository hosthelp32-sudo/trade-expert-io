package com.tradeexpert.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.webkit.WebView;

/**
 * Trade Expert on screen. The page is the same one the floating display shows (PageHost).
 */
public class MainActivity extends Activity {

    private FrameLayout container;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        container = new FrameLayout(this);
        container.setBackgroundColor(Color.parseColor("#FF0A0D14"));
        setContentView(container);
        PageHost.attach(PageHost.get(this), container);

        // the floating display over other apps: ask for permission once, then start the service
        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }
        startForegroundService(new Intent(this, BubbleService.class));
    }

    @Override
    protected void onStart() {
        super.onStart();
        WebView w = PageHost.get(this);
        if (w.getParent() != container) PageHost.attach(w, container);
        PageHost.setVisible(true);
        BubbleService.setAppVisible(true);
    }

    @Override
    protected void onStop() {
        super.onStop();
        PageHost.setVisible(false);
        BubbleService.setAppVisible(false);
    }

    @Override
    public void onBackPressed() {
        WebView w = PageHost.web;
        if (w != null && w.canGoBack()) {
            w.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        // the page stays alive for the service (the bot keeps running); only the screen lets go of it
        if (PageHost.web != null) PageHost.detach(PageHost.web);
        super.onDestroy();
    }
}
