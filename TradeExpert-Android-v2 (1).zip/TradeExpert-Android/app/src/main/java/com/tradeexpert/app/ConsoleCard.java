package com.tradeexpert.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * The bot console as a card over other apps and inside the app.
 * It shows what the web console shows: the bot, its status, the buttons and the EA CONSOLE lines.
 */
class ConsoleCard {

    static final int BG = 0xF20A0D14;      // app background (slightly see-through)
    static final int BLUE = 0xFF3B82F6;    // app blue
    static final int BLUE_BRIGHT = 0xFF7AA2FF;
    static final int RED = 0xFFE53935;
    static final int GREEN = 0xFF2ECC71;
    static final int DIM = 0xFF8891A7;

    final LinearLayout root;
    final View header;
    private final Context ctx;
    private final float d;
    private final ImageView avatar;
    private final TextView nameTv, stateTv;
    private final LinearLayout logBox;
    private final ScrollView logScroll;
    private final Handler main = new Handler(Looper.getMainLooper());
    private String lastLines = "";
    private String lastImg = "";

    ConsoleCard(Context c, Runnable onClose) {
        ctx = c;
        d = c.getResources().getDisplayMetrics().density;

        root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(12));
        root.setBackground(box(BG, 18, alpha(BLUE, 0.45f)));
        root.setClipToOutline(true);
        root.setOutlineProvider(ViewOutlineProvider.BACKGROUND);

        // header: bot picture, name and status, close
        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        header = head;

        avatar = new ImageView(c);
        avatar.setBackground(box(0xFF111111, 40, alpha(BLUE, 0.6f)));
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatar.setClipToOutline(true);
        avatar.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        avatar.setImageResource(R.drawable.app_logo);
        head.addView(avatar, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        nameTv = text("TradeExpert", 14, 0xFFFFFFFF, true);
        nameTv.setSingleLine(true);
        nameTv.setEllipsize(android.text.TextUtils.TruncateAt.END);
        stateTv = text("\u25CF ACTIVATED", 10, BLUE_BRIGHT, true);
        stateTv.setLetterSpacing(0.12f);
        col.addView(nameTv);
        col.addView(stateTv);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
        cp.leftMargin = dp(10);
        head.addView(col, cp);

        TextView x = text("\u2715", 14, DIM, true);
        x.setGravity(Gravity.CENTER);
        x.setBackground(box(0x14FFFFFF, 10, 0));
        x.setOnClickListener(v -> onClose.run());
        head.addView(x, new LinearLayout.LayoutParams(dp(30), dp(30)));
        root.addView(head, new LinearLayout.LayoutParams(-1, -2));

        // buttons: the same as the web card
        LinearLayout btns = new LinearLayout(c);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.addView(button("STOP EA", RED), btnParams(0));
        btns.addView(button("SCRIPT", BLUE), btnParams(6));
        btns.addView(button("+ LIVE", BLUE), btnParams(6));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(12);
        root.addView(btns, bp);

        // EA CONSOLE
        LinearLayout labelRow = new LinearLayout(c);
        labelRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView l1 = text("EA CONSOLE", 10, BLUE_BRIGHT, true);
        l1.setLetterSpacing(0.14f);
        labelRow.addView(l1, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView l2 = text("SCRIPT", 10, DIM, true);
        labelRow.addView(l2);
        LinearLayout.LayoutParams lr = new LinearLayout.LayoutParams(-1, -2);
        lr.topMargin = dp(14);
        root.addView(labelRow, lr);

        logBox = new LinearLayout(c);
        logBox.setOrientation(LinearLayout.VERTICAL);
        logBox.setPadding(dp(10), dp(8), dp(10), dp(8));
        logBox.setBackground(box(0xAA050812, 12, alpha(BLUE, 0.2f)));
        logScroll = new ScrollView(c);
        logScroll.addView(logBox, new ScrollView.LayoutParams(-1, -2));
        root.addView(logScroll, new LinearLayout.LayoutParams(-1, dp(220)));
    }

    private int dp(float v) {
        return (int) (v * d + 0.5f);
    }

    private static int alpha(int color, float a) {
        return (color & 0x00FFFFFF) | (((int) (a * 255f)) << 24);
    }

    private GradientDrawable box(int fill, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(String label, int color) {
        TextView b = text(label, 10, color, true);
        b.setGravity(Gravity.CENTER);
        b.setLetterSpacing(0.08f);
        b.setPadding(dp(4), dp(9), dp(4), dp(9));
        b.setBackground(box(alpha(color, 0.10f), 10, alpha(color, 0.55f)));
        b.setOnClickListener(v -> {
            String lbl = label.trim();
            // the web buttons: STOP EA, SCRIPT, + LIVE (the same text as on the page)
            MainActivity.clickButton(lbl);
        });
        return b;
    }

    private LinearLayout.LayoutParams btnParams(int leftDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.leftMargin = dp(leftDp);
        return p;
    }

    /** Fill the card from the page's console data (JSON from te_bridge.js). */
    void update(String json) {
        try {
            JSONObject o = new JSONObject(json);
            nameTv.setText(o.optString("name", "TradeExpert"));
            boolean running = o.optBoolean("running", false);
            stateTv.setText("\u25CF " + (running ? "ACTIVATED" : "STANDBY"));
            stateTv.setTextColor(running ? BLUE_BRIGHT : DIM);
            loadImage(o.optString("img", ""));

            JSONArray lines = o.optJSONArray("lines");
            String key = lines == null ? "" : lines.toString();
            if (key.equals(lastLines)) return;
            lastLines = key;
            logBox.removeAllViews();
            if (lines == null || lines.length() == 0) {
                logBox.addView(logLine("Waiting for the bot...", DIM));
            } else {
                for (int i = 0; i < lines.length(); i++) {
                    String t = lines.optString(i, "");
                    logBox.addView(logLine("> " + t, t.contains("ERROR") || t.contains("FAIL") ? RED : BLUE_BRIGHT));
                }
            }
            logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
        } catch (Exception ignored) {
        }
    }

    private TextView logLine(String s, int color) {
        TextView t = text(s, 11, color, false);
        t.setTypeface(Typeface.MONOSPACE);
        t.setPadding(0, dp(2), 0, dp(2));
        return t;
    }

    private void loadImage(String img) {
        if (img == null || img.isEmpty() || img.equals(lastImg)) return;
        lastImg = img;
        if (img.startsWith("data:image")) {
            try {
                byte[] b = Base64.decode(img.substring(img.indexOf(',') + 1), Base64.DEFAULT);
                avatar.setImageBitmap(BitmapFactory.decodeByteArray(b, 0, b.length));
            } catch (Exception ignored) {
            }
            return;
        }
        if (!img.startsWith("http")) return;
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(img).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                try (InputStream in = c.getInputStream()) {
                    Bitmap bm = BitmapFactory.decodeStream(in);
                    if (bm != null) main.post(() -> avatar.setImageBitmap(bm));
                }
            } catch (Exception ignored) {
            }
        }).start();
    }
}
