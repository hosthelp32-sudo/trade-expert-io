package com.tradeexpert.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.webkit.JavascriptInterface;

/** What the web page reports to the app: the bot switch (ON/OFF) and new signals. */
public class TeBridge {

    static final String CHANNEL = "te_signals";
    private final Context ctx;
    private int nextId = 2000;

    public TeBridge(Context c) {
        ctx = c.getApplicationContext();
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Signals", NotificationManager.IMPORTANCE_HIGH);
        ch.enableVibration(true);
        ctx.getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    /** The bot switch: the bubble shows when the bot is ON and hides when it is OFF. */
    @JavascriptInterface
    public void botState(boolean on) {
        BubbleService.setBotOn(ctx, on);
    }

    /** The bot console from the page (name, picture, lines), shown in the app's card. */
    @JavascriptInterface
    public void consoleData(String json) {
        BubbleService.setConsole(json);
    }

    /** A new signal: show it as a notification. */
    @JavascriptInterface
    public void show(String title, String body) {
        try {
            PendingIntent pi = PendingIntent.getActivity(ctx, 0,
                    new Intent(ctx, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(ctx, CHANNEL)
                    .setSmallIcon(R.drawable.ic_notif)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new Notification.BigTextStyle().bigText(body))
                    .setCategory(Notification.CATEGORY_MESSAGE)
                    .setAutoCancel(true)
                    .setContentIntent(pi)
                    .build();
            ctx.getSystemService(NotificationManager.class).notify(nextId++, n);
        } catch (Exception ignored) {
        }
    }
}
