(function () {
  if (window.__teBridge) return;
  window.__teBridge = true;

  var REST = 'https://zueqlxkqwigjlpgazeiz.supabase.co/rest/v1/';
  var ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp1ZXFseGtxd2lnamxwZ2F6ZWl6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI5NTU1MTgsImV4cCI6MjA4ODUzMTUxOH0.ZH9u7B90bndQVe_VT5cxmU1XCHL-yqfiBhtHn0T3ZfE';

  function ls(k) { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } }

  function session() {
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (k && k.indexOf('auth-token') > -1) {
          var o = JSON.parse(localStorage.getItem(k));
          var t = o.access_token || (o.currentSession && o.currentSession.access_token);
          var u = (o.user && o.user.id) || (o.currentSession && o.currentSession.user && o.currentSession.user.id);
          if (t && u) return { token: t, uid: u };
        }
      }
    } catch (e) {}
    return null;
  }

  function activeEa() {
    try {
      var bots = JSON.parse(ls('ea_bots') || '[]');
      var b = bots[parseInt(ls('ea_active_bot') || '0', 10) || 0];
      return (b && (b.ea_id || (b.ea && b.ea.id))) || '';
    } catch (e) { return ''; }
  }

  function get(path, s) {
    return fetch(REST + path, { headers: { apikey: ANON, Authorization: 'Bearer ' + s.token } })
      .then(function (r) { return r.ok ? r.json() : []; });
  }

  var lastReason = '';
  function report(reason) {
    if (reason === lastReason) return;
    lastReason = reason;
    try { AndroidNotify.status(reason); } catch (e) {}
  }

  // 1) Bot ON/OFF = the page's own bot switch (saved as "1" / "0" in ea_bot_running)
  var sentBot = null;
  function setBot(on) {
    if (on === sentBot) return;
    sentBot = on;
    try { AndroidNotify.botState(on); } catch (e) {}
  }
  function pollBot() {
    var on = ls('ea_bot_running') === '1';
    report(on ? 'bot ON' : 'bot OFF');
    setBot(on);
  }

  // 2) The web console: its lines, name and picture, for the app's card over other apps
  var lastImg = '', lastOpenTry = 0, lastConsole = '';
  function botInfo() {
    try {
      var bots = JSON.parse(ls('ea_bots') || '[]');
      var b = bots[parseInt(ls('ea_active_bot') || '0', 10) || 0] || {};
      var ea = b.ea || {};
      var img = ea.image_url || ea.image || ea.logo_url || ea.picture || ea.img || b.image_url || b.img || b.picture || '';
      return { name: String(ea.name || b.name || 'BOT'), img: String(img || '') };
    } catch (e) { return { name: 'BOT', img: '' }; }
  }
  function pageImage() {
    var ims = document.querySelectorAll('img.object-cover');
    for (var i = 0; i < ims.length; i++) {
      var src = String(ims[i].src || '');
      if (src && src.indexOf('data:') !== 0 && ims[i].width > 120) return src;
    }
    return '';
  }
  function reportConsole() {
    try {
      var info = botInfo();
      if (!info.img) info.img = pageImage();
      var root = document.querySelector('[aria-label="Bot console"]');
      var lines = [];
      if (!root && sentBot === true) {
        // the web console is closed: open it (the page's own bot button) so the card gets its lines
        var now = Date.now();
        if (now - lastOpenTry > 4000) {
          lastOpenTry = now;
          var fb = document.querySelector('.float-bubble');
          if (fb && String(fb.className).indexOf('docked') < 0) fb.click();
        }
      }
      if (root) {
        var els = root.querySelectorAll('div[style*="JetBrains Mono"], div[class*="my-2 flex items-center gap-2"]');
        for (var i = 0; i < els.length; i++) {
          var el = els[i];
          var raw = String(el.textContent || '');
          if (String(el.className).indexOf('my-2 flex items-center gap-2') > -1) {
            var label = raw.replace(/\s+/g, ' ').trim();
            if (label) lines.push({ t: label, sep: true });
            continue;
          }
          var bare = raw.charAt(0) !== '>';
          var t = raw.replace(/^>\s*/, '').trim();
          if (t) lines.push({ t: t, b: bare });
        }
        if (lines.length > 40) lines = lines.slice(-40);
      }
      var data = JSON.stringify({ name: info.name, img: info.img, running: sentBot === true, lines: lines });
      if (data !== lastConsole) {
        lastConsole = data;
        AndroidNotify.consoleData(data);
      }
    } catch (e) {}
  }

  // 4) New signals: notify only signals created after the page opened
  var seen = {}, since = new Date().toISOString(), firstRun = true;
  function pollSignals() {
    var s = session(), ea = activeEa();
    if (!s || !ea) return;
    get('signals?select=id,symbol,direction,action,lot_size,entry_price,created_at&ea_id=eq.' + ea +
        '&created_at=gt.' + encodeURIComponent(since) + '&order=created_at.asc&limit=10', s)
      .then(function (rows) {
        if (!Array.isArray(rows)) return;
        rows.forEach(function (r) {
          if (seen[r.id]) return;
          seen[r.id] = 1;
          if (r.created_at && r.created_at > since) since = r.created_at;
          if (firstRun) return;
          var title = ((r.action || 'SIGNAL') + ' ' + (r.symbol || '') + ' ' + (r.direction || '')).trim();
          var body = 'Lot ' + (r.lot_size || '-') + (r.entry_price ? ' \u00b7 @ ' + r.entry_price : '');
          try { AndroidNotify.show(title, body); } catch (e) {}
        });
        firstRun = false;
      })
      .catch(function () {});
  }

  report('page loaded');
  setTimeout(function () { pollBot(); pollSignals(); }, 500);
  setInterval(pollBot, 1000);
  setInterval(reportConsole, 700);
  setInterval(pollSignals, 4000);
})();
