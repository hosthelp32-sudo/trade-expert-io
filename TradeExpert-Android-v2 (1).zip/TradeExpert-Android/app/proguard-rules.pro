# No custom rules needed for the WebView wrapper.
