package com.tradeexpert.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * The web console over other apps: the bot name and picture, the STOP EA / SCRIPT / LIVE buttons,
 * and the EA CONSOLE lines (the same lines and order as the web console).
 */
class ConsoleCard {

    static final int FRAME = 0xFF2E6AA8;
    static final int HEAD = 0xFF8DB7E8;
    static final int BTN = 0xFF8CB9EE;
    static final int BTN_TEXT = 0xFF0B1B33;
    static final int LOG = 0xFF8FC8FF;
    static final int BARE = 0xFFD9ECFF;
    static final int ACTIVE = 0xFFDDEBFF;
    static final String SEP = "\u0001";

    final FrameLayout root;
    final View header;
    private final Context ctx;
    private final float d;
    private final TextView nameTv, pillTv;
    private final TextView stopBtn;
    private final ImageView picture;
    private final LinearLayout logBox;
    private final ScrollView logScroll;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<View> rows = new ArrayList<>();
    private final List<Boolean> rowIsSep = new ArrayList<>();
    private String lastKey = "";
    private boolean atBottom = true;
    private String lastImg = "";

    ConsoleCard(Context c, Runnable onClose) {
        ctx = c;
        d = c.getResources().getDisplayMetrics().density;

        LinearLayout content = new LinearLayout(c);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackground(box(0xF205090F, dp(8), FRAME, dp(2)));
        content.setPadding(dp(10), dp(8), dp(10), dp(12));

        // top bar: GET AUTOMATED WITH and the round close (drag by this row)
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        header = bar;
        TextView title = text("GET AUTOMATED WITH", 12, HEAD, true);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.18f);
        bar.addView(new View(c), new LinearLayout.LayoutParams(dp(30), dp(30)));
        bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView close = text("\u2715", 14, HEAD, true);
        close.setGravity(Gravity.CENTER);
        close.setBackground(box(0x00000000, dp(15), HEAD, dp(2)));
        close.setOnClickListener(v -> onClose.run());
        bar.addView(close, new LinearLayout.LayoutParams(dp(30), dp(30)));
        content.addView(bar, new LinearLayout.LayoutParams(-1, dp(42)));

        // the bot picture with ACTIVATED and the bot name over it
        FrameLayout pic = new FrameLayout(c);
        pic.setBackground(box(0xFF05090F, dp(6), FRAME, dp(1)));
        pic.setClipToOutline(true);
        pic.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        picture = new ImageView(c);
        picture.setScaleType(ImageView.ScaleType.CENTER_CROP);
        picture.setImageResource(R.drawable.app_logo);
        picture.setColorFilter(new PorterDuffColorFilter(0x663A7BD5, PorterDuff.Mode.OVERLAY));
        pic.addView(picture, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(c);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x26000000, 0xCC000000}));
        pic.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        nameTv = text("BOT", 20, ACTIVE, true);
        nameTv.setGravity(Gravity.CENTER);
        nameTv.setSingleLine(true);
        nameTv.setEllipsize(TextUtils.TruncateAt.END);
        nameTv.setLetterSpacing(0.06f);
        nameTv.setShadowLayer(dp(8), 0, 0, 0xFF3A9BFF);
        FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        np.leftMargin = dp(12);
        np.rightMargin = dp(12);
        pic.addView(nameTv, np);

        pillTv = text("\u25CF ACTIVATED", 9, ACTIVE, true);
        pillTv.setLetterSpacing(0.14f);
        pillTv.setPadding(dp(10), dp(4), dp(10), dp(4));
        pillTv.setBackground(box(0x66000000, dp(12), HEAD, dp(1)));
        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.TOP);
        pl.setMargins(dp(8), dp(8), 0, 0);
        pic.addView(pillTv, pl);

        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(96));
        pp.topMargin = dp(10);
        content.addView(pic, pp);

        // the console's buttons: they press the page's own buttons
        LinearLayout btns = new LinearLayout(c);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        stopBtn = button("STOP EA", "toggle");
        btns.addView(stopBtn, btnParams(0));
        btns.addView(button("SCRIPT", "script"), btnParams(8));
        // LIVE is an indicator on the web (not a button): a pulsing dot, no action
        TextView live = text("\u25CF LIVE", 11, BTN_TEXT, true);
        live.setGravity(Gravity.CENTER);
        live.setLetterSpacing(0.08f);
        live.setPadding(dp(4), dp(13), dp(4), dp(13));
        live.setBackground(box(BTN, dp(8), 0, 0));
        btns.addView(live, btnParams(8));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(10);
        content.addView(btns, bp);

        // EA CONSOLE: starts small and grows with the lines
        LinearLayout panel = new LinearLayout(c);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(box(0xCC000000, dp(6), alpha(FRAME, 0.7f), dp(1)));
        panel.setPadding(dp(12), dp(8), dp(12), dp(10));

        LinearLayout labelRow = new LinearLayout(c);
        labelRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView l1 = text("EA CONSOLE", 10, HEAD, true);
        l1.setLetterSpacing(0.16f);
        labelRow.addView(l1, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView l2 = text("SCRIPT", 10, HEAD, true);
        l2.setLetterSpacing(0.16f);
        labelRow.addView(l2);
        panel.addView(labelRow, new LinearLayout.LayoutParams(-1, -2));

        View div = new View(c);
        div.setBackgroundColor(alpha(FRAME, 0.5f));
        LinearLayout.LayoutParams dv = new LinearLayout.LayoutParams(-1, dp(1));
        dv.topMargin = dp(6);
        panel.addView(div, dv);

        logBox = new LinearLayout(c);
        logBox.setOrientation(LinearLayout.VERTICAL);
        logBox.setPadding(0, dp(6), 0, 0);
        logScroll = new ScrollView(c);
        logScroll.setVerticalScrollBarEnabled(true);
        logScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        logScroll.addView(logBox, new FrameLayout.LayoutParams(-1, -2));
        panel.addView(logScroll, new LinearLayout.LayoutParams(-1, dp(44)));

        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-1, -2);
        plp.topMargin = dp(10);
        content.addView(panel, plp);

        // the web's corner brackets
        root = new FrameLayout(c);
        root.addView(content, new FrameLayout.LayoutParams(-1, -2));
        bracket(Gravity.TOP | Gravity.START);
        bracket(Gravity.TOP | Gravity.END);
        bracket(Gravity.BOTTOM | Gravity.START);
        bracket(Gravity.BOTTOM | Gravity.END);
    }

    private void bracket(int gravity) {
        int len = dp(12), t = dp(1), m = dp(5);
        boolean top = (gravity & Gravity.TOP) != 0;
        boolean start = (gravity & Gravity.START) != 0;
        View h = new View(ctx);
        h.setBackgroundColor(HEAD);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(len, t, gravity);
        View v = new View(ctx);
        v.setBackgroundColor(HEAD);
        FrameLayout.LayoutParams vp = new FrameLayout.LayoutParams(t, len, gravity);
        hp.topMargin = top ? m : 0;
        hp.bottomMargin = top ? 0 : m;
        vp.topMargin = top ? m : 0;
        vp.bottomMargin = top ? 0 : m;
        if (start) {
            hp.leftMargin = m;
            vp.leftMargin = m;
        } else {
            hp.rightMargin = m;
            vp.rightMargin = m;
        }
        root.addView(h, hp);
        root.addView(v, vp);
    }

    private int dp(float v) {
        return (int) (v * d + 0.5f);
    }

    static int alpha(int color, float a) {
        return (color & 0x00FFFFFF) | (((int) (a * 255f)) << 24);
    }

    private GradientDrawable box(int fill, int radiusPx, int stroke, int strokePx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radiusPx);
        if (stroke != 0) g.setStroke(strokePx, stroke);
        return g;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(final String label, final String which) {
        TextView b = text(label, 11, BTN_TEXT, true);
        b.setGravity(Gravity.CENTER);
        b.setLetterSpacing(0.08f);
        b.setPadding(dp(4), dp(13), dp(4), dp(13));
        b.setBackground(box(BTN, dp(8), 0, 0));
        b.setOnClickListener(v -> PageHost.clickButton(which));
        return b;
    }

    private LinearLayout.LayoutParams btnParams(int leftDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.leftMargin = dp(leftDp);
        return p;
    }

    /**
     * Fill the card from the web console data. The lines are shown as the page writes them, at once:
     * existing rows are updated in place (no rebuild, no flicker), new rows are added at the bottom.
     */
    void update(String json) {
        try {
            JSONObject o = new JSONObject(json);
            String name = o.optString("name", "");
            nameTv.setText(name.isEmpty() ? "BOT" : name.toUpperCase());
            boolean running = o.optBoolean("running", false);
            pillTv.setText((running ? "\u25CF" : "\u25CB") + " " + (running ? "ACTIVATED" : "STANDBY"));
            stopBtn.setText(running ? "STOP EA" : "START EA");
            loadImage(o.optString("img", ""));

            JSONArray arr = o.optJSONArray("lines");
            List<String> text = new ArrayList<>();
            List<Boolean> sep = new ArrayList<>();
            List<Boolean> bare = new ArrayList<>();
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject l = arr.optJSONObject(i);
                    if (l == null) continue;
                    text.add(l.optString("t", ""));
                    sep.add(l.optBoolean("sep", false));
                    bare.add(l.optBoolean("b", false));
                }
            }
            if (text.isEmpty()) {
                // the web shows only a blinking cursor when the console is empty
                text.add("\u258C");
                sep.add(false);
                bare.add(true);
            }
            String key = text.toString() + sep.toString() + bare.toString();
            if (key.equals(lastKey)) return;
            lastKey = key;
            // follow the newest line only when the user is already at the bottom
            View inner = logScroll.getChildAt(0);
            int bottomGap = inner == null ? 0 : inner.getHeight() - (logScroll.getScrollY() + logScroll.getHeight());
            atBottom = bottomGap <= dp(24);

            for (int i = 0; i < text.size(); i++) {
                boolean isSep = sep.get(i);
                if (i < rows.size()) {
                    View row = rows.get(i);
                    if (isSep == rowIsSep.get(i)) {
                        if (!isSep) {
                            String shown = (bare.get(i) ? "" : "> ") + text.get(i);
                            TextView tv = (TextView) row;
                            if (!shown.equals(tv.getText().toString())) tv.setText(shown);
                        }
                        continue;
                    }
                    // a different kind of row in this place: replace it
                    logBox.removeView(row);
                    rows.remove(i);
                    rowIsSep.remove(i);
                }
                View row = isSep ? sepChip(text.get(i)) : logLine(bare.get(i), text.get(i));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(isSep ? -2 : -1, -2);
                if (isSep) {
                    lp.gravity = Gravity.CENTER_HORIZONTAL;
                    lp.topMargin = dp(8);
                    lp.bottomMargin = dp(6);
                }
                logBox.addView(row, Math.min(i, logBox.getChildCount()), lp);
                rows.add(i, row);
                rowIsSep.add(i, isSep);
            }
            while (rows.size() > text.size()) {
                logBox.removeView(rows.remove(rows.size() - 1));
                rowIsSep.remove(rowIsSep.size() - 1);
            }
            logScroll.post(() -> {
                resizeLog();
                if (atBottom) logScroll.fullScroll(View.FOCUS_DOWN);
            });
        } catch (Exception ignored) {
        }
    }

    private TextView sepChip(String label) {
        TextView t = text(label.toUpperCase(), 10, HEAD, true);
        t.setGravity(Gravity.CENTER);
        t.setLetterSpacing(0.14f);
        t.setPadding(dp(10), dp(4), dp(10), dp(4));
        t.setBackground(box(alpha(FRAME, 0.25f), dp(12), FRAME, dp(1)));
        return t;
    }

    /** The EA CONSOLE grows with its lines, up to a limit. */
    private void resizeLog() {
        int w = logScroll.getWidth() > 0 ? logScroll.getWidth() : dp(260);
        logBox.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.UNSPECIFIED);
        int want = Math.min(logBox.getMeasuredHeight() + dp(4), dp(260));
        want = Math.max(want, dp(44));
        ViewGroup.LayoutParams lp = logScroll.getLayoutParams();
        if (lp.height != want) {
            lp.height = want;
            logScroll.setLayoutParams(lp);
        }
    }

    private TextView logLine(boolean bare, String body) {
        TextView t = text((bare ? "" : "> ") + body, 13, bare ? BARE : LOG, false);
        t.setTypeface(Typeface.MONOSPACE);
        t.setLineSpacing(0, 1.25f);
        t.setPadding(0, dp(3), 0, dp(3));
        return t;
    }

    private void loadImage(String img) {
        if (img == null || img.isEmpty() || img.equals(lastImg)) return;
        lastImg = img;
        if (img.startsWith("data:image")) {
            try {
                byte[] b = android.util.Base64.decode(img.substring(img.indexOf(',') + 1), android.util.Base64.DEFAULT);
                picture.setImageBitmap(BitmapFactory.decodeByteArray(b, 0, b.length));
            } catch (Exception ignored) {
            }
            return;
        }
        if (!img.startsWith("http")) return;
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(img).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                try (InputStream in = c.getInputStream()) {
                    Bitmap bm = BitmapFactory.decodeStream(in);
                    if (bm != null) main.post(() -> picture.setImageBitmap(bm));
                }
            } catch (Exception ignored) {
            }
        }).start();
    }
}
