package com.tradeexpert.app;

import android.animation.ObjectAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;

/**
 * The floating display and the console card over other apps, the same way as Logical Host.
 * Bot ON: the console card pops up. Its X closes it to the display. Tapping the display opens the card.
 * Bot OFF: both disappear. The app on screen: both are hidden.
 */
public class BubbleService extends Service {

    private static final String CHANNEL = "tx_running";
    private static final int NOTIF_ID = 7;

    static BubbleService instance;
    static volatile boolean botOn = false;
    static volatile boolean appVisible = false;
    static volatile boolean consoleOpen = false;
    static volatile String consoleJson = "";

    private WindowManager wm;
    private FrameLayout bubble;
    private WindowManager.LayoutParams bubbleLp;
    private ObjectAnimator pulse;
    private ImageView bubbleImg;
    private ConsoleCard card;
    private android.os.PowerManager.WakeLock wakeLock;
    private WindowManager.LayoutParams cardLp;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        NotificationChannel ch = new NotificationChannel(CHANNEL, "Running", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.app_logo)
                .setContentTitle("Trade Expert")
                .setContentText("Running in the background. Tap to open.")
                .setOngoing(true)
                .setContentIntent(open)
                .build();
        startForeground(NOTIF_ID, n);

        // the page runs here, in the background, so the bot and the console keep working
        try {
            PageHost.get(this);
        } catch (Exception e) {
            Log.e("TradeExpert", "page not started", e);
        }
        try {
            android.os.PowerManager pm = (android.os.PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "tradeexpert:page");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire();
        } catch (Exception e) {
            Log.e("TradeExpert", "wake lock not held", e);
        }

        refresh();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    /** The web bot switch (called from the page's background thread). */
    static void setBotOn(final Context c, final boolean on) {
        new Handler(Looper.getMainLooper()).post(() -> {
            botOn = on;
            consoleOpen = on;   // bot ON: the console pops up at once
            if (instance == null) {
                if (on) c.startForegroundService(new Intent(c, BubbleService.class));
                return;
            }
            instance.refresh();
        });
    }

    /** The app on screen (true) or not (false). */
    static void setAppVisible(final boolean visible) {
        new Handler(Looper.getMainLooper()).post(() -> {
            appVisible = visible;
            if (instance != null) instance.refresh();
        });
    }

    /** The web console's name, picture and lines. */
    static void setConsole(final String json) {
        new Handler(Looper.getMainLooper()).post(() -> {
            consoleJson = json;
            if (instance != null && instance.card != null) instance.card.update(json);
        });
    }

    /** The bot picture arrived. */
    static void onBotPicture() {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (instance != null) instance.applyPicture();
        });
    }

    /** One of: the console card, the display, or nothing. */
    void refresh() {
        if (!botOn) {
            hideCard();
            removeBubble();
            return;
        }
        if (appVisible) {
            // in the app there is one display: the console card (no separate bubble)
            removeBubble();
            if (consoleOpen) showCard(); else hideCard();
            return;
        }
        // outside the app: the console card when open, otherwise the display (bubble)
        if (consoleOpen) {
            removeBubble();
            showCard();
        } else {
            hideCard();
            addBubble();
        }
    }

    private void showCard() {
        if (card != null || !Settings.canDrawOverlays(this)) return;
        float d = getResources().getDisplayMetrics().density;
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int screenH = getResources().getDisplayMetrics().heightPixels;
        int w = Math.min((int) (300 * d), screenW - (int) (16 * d));

        card = new ConsoleCard(this, () -> {
            consoleOpen = false;
            refresh();
        });
        cardLp = new WindowManager.LayoutParams(
                w, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        cardLp.gravity = Gravity.TOP | Gravity.START;
        cardLp.x = (screenW - w) / 2;
        cardLp.y = (int) (screenH * 0.14f);

        card.header.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = cardLp.x;
                        sy = cardLp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        cardLp.x = sx + (int) (e.getRawX() - tx);
                        cardLp.y = sy + (int) (e.getRawY() - ty);
                        try {
                            wm.updateViewLayout(card.root, cardLp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });

        try {
            wm.addView(card.root, cardLp);
            card.update(consoleJson);
        } catch (Exception e) {
            Log.e("TradeExpert", "console not shown", e);
            card = null;
        }
    }

    private void hideCard() {
        if (card != null) {
            try {
                wm.removeView(card.root);
            } catch (Exception ignored) {
            }
            card = null;
        }
    }

    private void addBubble() {
        if (bubble != null || !Settings.canDrawOverlays(this)) return;
        float d = getResources().getDisplayMetrics().density;
        int size = (int) (64 * d);
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int ring = (int) (2 * d);

        bubble = new FrameLayout(this);
        GradientDrawable rg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{ConsoleCard.FRAME, 0xFF2F6FD6});
        rg.setShape(GradientDrawable.OVAL);
        View ringView = new View(this);
        ringView.setBackground(rg);
        bubble.addView(ringView, new FrameLayout.LayoutParams(size, size));

        bubbleImg = new ImageView(this);
        bubbleImg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bubbleImg.setClipToOutline(true);
        bubbleImg.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
        GradientDrawable imgBg = new GradientDrawable();
        imgBg.setShape(GradientDrawable.OVAL);
        imgBg.setColor(0xFF030807);
        bubbleImg.setBackground(imgBg);
        bubbleImg.setPadding(ring, ring, ring, ring);
        applyPicture();
        bubble.addView(bubbleImg, new FrameLayout.LayoutParams(size, size));

        View dot = new View(this);
        GradientDrawable dg = new GradientDrawable();
        dg.setShape(GradientDrawable.OVAL);
        dg.setColor(ConsoleCard.FRAME);
        dg.setStroke((int) (2 * d), 0xFF0A0D14);
        dot.setBackground(dg);
        int ds = (int) (16 * d);
        bubble.addView(dot, new FrameLayout.LayoutParams(ds, ds, Gravity.BOTTOM | Gravity.END));
        pulse = ObjectAnimator.ofFloat(dot, View.ALPHA, 1f, 0.35f, 1f);
        pulse.setDuration(1600);
        pulse.setRepeatCount(ObjectAnimator.INFINITE);
        pulse.setInterpolator(new LinearInterpolator());

        bubbleLp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = screenW - size;
        bubbleLp.y = (int) (220 * d);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float touchX, touchY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = bubbleLp.x;
                        startY = bubbleLp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - touchX;
                        float dy = e.getRawY() - touchY;
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true;
                        bubbleLp.x = startX + (int) dx;
                        bubbleLp.y = startY + (int) dy;
                        try {
                            wm.updateViewLayout(bubble, bubbleLp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            // tap: open the console card (and the page's console, so it has its lines)
                            consoleOpen = true;
                            PageHost.clickBubble();
                            refresh();
                        } else {
                            bubbleLp.x = (bubbleLp.x + size / 2 < screenW / 2) ? 0 : screenW - size;
                            try {
                                wm.updateViewLayout(bubble, bubbleLp);
                            } catch (Exception ignored) {
                            }
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });

        try {
            wm.addView(bubble, bubbleLp);
            pulse.start();
        } catch (Exception e) {
            Log.e("TradeExpert", "display not shown", e);
            bubble = null;
        }
    }

    private void applyPicture() {
        if (bubbleImg == null) return;
        Bitmap bm = BotPicture.bitmap;
        if (bm != null) {
            bubbleImg.setImageBitmap(bm);
        } else {
            bubbleImg.setImageResource(R.drawable.app_logo);
        }
    }

    private void removeBubble() {
        if (pulse != null) pulse.cancel();
        if (bubble != null) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubble = null;
        }
    }

    @Override
    public void onDestroy() {
        hideCard();
        removeBubble();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        instance = null;
        super.onDestroy();
    }
}
