package com.tradeexpert.app;

import android.animation.ObjectAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;

/**
 * The floating display over other apps. Bot ON: the display shows. Tap it: the real web console
 * opens over the app (the same page, not a copy). The console's X closes it back to the display.
 * Bot OFF: everything disappears.
 */
public class BubbleService extends Service {

    static final int FRAME = 0xFF2E6AA8;   // the web console's blue
    static final int HEAD = 0xFF8DB7E8;
    private static final String CHANNEL = "tx_running";
    private static final int NOTIF_ID = 7;

    static BubbleService instance;
    static volatile boolean botOn = false;
    static volatile boolean appVisible = false;
    static volatile boolean consoleOpen = false;

    private WindowManager wm;
    private FrameLayout bubble;
    private WindowManager.LayoutParams bubbleLp;
    private ObjectAnimator pulse;
    private ImageView bubbleImg;
    private FrameLayout overlay;
    private WindowManager.LayoutParams overlayLp;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        NotificationChannel ch = new NotificationChannel(CHANNEL, "Running", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Trade Expert")
                .setContentText("Running in the background. Tap to open.")
                .setOngoing(true)
                .setContentIntent(open)
                .build();
        startForeground(NOTIF_ID, n);

        refresh();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    /** The page's bot switch (called from the page's background thread). */
    static void setBotOn(final Context c, final boolean on) {
        new Handler(Looper.getMainLooper()).post(() -> {
            botOn = on;
            if (instance == null) {
                if (on) c.startForegroundService(new Intent(c, BubbleService.class));
                return;
            }
            if (!on) consoleOpen = false;
            instance.refresh();
        });
    }

    /** The web console opened (true) or closed (false). */
    static void setConsoleOpen(final boolean open) {
        new Handler(Looper.getMainLooper()).post(() -> {
            consoleOpen = open;
            if (instance != null) instance.refresh();
        });
    }

    /** The app on screen (true) or not (false). */
    static void setAppVisible(final boolean visible) {
        new Handler(Looper.getMainLooper()).post(() -> {
            appVisible = visible;
            if (instance != null) instance.refresh();
        });
    }

    /** The bot picture arrived. */
    static void onBotPicture() {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (instance != null) instance.applyPicture();
        });
    }

    /** One of: the display, the web console over other apps, or nothing (bot OFF or app on screen). */
    void refresh() {
        if (!botOn || appVisible) {
            hideOverlay();
            removeBubble();
            return;
        }
        if (consoleOpen) {
            removeBubble();
            showOverlay();
        } else {
            hideOverlay();
            addBubble();
        }
    }

    /** The real web console, shown over the app: the same page, only the console is visible. */
    private void showOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return;
        WebView w = PageHost.get(this);
        PageHost.detach(w);

        float d = getResources().getDisplayMetrics().density;
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int screenH = getResources().getDisplayMetrics().heightPixels;
        int ow = Math.min(screenW - (int) (12 * d), (int) (380 * d));
        int oh = Math.min(screenH - (int) (80 * d), (int) (620 * d));

        overlay = new FrameLayout(this);
        overlay.addView(w, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        overlayLp = new WindowManager.LayoutParams(
                ow, oh,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        overlayLp.gravity = Gravity.TOP | Gravity.START;
        overlayLp.x = (screenW - ow) / 2;
        overlayLp.y = (int) (40 * d);
        try {
            wm.addView(overlay, overlayLp);
            w.onResume();
            w.resumeTimers();
            PageHost.overlayOn(w);
        } catch (Exception e) {
            Log.e("TradeExpert", "console not shown", e);
            overlay = null;
            PageHost.attach(w, new FrameLayout(this));
        }
    }

    private void hideOverlay() {
        if (overlay == null) return;
        WebView w = PageHost.web;
        try {
            wm.removeView(overlay);
        } catch (Exception ignored) {
        }
        if (w != null) {
            ViewParent p = w.getParent();
            if (p == overlay) overlay.removeView(w);
            PageHost.overlayOff(w);
        }
        overlay = null;
    }

    private void addBubble() {
        if (bubble != null || !Settings.canDrawOverlays(this)) return;
        float d = getResources().getDisplayMetrics().density;
        int size = (int) (64 * d);
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int ring = (int) (2 * d);

        bubble = new FrameLayout(this);
        GradientDrawable rg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{FRAME, 0xFF2F6FD6});
        rg.setShape(GradientDrawable.OVAL);
        View ringView = new View(this);
        ringView.setBackground(rg);
        bubble.addView(ringView, new FrameLayout.LayoutParams(size, size));

        bubbleImg = new ImageView(this);
        bubbleImg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bubbleImg.setClipToOutline(true);
        bubbleImg.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
        GradientDrawable imgBg = new GradientDrawable();
        imgBg.setShape(GradientDrawable.OVAL);
        imgBg.setColor(0xFF030807);
        bubbleImg.setBackground(imgBg);
        bubbleImg.setPadding(ring, ring, ring, ring);
        applyPicture();
        bubble.addView(bubbleImg, new FrameLayout.LayoutParams(size, size));

        View dot = new View(this);
        GradientDrawable dg = new GradientDrawable();
        dg.setShape(GradientDrawable.OVAL);
        dg.setColor(FRAME);
        dg.setStroke((int) (2 * d), 0xFF0A0D14);
        dot.setBackground(dg);
        int ds = (int) (16 * d);
        bubble.addView(dot, new FrameLayout.LayoutParams(ds, ds, Gravity.BOTTOM | Gravity.END));
        pulse = ObjectAnimator.ofFloat(dot, View.ALPHA, 1f, 0.35f, 1f);
        pulse.setDuration(1600);
        pulse.setRepeatCount(ObjectAnimator.INFINITE);
        pulse.setInterpolator(new LinearInterpolator());

        bubbleLp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = screenW - size;
        bubbleLp.y = (int) (220 * d);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float touchX, touchY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = bubbleLp.x;
                        startY = bubbleLp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - touchX;
                        float dy = e.getRawY() - touchY;
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true;
                        bubbleLp.x = startX + (int) dx;
                        bubbleLp.y = startY + (int) dy;
                        try {
                            wm.updateViewLayout(bubble, bubbleLp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            // tap: the web console opens (the page's own bot button)
                            PageHost.clickBubble();
                        } else {
                            bubbleLp.x = (bubbleLp.x + size / 2 < screenW / 2) ? 0 : screenW - size;
                            try {
                                wm.updateViewLayout(bubble, bubbleLp);
                            } catch (Exception ignored) {
                            }
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });

        try {
            wm.addView(bubble, bubbleLp);
            pulse.start();
        } catch (Exception e) {
            Log.e("TradeExpert", "display not shown", e);
            bubble = null;
        }
    }

    private void applyPicture() {
        if (bubbleImg == null) return;
        Bitmap bm = BotPicture.bitmap;
        if (bm != null) {
            bubbleImg.setImageBitmap(bm);
        } else {
            bubbleImg.setImageResource(R.drawable.app_logo);
        }
    }

    private void removeBubble() {
        if (pulse != null) pulse.cancel();
        if (bubble != null) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubble = null;
        }
    }

    @Override
    public void onDestroy() {
        hideOverlay();
        removeBubble();
        instance = null;
        super.onDestroy();
    }
}
