package com.tradeexpert.app;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * The chart scanner's signal over the app and over other apps: the signal (BUY or SELL), the
 * entry, stop loss and take profit, the confidence, and the reason the scanner gave (the "why").
 */
class SignalCard {

    static final int BUY = 0xFF22C55E;
    static final int SELL = 0xFFEF4444;
    static final int TEXT = 0xFFE5E7EB;
    static final int MUTED = 0xFF9CA3AF;

    final FrameLayout root;
    private final Context ctx;
    private final float d;
    private final LinearLayout content;
    private final TextView titleTv, signalTv, levelsTv, confTv, reasonTv, factorsTv;

    SignalCard(Context c, Runnable onClose) {
        ctx = c;
        d = c.getResources().getDisplayMetrics().density;

        content = new LinearLayout(c);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(10), dp(12), dp(10));
        content.setBackground(box(0xFF07090D, dp(12), ConsoleCard.DEFAULT_ACCENT, dp(2)));
        content.setClipToOutline(true);

        // title and close
        LinearLayout top = new LinearLayout(c);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        titleTv = text("AI TRADE ANALYSIS", 9, ConsoleCard.DEFAULT_ACCENT, true);
        titleTv.setLetterSpacing(0.12f);
        titleTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        top.addView(titleTv, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView close = text("✕", 11, 0xFFFFFFFF, true);
        close.setGravity(Gravity.CENTER);
        close.setBackground(box(0xFF141820, dp(12), 0xFF2A2F3A, dp(1)));
        close.setOnClickListener(v -> onClose.run());
        top.addView(close, new LinearLayout.LayoutParams(dp(24), dp(24)));
        content.addView(top, new LinearLayout.LayoutParams(-1, -2));

        // BUY or SELL, with the symbol
        signalTv = text("", 20, BUY, true);
        signalTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        signalTv.setPadding(0, dp(6), 0, 0);
        content.addView(signalTv, new LinearLayout.LayoutParams(-1, -2));

        // entry, stop loss, take profit
        levelsTv = text("", 11, TEXT, false);
        levelsTv.setTypeface(Typeface.MONOSPACE);
        levelsTv.setPadding(0, dp(4), 0, 0);
        content.addView(levelsTv, new LinearLayout.LayoutParams(-1, -2));

        confTv = text("", 10, ConsoleCard.DEFAULT_ACCENT, true);
        confTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        confTv.setPadding(0, dp(2), 0, dp(6));
        content.addView(confTv, new LinearLayout.LayoutParams(-1, -2));

        // the why
        reasonTv = text("", 11, TEXT, false);
        reasonTv.setTypeface(Typeface.MONOSPACE);
        reasonTv.setLineSpacing(0, 1.2f);
        reasonTv.setMaxLines(7);
        reasonTv.setEllipsize(TextUtils.TruncateAt.END);
        reasonTv.setPadding(dp(8), dp(6), dp(8), dp(6));
        reasonTv.setBackground(box(0xFF000000, dp(6), 0, 0));
        content.addView(reasonTv, new LinearLayout.LayoutParams(-1, -2));

        factorsTv = text("", 10, MUTED, false);
        factorsTv.setTypeface(Typeface.MONOSPACE);
        factorsTv.setLineSpacing(0, 1.2f);
        factorsTv.setPadding(0, dp(6), 0, 0);
        content.addView(factorsTv, new LinearLayout.LayoutParams(-1, -2));

        // footer
        TextView powered = text("Powered by TradeExpert", 10, 0xFFFFFFFF, true);
        powered.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        powered.setPadding(0, dp(8), 0, 0);
        content.addView(powered, new LinearLayout.LayoutParams(-1, -2));

        root = new FrameLayout(c);
        root.addView(content, new FrameLayout.LayoutParams(-1, -2));
    }

    /** Fill the card from the scanner result (signal, levels, confidence, analysis, factors). */
    void fill(JSONObject r, int accent) {
        String signal = r.optString("signal", "").toUpperCase();
        boolean buy = signal.equals("BUY");
        String symbol = r.optString("symbol", "");
        signalTv.setText(signal + (symbol.isEmpty() ? "" : " " + symbol.toUpperCase()));
        signalTv.setTextColor(buy ? BUY : SELL);

        levelsTv.setText("Entry " + r.optString("entry", "-")
                + "  ·  SL " + r.optString("stopLoss", "-")
                + "  ·  TP " + r.optString("takeProfit", "-"));

        double conf = r.optDouble("confidence", 0);
        confTv.setText("● Confidence " + Math.round(conf) + "%");
        confTv.setTextColor(accent);
        titleTv.setTextColor(accent);

        String why = r.optString("analysis", "");
        if (why.isEmpty()) why = r.optString("reason", "");
        if (why.isEmpty()) why = "Directional chart analysis completed.";
        reasonTv.setText(why.trim());

        StringBuilder f = new StringBuilder();
        JSONArray arr = r.optJSONArray("confluenceFactors");
        if (arr != null) {
            for (int i = 0; i < arr.length() && i < 4; i++) {
                String s = arr.optString(i, "").trim();
                if (!s.isEmpty()) f.append("• ").append(s).append('\n');
            }
        }
        factorsTv.setText(f.toString().trim());
        factorsTv.setVisibility(f.length() == 0 ? View.GONE : View.VISIBLE);

        content.setBackground(box(0xFF07090D, dp(12), accent, dp(2)));
    }

    private int dp(float v) {
        return (int) (v * d + 0.5f);
    }

    private GradientDrawable box(int fill, int radiusPx, int stroke, int strokePx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radiusPx);
        if (stroke != 0) g.setStroke(strokePx, stroke);
        return g;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }
}
