package com.tradeexpert.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * The bot console card, in the web design: the bot picture with its name and ACCOUNT status,
 * the console lines typed out one by one (">> ..."), and the footer with the stop and clear buttons.
 * The lines are the web page's own console lines.
 */
class ConsoleCard {

    static final int FRAME = 0xFFE5192A;   // the red of the web card (also the bubble ring)
    static final int RED = 0xFFE5192A;
    static final int TEXT = 0xFFEDEDED;
    static final int AMBER = 0xFFF2C14E;
    static final int MUTED = 0xFF8A8F9A;
    static final int BTN = 0xFF141820;
    static final int BTN_EDGE = 0xFF3A3F4A;

    private static final int SPAN = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE;

    /** One console line. */
    private static final class Row {
        final String text;
        final boolean sep;
        TextView view;
        int shown;

        Row(String text, boolean sep) {
            this.text = text;
            this.sep = sep;
        }

        boolean same(Row o) {
            return text.equals(o.text) && sep == o.sep;
        }
    }

    final FrameLayout root;
    /** The top picture: drag the card by it. */
    final View header;
    private final Context ctx;
    private final float d;
    private final TextView nameTv, pillTv, stopBtn;
    private final ImageView picture;
    private final LinearLayout logBox;
    private final ScrollView logScroll;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<Row> rows = new ArrayList<>();
    private boolean typingScheduled = false;
    private String lastImg = "";

    ConsoleCard(Context c, Runnable onClose) {
        ctx = c;
        d = c.getResources().getDisplayMetrics().density;

        LinearLayout content = new LinearLayout(c);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackground(box(0xFF07090D, dp(14), FRAME, dp(2)));
        content.setClipToOutline(true);
        content.setOutlineProvider(ViewOutlineProvider.BACKGROUND);

        // the picture: grip (top left), close (top right), name and status over the picture
        FrameLayout pic = new FrameLayout(c);
        header = pic;
        picture = new ImageView(c);
        picture.setScaleType(ImageView.ScaleType.CENTER_CROP);
        picture.setImageResource(R.drawable.app_logo);
        pic.addView(picture, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(c);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x33000000, 0xEE000000}));
        pic.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.TOP);
        gp.setMargins(dp(14), dp(14), 0, 0);
        pic.addView(grip(), gp);

        TextView close = text("✕", 14, 0xFFFFFFFF, true);
        close.setGravity(Gravity.CENTER);
        close.setBackground(box(0xCC000000, dp(18), 0xFF2A2F3A, dp(1)));
        close.setOnClickListener(v -> onClose.run());
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(36), dp(36), Gravity.END | Gravity.TOP);
        cp.setMargins(0, dp(10), dp(10), 0);
        pic.addView(close, cp);

        LinearLayout info = new LinearLayout(c);
        info.setOrientation(LinearLayout.VERTICAL);
        nameTv = text("BOT", 22, 0xFFFFFFFF, true);
        nameTv.setSingleLine(true);
        nameTv.setEllipsize(TextUtils.TruncateAt.END);
        nameTv.setLetterSpacing(0.04f);
        nameTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        info.addView(nameTv);
        pillTv = text("● ACCOUNT NOT CONNECTED", 10, RED, true);
        pillTv.setLetterSpacing(0.08f);
        pillTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-2, -2);
        pp.topMargin = dp(4);
        info.addView(pillTv, pp);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        ip.setMargins(dp(16), 0, dp(16), dp(16));
        pic.addView(info, ip);
        content.addView(pic, new LinearLayout.LayoutParams(-1, dp(210)));

        // the console panel: the typed lines
        LinearLayout panel = new LinearLayout(c);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xFF0B0E14);
        panel.setPadding(dp(16), dp(12), dp(16), dp(6));

        logBox = new LinearLayout(c);
        logBox.setOrientation(LinearLayout.VERTICAL);
        logScroll = new ScrollView(c);
        logScroll.setVerticalScrollBarEnabled(false);
        logScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        logScroll.addView(logBox, new FrameLayout.LayoutParams(-1, -2));
        panel.addView(logScroll, new LinearLayout.LayoutParams(-1, dp(44)));
        content.addView(panel, new LinearLayout.LayoutParams(-1, -2));

        // the footer: powered by, stop (square) and clear (bin)
        LinearLayout footer = new LinearLayout(c);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.setBackgroundColor(0xFF0B0E14);
        footer.setPadding(dp(16), dp(4), dp(12), dp(12));
        TextView powered = text("Powered by TradeExpert", 10, MUTED, false);
        powered.setTypeface(Typeface.MONOSPACE);
        footer.addView(powered, new LinearLayout.LayoutParams(0, -2, 1f));
        stopBtn = iconButton("▢", "toggle");
        footer.addView(stopBtn, new LinearLayout.LayoutParams(dp(36), dp(36)));
        footer.addView(iconButton("🗑", "script"), new LinearLayout.LayoutParams(dp(36), dp(36)));
        content.addView(footer, new LinearLayout.LayoutParams(-1, -2));

        root = new FrameLayout(c);
        root.addView(content, new FrameLayout.LayoutParams(-1, -2));
    }

    /** The 3 by 3 grip dots (drag). */
    private LinearLayout grip() {
        LinearLayout g = new LinearLayout(ctx);
        g.setOrientation(LinearLayout.VERTICAL);
        for (int r = 0; r < 3; r++) {
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int col = 0; col < 3; col++) {
                View dot = new View(ctx);
                GradientDrawable dg = new GradientDrawable();
                dg.setShape(GradientDrawable.OVAL);
                dg.setColor(RED);
                dot.setBackground(dg);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(4), dp(4));
                lp.setMargins(dp(1), dp(1), dp(1), dp(1));
                row.addView(dot, lp);
            }
            g.addView(row);
        }
        return g;
    }

    /**
     * Fill the card from the web console data. The lines the page already has stay as they are; the
     * new ones are typed out, one after another, like the web console.
     */
    void update(String json) {
        try {
            JSONObject o = new JSONObject(json);
            String name = o.optString("name", "");
            nameTv.setText(name.isEmpty() ? "BOT" : name.toUpperCase());
            boolean running = o.optBoolean("running", false);
            stopBtn.setText(running ? "▢" : "▷");
            loadImage(o.optString("img", ""));

            List<Row> incoming = new ArrayList<>();
            JSONArray arr = o.optJSONArray("lines");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject l = arr.optJSONObject(i);
                    if (l == null) continue;
                    incoming.add(new Row(l.optString("t", ""), l.optBoolean("sep", false)));
                }
            }

            // ACCOUNT CONNECTED once the page says the trading account is linked
            boolean connected = false;
            for (Row r : incoming) {
                String u = r.text.toUpperCase();
                if (u.contains("LINKED") || (u.contains("CONNECTED") && !u.contains("NOT CONNECTED"))) {
                    connected = true;
                }
            }
            pillTv.setText("● ACCOUNT " + (connected ? "CONNECTED" : "NOT CONNECTED"));

            // keep the lines that are already shown; drop the rest and add the new ones
            int same = 0;
            while (same < rows.size() && same < incoming.size() && rows.get(same).same(incoming.get(same))) {
                same++;
            }
            while (rows.size() > same) {
                Row r = rows.remove(rows.size() - 1);
                if (r.view != null) logBox.removeView(r.view);
            }
            for (int i = same; i < incoming.size(); i++) {
                Row r = incoming.get(i);
                r.view = makeView(r);
                logBox.addView(r.view, new LinearLayout.LayoutParams(-1, -2));
                rows.add(r);
            }
            if (rows.size() > same) scheduleTyping();
            scrollDown();
        } catch (Exception ignored) {
        }
    }

    private TextView makeView(Row r) {
        TextView t = new TextView(ctx);
        t.setTextSize(13);
        t.setTypeface(Typeface.MONOSPACE);
        t.setLineSpacing(0, 1.2f);
        t.setPadding(0, dp(3), 0, dp(3));
        if (r.sep) {
            // a section label, e.g. CHART SCANNER
            t.setText(r.text.toUpperCase());
            t.setTextColor(RED);
            t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            t.setLetterSpacing(0.1f);
            t.setPadding(0, dp(8), 0, dp(4));
            r.shown = r.text.length();
        } else {
            r.shown = 0;
            paint(r, t);
        }
        return t;
    }

    /** Show the typed part of a line, with a cursor while it is still being typed. */
    private void paint(Row r, TextView t) {
        int n = Math.min(r.shown, r.text.length());
        boolean typing = n < r.text.length();
        SpannableStringBuilder sb = new SpannableStringBuilder(">> ");
        sb.setSpan(new ForegroundColorSpan(RED), 0, 2, SPAN);
        int bodyStart = sb.length();
        sb.append(r.text, 0, n);
        int color = r.text.toUpperCase().contains("STATUS") ? AMBER : TEXT;
        sb.setSpan(new ForegroundColorSpan(color), bodyStart, sb.length(), SPAN);
        if (typing) {
            sb.append("▌");
            sb.setSpan(new ForegroundColorSpan(RED), sb.length() - 1, sb.length(), SPAN);
        }
        t.setText(sb);
    }

    private void scheduleTyping() {
        if (typingScheduled) return;
        typingScheduled = true;
        main.post(typer);
    }

    private final Runnable typer = new Runnable() {
        @Override
        public void run() {
            int pending = 0;
            Row cur = null;
            for (Row r : rows) {
                if (r.sep || r.shown >= r.text.length()) continue;
                if (cur == null) cur = r;
                pending += r.text.length() - r.shown;
            }
            if (cur == null) {
                typingScheduled = false;
                return;
            }
            // many lines at once (a new scan): type faster so the card keeps up
            int step = pending > 240 ? 24 : pending > 80 ? 6 : 2;
            cur.shown = Math.min(cur.text.length(), cur.shown + step);
            paint(cur, (TextView) cur.view);
            scrollDown();
            main.postDelayed(this, 22);
        }
    };

    private void scrollDown() {
        logScroll.post(() -> {
            resizeLog();
            logScroll.fullScroll(View.FOCUS_DOWN);
        });
    }

    /** The console grows with its lines, up to a limit. */
    private void resizeLog() {
        int w = logScroll.getWidth() > 0 ? logScroll.getWidth() : dp(260);
        logBox.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.UNSPECIFIED);
        int want = Math.min(logBox.getMeasuredHeight() + dp(4), dp(200));
        want = Math.max(want, dp(44));
        android.view.ViewGroup.LayoutParams lp = logScroll.getLayoutParams();
        if (lp.height != want) {
            lp.height = want;
            logScroll.setLayoutParams(lp);
        }
    }

    private void loadImage(String img) {
        if (img == null || img.isEmpty() || img.equals(lastImg)) return;
        lastImg = img;
        if (img.startsWith("data:image")) {
            try {
                byte[] b = android.util.Base64.decode(img.substring(img.indexOf(',') + 1), android.util.Base64.DEFAULT);
                picture.setImageBitmap(BitmapFactory.decodeByteArray(b, 0, b.length));
            } catch (Exception ignored) {
            }
            return;
        }
        if (!img.startsWith("http")) return;
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(img).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                try (InputStream in = c.getInputStream()) {
                    Bitmap bm = BitmapFactory.decodeStream(in);
                    if (bm != null) main.post(() -> picture.setImageBitmap(bm));
                }
            } catch (Exception ignored) {
            }
        }).start();
    }

    private TextView iconButton(final String label, final String which) {
        TextView b = text(label, 15, 0xFFEDEDED, false);
        b.setGravity(Gravity.CENTER);
        b.setBackground(box(BTN, dp(8), BTN_EDGE, dp(1)));
        b.setOnClickListener(v -> PageHost.clickButton(which));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(36), dp(36));
        lp.leftMargin = dp(8);
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(float v) {
        return (int) (v * d + 0.5f);
    }

    private GradientDrawable box(int fill, int radiusPx, int stroke, int strokePx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radiusPx);
        if (stroke != 0) g.setStroke(strokePx, stroke);
        return g;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }
}
