package com.tradeexpert.app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** The bot picture, shared by the display and the console card. */
final class BotPicture {

    static volatile Bitmap bitmap = null;
    private static String current = "";

    private BotPicture() {}

    static void load(final String img) {
        if (img == null || img.isEmpty() || img.equals(current)) return;
        current = img;
        if (img.startsWith("data:image")) {
            try {
                byte[] b = Base64.decode(img.substring(img.indexOf(',') + 1), Base64.DEFAULT);
                done(BitmapFactory.decodeByteArray(b, 0, b.length));
            } catch (Exception ignored) {
            }
            return;
        }
        if (!img.startsWith("http")) return;
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(img).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                try (InputStream in = c.getInputStream()) {
                    done(BitmapFactory.decodeStream(in));
                }
            } catch (Exception ignored) {
            }
        }).start();
    }

    /** Crops a picture to a centred circle (the rest of the square becomes transparent). */
    static Bitmap round(final Bitmap src) {
        if (src == null) return null;
        int s = Math.min(src.getWidth(), src.getHeight());
        if (s <= 0) return src;
        Bitmap out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        cv.drawCircle(s / 2f, s / 2f, s / 2f, p);
        p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        int x = (src.getWidth() - s) / 2, y = (src.getHeight() - s) / 2;
        cv.drawBitmap(src, new Rect(x, y, x + s, y + s), new Rect(0, 0, s, s), p);
        return out;
    }

    private static void done(final Bitmap raw) {
        if (raw == null) return;
        final Bitmap bm = round(raw);
        new Handler(Looper.getMainLooper()).post(() -> {
            bitmap = bm;
            BubbleService.onBotPicture();
        });
    }
}
