package com.tradeexpert.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.FrameLayout;

/**
 * Trade Expert on screen. The page itself lives in the background service (PageHost), so the bot,
 * the console and the signals keep running when the app is closed.
 */
public class MainActivity extends Activity {

    static Activity current;

    private FrameLayout container;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        container = new FrameLayout(this);
        container.setBackgroundColor(Color.parseColor("#FF0A0D14"));
        setContentView(container);

        // the floating display over other apps: ask for permission once, then start the service
        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }
        startForegroundService(new Intent(this, BubbleService.class));
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (PageHost.web == null || PageHost.web.getParent() != container) {
            PageHost.attach(PageHost.get(this), container);
        }
        current = this;
        PageHost.setVisible(true);
        BubbleService.setAppVisible(true);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (current == this) current = null;
        PageHost.setVisible(false);
        BubbleService.setAppVisible(false);
        // the page keeps running in the service; only the screen lets go of it
        if (PageHost.web != null) PageHost.detach(PageHost.web);
    }

    @Override
    public void onBackPressed() {
        if (PageHost.web != null && PageHost.web.canGoBack()) {
            PageHost.web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
