package com.tradeexpert.app;

import android.content.Context;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import android.app.Activity;
import android.app.AlertDialog;

/** What the web page reports to the app: the bot switch (ON / OFF). */
public class TeBridge {

    static final String CHANNEL = "te_signals";

    private final Context ctx;
    private int nextId = 2000;

    public TeBridge(Context c) {
        ctx = c.getApplicationContext();
    }

    @JavascriptInterface
    public void botState(boolean on) {
        BubbleService.setBotOn(ctx, on);
    }

    /** The web console's name, picture and lines (for the card over other apps). */
    @JavascriptInterface
    public void consoleData(String json) {
        BubbleService.setConsole(json);
    }


    /** A dropdown on the page was tapped: show its choices in a native list, then give the choice back. */
    @JavascriptInterface
    public void pickOption(final String id, final String title, final String optionsJson, final int selected) {
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                final Activity act = MainActivity.current;
                if (act == null || act.isFinishing()) return;
                JSONArray arr = new JSONArray(optionsJson);
                final String[] items = new String[arr.length()];
                for (int i = 0; i < items.length; i++) items[i] = arr.getString(i);
                new AlertDialog.Builder(act, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle(title)
                        .setSingleChoiceItems(items, selected, (d, which) -> {
                            d.dismiss();
                            final WebView w = PageHost.web;
                            if (w != null) w.evaluateJavascript(
                                    "window.__tePicked&&window.__tePicked('" + id + "'," + which + ")", null);
                        })
                        .show();
            } catch (Exception ignored) {
            }
        });
    }

    /** The web console data for the card. */

    /** A short status from the page (for testing). */
    @JavascriptInterface
    public void status(final String text) {
        new Handler(Looper.getMainLooper()).post(() ->
                Toast.makeText(ctx, "Display: " + text, Toast.LENGTH_SHORT).show());
    }

    /** A new signal: a notification. */
    @JavascriptInterface
    public void show(String title, String body) {
        try {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Signals", NotificationManager.IMPORTANCE_HIGH);
            ch.enableVibration(true);
            ctx.getSystemService(NotificationManager.class).createNotificationChannel(ch);
            PendingIntent pi = PendingIntent.getActivity(ctx, 0,
                    new Intent(ctx, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(ctx, CHANNEL)
                    .setSmallIcon(R.drawable.app_logo)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new Notification.BigTextStyle().bigText(body))
                    .setCategory(Notification.CATEGORY_MESSAGE)
                    .setAutoCancel(true)
                    .setContentIntent(pi)
                    .build();
            ctx.getSystemService(NotificationManager.class).notify(nextId++, n);
        } catch (Exception ignored) {
        }
    }
}
