package com.tradeexpert.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * The bot console card: the bot picture with its name and ACCOUNT status, the console lines
 * (shown at once), and the footer with the stop and clear buttons. The frame cycles between the
 * app's accent colours at the app's colour speed, and follows the colour the user picks in the app.
 */
class ConsoleCard {

    static final int DEFAULT_ACCENT = 0xFF10B981;   // the web app's default colour
    static final int FRAME = DEFAULT_ACCENT;         // the bubble ring uses this too
    static final int TEXT = 0xFFEDEDED;
    static final int AMBER = 0xFFF2C14E;
    static final int MUTED = 0xFF8A8F9A;
    static final int BTN = 0xFF141820;
    static final int BTN_EDGE = 0xFF3A3F4A;

    private static final int SPAN = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE;

    /** One console line. */
    private static final class Row {
        String text;      // the text the page has written so far (it can grow)
        final boolean sep;
        int shown;        // how many letters are typed on the card
        TextView view;

        Row(String text, boolean sep) {
            this.text = text;
            this.sep = sep;
            this.shown = sep ? text.length() : 0;
        }
    }

    final FrameLayout root;
    /** The top picture: drag the card by it. */
    final View header;
    private final Context ctx;
    private final float d;
    private final LinearLayout content;
    private final TextView nameTv, pillTv, stopBtn;
    private final ImageView picture;
    private final LinearLayout logBox;
    private final ScrollView logScroll;
    private final List<View> dots = new ArrayList<>();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<Row> rows = new ArrayList<>();
    private String lastImg = "";

    // the app's colours: accent, secondary (0 = none) and cycle speed
    private int accent = DEFAULT_ACCENT;
    private int secondary = 0;
    private float speed = 0.3f;
    private boolean cycling = false;

    private final Runnable cycler = new Runnable() {
        @Override
        public void run() {
            double t = (Math.sin(SystemClock.uptimeMillis() / 1000.0 * 2 * Math.PI * speed) + 1) / 2;
            setTint(mix(accent, otherColour(), (float) t));
            main.postDelayed(this, 50);
        }
    };

    ConsoleCard(Context c, Runnable onClose) {
        ctx = c;
        d = c.getResources().getDisplayMetrics().density;

        content = new LinearLayout(c);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setClipToOutline(true);
        content.setOutlineProvider(ViewOutlineProvider.BACKGROUND);

        // the picture: grip (top left), close (top right), name and status over the picture
        FrameLayout pic = new FrameLayout(c);
        header = pic;
        picture = new ImageView(c);
        picture.setScaleType(ImageView.ScaleType.CENTER_CROP);
        picture.setImageResource(R.drawable.app_logo);
        pic.addView(picture, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(c);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x33000000, 0xEE000000}));
        pic.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.TOP);
        gp.setMargins(dp(10), dp(10), 0, 0);
        pic.addView(grip(), gp);

        TextView close = text("✕", 11, 0xFFFFFFFF, true);
        close.setGravity(Gravity.CENTER);
        close.setBackground(box(0xCC000000, dp(14), 0xFF2A2F3A, dp(1)));
        close.setOnClickListener(v -> onClose.run());
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.END | Gravity.TOP);
        cp.setMargins(0, dp(8), dp(8), 0);
        pic.addView(close, cp);

        LinearLayout info = new LinearLayout(c);
        info.setOrientation(LinearLayout.VERTICAL);
        nameTv = text("BOT", 16, 0xFFFFFFFF, true);
        nameTv.setSingleLine(true);
        nameTv.setEllipsize(TextUtils.TruncateAt.END);
        nameTv.setLetterSpacing(0.04f);
        nameTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        info.addView(nameTv);
        pillTv = text("● ACCOUNT NOT CONNECTED", 8, FRAME, true);
        pillTv.setLetterSpacing(0.06f);
        pillTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-2, -2);
        pp.topMargin = dp(3);
        info.addView(pillTv, pp);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        ip.setMargins(dp(12), 0, dp(12), dp(10));
        pic.addView(info, ip);
        content.addView(pic, new LinearLayout.LayoutParams(-1, dp(128)));

        // the console panel: the lines
        LinearLayout panel = new LinearLayout(c);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xFF0B0E14);
        panel.setPadding(dp(12), dp(8), dp(12), dp(4));

        logBox = new LinearLayout(c);
        logBox.setOrientation(LinearLayout.VERTICAL);
        logScroll = new ScrollView(c);
        logScroll.setVerticalScrollBarEnabled(false);
        logScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        logScroll.addView(logBox, new FrameLayout.LayoutParams(-1, -2));
        panel.addView(logScroll, new LinearLayout.LayoutParams(-1, dp(40)));
        content.addView(panel, new LinearLayout.LayoutParams(-1, -2));

        // the footer: powered by, stop (square) and clear (bin)
        LinearLayout footer = new LinearLayout(c);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.setBackgroundColor(0xFF0B0E14);
        footer.setPadding(dp(12), dp(2), dp(8), dp(8));
        TextView powered = text("Powered by TradeExpert", 8, MUTED, false);
        powered.setTypeface(Typeface.MONOSPACE);
        footer.addView(powered, new LinearLayout.LayoutParams(0, -2, 1f));
        stopBtn = iconButton("▢", "toggle");
        footer.addView(stopBtn, buttonParams(0));
        footer.addView(iconButton("🗑", "script"), buttonParams(6));
        content.addView(footer, new LinearLayout.LayoutParams(-1, -2));

        root = new FrameLayout(c);
        root.addView(content, new FrameLayout.LayoutParams(-1, -2));
        setTint(FRAME);
    }

    /** Stop the colour cycle (the card is being removed). */
    void stop() {
        cycling = false;
        main.removeCallbacks(cycler);
    }

    /** The bot picture arrived: show it on the card. */
    void refreshPicture() {
        if (BotPicture.bitmap != null) picture.setImageBitmap(BotPicture.bitmap);
    }

    /** The 3 by 3 grip dots (drag). */
    private LinearLayout grip() {
        LinearLayout g = new LinearLayout(ctx);
        g.setOrientation(LinearLayout.VERTICAL);
        for (int r = 0; r < 3; r++) {
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int col = 0; col < 3; col++) {
                View dot = new View(ctx);
                GradientDrawable dg = new GradientDrawable();
                dg.setShape(GradientDrawable.OVAL);
                dg.setColor(FRAME);
                dot.setBackground(dg);
                dots.add(dot);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(3), dp(3));
                lp.setMargins(dp(1), dp(1), dp(1), dp(1));
                row.addView(dot, lp);
            }
            g.addView(row);
        }
        return g;
    }

    /**
     * Fill the card from the web console data. The lines the page already has stay as they are;
     * new lines are shown at once. The colours follow the app's colour and speed.
     */
    void update(String json) {
        try {
            JSONObject o = new JSONObject(json);
            String name = o.optString("name", "");
            nameTv.setText(name.isEmpty() ? "BOT" : name.toUpperCase());
            boolean running = o.optBoolean("running", false);
            stopBtn.setText(running ? "▢" : "▷");
            if (BotPicture.bitmap != null) refreshPicture();
            else loadImage(o.optString("img", ""));
            setAccent(o.optString("accent", ""), o.optString("secondary", ""), (float) o.optDouble("speed", 0.3));

            List<Row> incoming = new ArrayList<>();
            JSONArray arr = o.optJSONArray("lines");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject l = arr.optJSONObject(i);
                    if (l == null) continue;
                    incoming.add(new Row(l.optString("t", ""), l.optBoolean("sep", false)));
                }
            }

            // ACCOUNT CONNECTED once the page says the trading account is linked
            boolean connected = false;
            for (Row r : incoming) {
                String u = r.text.toUpperCase();
                if (u.contains("LINKED") || (u.contains("CONNECTED") && !u.contains("NOT CONNECTED"))) {
                    connected = true;
                }
            }
            pillTv.setText("● ACCOUNT " + (connected ? "CONNECTED" : "NOT CONNECTED"));

            // keep the lines already shown; drop the rest and add the new ones at once
            // a line the page is still writing grows in place and keeps its typed letters
            int same = 0;
            while (same < rows.size() && same < incoming.size()) {
                Row have = rows.get(same);
                Row want = incoming.get(same);
                if (have.sep != want.sep) break;
                if (have.text.equals(want.text)) {
                    same++;
                } else if (!have.sep && want.text.startsWith(have.text)) {
                    have.text = want.text;
                    same++;
                } else {
                    break;
                }
            }
            while (rows.size() > same) {
                Row r = rows.remove(rows.size() - 1);
                if (r.view != null) logBox.removeView(r.view);
            }
            for (int i = same; i < incoming.size(); i++) {
                Row r = incoming.get(i);
                r.view = makeView(r);
                logBox.addView(r.view, new LinearLayout.LayoutParams(-1, -2));
                rows.add(r);
            }
            scheduleTyping();
            scrollDown();
        } catch (Exception ignored) {
        }
    }

    /** Take the app's colours. A change repaints the lines; the frame keeps cycling. */
    private void setAccent(String accentHex, String secondaryHex, float sp) {
        int a = parse(accentHex, DEFAULT_ACCENT);
        int s = parse(secondaryHex, 0);
        float newSpeed = sp > 0 ? Math.min(sp, 3f) : 0.3f;
        boolean changed = a != accent || s != secondary;
        accent = a;
        secondary = s;
        speed = newSpeed;
        if (changed) repaintAll();
        if (!cycling) {
            cycling = true;
            main.post(cycler);
        }
    }

    /** The second colour of the cycle: the app's secondary colour, or a light tint of the accent. */
    private int otherColour() {
        return secondary != 0 ? secondary : mix(accent, 0xFFFFFFFF, 0.45f);
    }

    /** Paint the frame, the grip, and the status in one colour. */
    private void setTint(int c) {
        content.setBackground(box(0xFF07090D, dp(12), c, dp(2)));
        for (View v : dots) {
            ((GradientDrawable) v.getBackground()).setColor(c);
        }
        pillTv.setTextColor(c);
    }

    private void repaintAll() {
        for (Row r : rows) {
            if (r.view != null) paint(r, (TextView) r.view);
        }
    }

    private TextView makeView(Row r) {
        TextView t = new TextView(ctx);
        t.setTextSize(12);
        t.setTypeface(Typeface.MONOSPACE);
        t.setLineSpacing(0, 1.15f);
        t.setPadding(0, dp(2), 0, dp(2));
        if (r.sep) {
            t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            t.setLetterSpacing(0.1f);
            t.setPadding(0, dp(6), 0, dp(3));
        }
        paint(r, t);
        return t;
    }

    /** Write the typed part of the line: a section label, or ">> " then the text (amber for STATUS). */
    private void paint(Row r, TextView t) {
        int n = Math.min(r.shown, r.text.length());
        boolean typing = n < r.text.length();
        SpannableStringBuilder sb = new SpannableStringBuilder();
        if (r.sep) {
            sb.append(r.text.toUpperCase());
            sb.setSpan(new ForegroundColorSpan(accent), 0, sb.length(), SPAN);
        } else {
            sb.append(">> ");
            sb.setSpan(new ForegroundColorSpan(accent), 0, 2, SPAN);
            int start = sb.length();
            sb.append(r.text, 0, n);
            int color = r.text.toUpperCase().contains("STATUS") ? AMBER : TEXT;
            sb.setSpan(new ForegroundColorSpan(color), start, sb.length(), SPAN);
            if (typing) {
                sb.append("\u258C");
                sb.setSpan(new ForegroundColorSpan(accent), sb.length() - 1, sb.length(), SPAN);
            }
        }
        t.setText(sb);
    }

    private boolean typingScheduled = false;

    /** Types the lines letter by letter, a few letters per frame, so the card never freezes. */
    private final Runnable typer = new Runnable() {
        @Override
        public void run() {
            Row cur = null;
            int pending = 0;
            for (Row r : rows) {
                if (r.shown >= r.text.length()) continue;
                if (cur == null) cur = r;
                pending += r.text.length() - r.shown;
            }
            if (cur == null || cur.view == null) {
                typingScheduled = false;
                return;
            }
            int step = pending > 300 ? 12 : pending > 120 ? 6 : 3;
            cur.shown = Math.min(cur.text.length(), cur.shown + step);
            paint(cur, (TextView) cur.view);
            scrollDown();
            main.postDelayed(this, 16);
        }
    };

    private void scheduleTyping() {
        if (typingScheduled) return;
        typingScheduled = true;
        main.post(typer);
    }

    private void scrollDown() {
        logScroll.post(() -> {
            resizeLog();
            logScroll.fullScroll(View.FOCUS_DOWN);
        });
    }

    /** The console grows with its lines, up to a limit. */
    private void resizeLog() {
        int w = logScroll.getWidth() > 0 ? logScroll.getWidth() : dp(220);
        logBox.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.UNSPECIFIED);
        int want = Math.min(logBox.getMeasuredHeight() + dp(4), dp(150));
        want = Math.max(want, dp(40));
        ViewGroup.LayoutParams lp = logScroll.getLayoutParams();
        if (lp.height != want) {
            lp.height = want;
            logScroll.setLayoutParams(lp);
        }
    }

    private void loadImage(String img) {
        if (img == null || img.isEmpty() || img.equals(lastImg)) return;
        lastImg = img;
        if (img.startsWith("data:image")) {
            try {
                byte[] b = android.util.Base64.decode(img.substring(img.indexOf(',') + 1), android.util.Base64.DEFAULT);
                picture.setImageBitmap(BitmapFactory.decodeByteArray(b, 0, b.length));
            } catch (Exception ignored) {
            }
            return;
        }
        if (!img.startsWith("http")) return;
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(img).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                try (InputStream in = c.getInputStream()) {
                    Bitmap bm = BitmapFactory.decodeStream(in);
                    if (bm != null) main.post(() -> picture.setImageBitmap(bm));
                }
            } catch (Exception ignored) {
            }
        }).start();
    }

    private static int parse(String hex, int fallback) {
        try {
            return Color.parseColor(hex);
        } catch (Exception e) {
            return fallback;
        }
    }

    /** Colour a (0 = first, 1 = second). */
    static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private TextView iconButton(final String label, final String which) {
        TextView b = text(label, 13, 0xFFEDEDED, false);
        b.setGravity(Gravity.CENTER);
        b.setBackground(box(BTN, dp(7), BTN_EDGE, dp(1)));
        b.setOnClickListener(v -> PageHost.clickButton(which));
        return b;
    }

    private LinearLayout.LayoutParams buttonParams(int leftDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(30), dp(30));
        lp.leftMargin = dp(leftDp);
        return lp;
    }

    private int dp(float v) {
        return (int) (v * d + 0.5f);
    }

    private GradientDrawable box(int fill, int radiusPx, int stroke, int strokePx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radiusPx);
        if (stroke != 0) g.setStroke(strokePx, stroke);
        return g;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }
}
