package com.tradeexpert.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * The bot console card, in the layout of the console the user chose: the bot picture, the name and
 * the server status at the top; the console lines typed out in a black panel; and the footer with
 * "Powered by TradeExpert" and the stop and clear buttons. The colour follows the app's accent colour.
 */
class ConsoleCard {

    static final int DEFAULT_ACCENT = 0xFF10B981;   // the web app's default colour
    static final int FRAME = DEFAULT_ACCENT;         // the bubble ring uses this too
    static final int MUTED = 0xFFB8BDC7;
    static final int BTN = 0xFF141820;
    static final int BTN_EDGE = 0xFF3A3F4A;

    private static final int SPAN = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE;

    /** One console line. */
    private static final class Row {
        String text;      // the text to type (the lines the app writes)
        final boolean sep;
        int shown;        // how many letters are typed on the card
        TextView view;

        Row(String text, boolean sep) {
            this.text = text;
            this.sep = sep;
            this.shown = sep ? text.length() : 0;
        }
    }

    final FrameLayout root;
    /** The top bar (picture, name, status): drag the card by it. */
    final View header;
    private final Context ctx;
    private final float d;
    private final LinearLayout content;
    private final TextView nameTv, statusTv, stopBtn, poweredTv;
    private final ImageView picture;
    private final GradientDrawable picRing;
    private final LinearLayout logBox;
    private final ScrollView logScroll;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<Row> rows = new ArrayList<>();
    private boolean typingScheduled = false;
    private String lastImg = "";
    private Bitmap shownBitmap = null;
    private boolean lastRunning = false;
    private boolean dismissed = false;

    // the app's colours: accent, secondary (0 = none) and cycle speed
    private int accent = DEFAULT_ACCENT;
    private int secondary = 0;
    private float speed = 0.3f;
    private boolean cycling = false;

    private final Runnable cycler = new Runnable() {
        @Override
        public void run() {
            double t = (Math.sin(SystemClock.uptimeMillis() / 1000.0 * 2 * Math.PI * speed) + 1) / 2;
            setTint(mix(accent, otherColour(), (float) t));
            main.postDelayed(this, 50);
        }
    };

    ConsoleCard(Context c, Runnable onClose) {
        ctx = c;
        d = c.getResources().getDisplayMetrics().density;

        content = new LinearLayout(c);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setClipToOutline(true);
        content.setOutlineProvider(ViewOutlineProvider.BACKGROUND);

        // top bar: picture with a ring, name and server status, close
        LinearLayout top = new LinearLayout(c);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(10), dp(10), dp(8), dp(8));
        top.setBackgroundColor(0xFF0B0E14);
        header = top;

        FrameLayout pic = new FrameLayout(c);
        picRing = new GradientDrawable();
        picRing.setShape(GradientDrawable.OVAL);
        picRing.setStroke(dp(2), FRAME);
        picRing.setColor(0xFF05090F);
        pic.setBackground(picRing);
        picture = new ImageView(c);
        picture.setScaleType(ImageView.ScaleType.CENTER_CROP);
        picture.setImageResource(R.drawable.app_logo);
        picture.setClipToOutline(true);
        picture.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        pic.setPadding(dp(2), dp(2), dp(2), dp(2));
        pic.addView(picture, new FrameLayout.LayoutParams(-1, -1));
        top.addView(pic, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout info = new LinearLayout(c);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(10), 0, 0, 0);
        nameTv = text("BOT", 15, 0xFFFFFFFF, true);
        nameTv.setSingleLine(true);
        nameTv.setEllipsize(TextUtils.TruncateAt.END);
        nameTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        info.addView(nameTv);
        statusTv = text("● Server: Connected", 10, FRAME, true);
        statusTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        info.addView(statusTv);
        top.addView(info, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView close = text("✕", 12, 0xFFFFFFFF, true);
        close.setGravity(Gravity.CENTER);
        close.setBackground(box(0xFF141820, dp(14), 0xFF2A2F3A, dp(1)));
        close.setOnClickListener(v -> onClose.run());
        top.addView(close, new LinearLayout.LayoutParams(dp(28), dp(28)));
        content.addView(top, new LinearLayout.LayoutParams(-1, -2));

        // the console: black panel with the typed lines
        LinearLayout panel = new LinearLayout(c);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xFF000000);
        panel.setPadding(dp(12), dp(10), dp(12), dp(8));
        logBox = new LinearLayout(c);
        logBox.setOrientation(LinearLayout.VERTICAL);
        logScroll = new ScrollView(c);
        logScroll.setVerticalScrollBarEnabled(false);
        logScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        logScroll.addView(logBox, new FrameLayout.LayoutParams(-1, -2));
        panel.addView(logScroll, new LinearLayout.LayoutParams(-1, dp(120)));
        content.addView(panel, new LinearLayout.LayoutParams(-1, -2));

        // footer: "Powered by TradeExpert" (clear), stop and clear buttons
        LinearLayout footer = new LinearLayout(c);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.setBackgroundColor(0xFF0B0E14);
        footer.setPadding(dp(12), dp(6), dp(8), dp(8));
        poweredTv = text("Powered by TradeExpert", 11, 0xFFFFFFFF, true);
        poweredTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        footer.addView(poweredTv, new LinearLayout.LayoutParams(0, -2, 1f));
        stopBtn = iconButton("▢", "toggle");
        footer.addView(stopBtn, buttonParams(0));
        footer.addView(clearButton(), buttonParams(6));
        content.addView(footer, new LinearLayout.LayoutParams(-1, -2));

        content.setBackground(box(0xFF07090D, dp(12), FRAME, dp(2)));
        root = new FrameLayout(c);
        root.addView(content, new FrameLayout.LayoutParams(-1, -2));
        setTint(FRAME);
    }

    /** Stop the colour cycle (the card is being removed). */
    void stop() {
        cycling = false;
        main.removeCallbacks(cycler);
    }

    /** The bot picture arrived (or changed): show it on the card. */
    void refreshPicture() {
        Bitmap bm = BotPicture.bitmap;
        if (bm != null && bm != shownBitmap) {
            shownBitmap = bm;
            picture.setImageBitmap(bm);
        }
    }

    /**
     * Fill the card from the web data: the name, the picture and the colour. The console lines are
     * written by the app (see below), not by the page.
     */
    void update(String json) {
        try {
            JSONObject o = new JSONObject(json);
            String name = o.optString("name", "");
            nameTv.setText(name.isEmpty() ? "BOT" : name.toUpperCase());
            boolean running = o.optBoolean("running", false);
            stopBtn.setText(running ? "▢" : "▷");
            statusTv.setText(running ? "● Server: Connected" : "○ Standby");
            if (BotPicture.bitmap != null) refreshPicture();
            else loadImage(o.optString("img", ""));
            setAccent(o.optString("accent", ""), o.optString("secondary", ""), (float) o.optDouble("speed", 0.3));

            // the lines the app writes, as in the video (the page's console is not used)
            if (running != lastRunning) {
                lastRunning = running;
                dismissed = false;
            }
            List<Row> incoming = new ArrayList<>();
            if (running && !dismissed) {
                String bot = name.isEmpty() ? "BOT" : name;
                incoming.add(new Row(bot + " is connected", false));
                incoming.add(new Row("Servers online and EA is active", false));
                incoming.add(new Row("Waiting for a new live signal...", false));
            }

            // a line the page is still writing grows in place and keeps its typed letters
            int same = 0;
            while (same < rows.size() && same < incoming.size()) {
                Row have = rows.get(same);
                Row want = incoming.get(same);
                if (have.sep != want.sep) break;
                if (have.text.equals(want.text)) {
                    same++;
                } else if (!have.sep && want.text.startsWith(have.text)) {
                    have.text = want.text;
                    same++;
                } else {
                    break;
                }
            }
            while (rows.size() > same) {
                Row r = rows.remove(rows.size() - 1);
                if (r.view != null) logBox.removeView(r.view);
            }
            for (int i = same; i < incoming.size(); i++) {
                Row r = incoming.get(i);
                r.view = makeView(r);
                logBox.addView(r.view, new LinearLayout.LayoutParams(-1, -2));
                rows.add(r);
            }
            scheduleTyping();
            logScroll.fullScroll(View.FOCUS_DOWN);
        } catch (Exception ignored) {
        }
    }

    /** Take the app's colours. A change repaints the lines; the frame keeps cycling. */
    private void setAccent(String accentHex, String secondaryHex, float sp) {
        int a = parse(accentHex, DEFAULT_ACCENT);
        int s = parse(secondaryHex, 0);
        float newSpeed = sp > 0 ? Math.min(sp, 3f) : 0.3f;
        boolean changed = a != accent || s != secondary;
        accent = a;
        secondary = s;
        speed = newSpeed;
        if (changed) repaintAll();
        if (!cycling) {
            cycling = true;
            main.post(cycler);
        }
    }

    /** The second colour of the cycle: the app's secondary colour, or a light tint of the accent. */
    private int otherColour() {
        return secondary != 0 ? secondary : mix(accent, 0xFFFFFFFF, 0.45f);
    }

    /** Paint the frame, the picture ring and the status in one colour. */
    private void setTint(int c) {
        content.setBackground(box(0xFF07090D, dp(12), c, dp(2)));
        picRing.setStroke(dp(2), c);
        statusTv.setTextColor(c);
    }

    private void repaintAll() {
        for (Row r : rows) {
            if (r.view != null) paint(r, (TextView) r.view);
        }
    }

    private TextView makeView(Row r) {
        TextView t = new TextView(ctx);
        t.setTextSize(12);
        t.setTypeface(Typeface.MONOSPACE);
        t.setLineSpacing(0, 1.15f);
        t.setPadding(0, dp(2), 0, dp(2));
        if (r.sep) {
            t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            t.setLetterSpacing(0.1f);
            t.setPadding(0, dp(6), 0, dp(3));
        }
        paint(r, t);
        return t;
    }

    /** Write the typed part of the line: ">> " in the accent colour, then the text. */
    private void paint(Row r, TextView t) {
        int n = Math.min(r.shown, r.text.length());
        boolean typing = n < r.text.length();
        SpannableStringBuilder sb = new SpannableStringBuilder();
        if (r.sep) {
            sb.append(r.text.toUpperCase());
            sb.setSpan(new ForegroundColorSpan(accent), 0, sb.length(), SPAN);
        } else {
            sb.append(">> ");
            sb.setSpan(new ForegroundColorSpan(accent), 0, 2, SPAN);
            sb.setSpan(new StyleSpan(Typeface.BOLD), 0, 2, SPAN);
            int start = sb.length();
            sb.append(r.text, 0, n);
            sb.setSpan(new ForegroundColorSpan(mix(accent, 0xFFFFFFFF, 0.25f)), start, sb.length(), SPAN);
            if (typing) {
                sb.append("▌");
                sb.setSpan(new ForegroundColorSpan(accent), sb.length() - 1, sb.length(), SPAN);
            }
        }
        t.setText(sb);
    }

    private void scheduleTyping() {
        if (typingScheduled) return;
        typingScheduled = true;
        main.post(typer);
    }

    /** Types the lines letter by letter, a few letters per frame, so the card never freezes. */
    private final Runnable typer = new Runnable() {
        @Override
        public void run() {
            Row cur = null;
            int pending = 0;
            for (Row r : rows) {
                if (r.shown >= r.text.length()) continue;
                if (cur == null) cur = r;
                pending += r.text.length() - r.shown;
            }
            if (cur == null || cur.view == null) {
                typingScheduled = false;
                return;
            }
            int step = pending > 300 ? 12 : pending > 120 ? 6 : 3;
            cur.shown = Math.min(cur.text.length(), cur.shown + step);
            paint(cur, (TextView) cur.view);
            logScroll.fullScroll(View.FOCUS_DOWN);
            main.postDelayed(this, 16);
        }
    };

    /** Clear the card's lines until the bot is switched off and on again. */
    private void clearLines() {
        dismissed = true;
        for (Row r : rows) {
            if (r.view != null) logBox.removeView(r.view);
        }
        rows.clear();
    }

    private void loadImage(String img) {
        if (img == null || img.isEmpty() || img.equals(lastImg)) return;
        lastImg = img;
        if (img.startsWith("data:image")) {
            try {
                byte[] b = android.util.Base64.decode(img.substring(img.indexOf(',') + 1), android.util.Base64.DEFAULT);
                picture.setImageBitmap(BitmapFactory.decodeByteArray(b, 0, b.length));
            } catch (Exception ignored) {
            }
            return;
        }
        if (!img.startsWith("http")) return;
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(img).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                try (InputStream in = c.getInputStream()) {
                    Bitmap bm = BitmapFactory.decodeStream(in);
                    if (bm != null) main.post(() -> picture.setImageBitmap(bm));
                }
            } catch (Exception ignored) {
            }
        }).start();
    }

    private static int parse(String hex, int fallback) {
        try {
            return Color.parseColor(hex);
        } catch (Exception e) {
            return fallback;
        }
    }

    /** Colour a (0 = first, 1 = second). */
    static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private TextView iconButton(final String label, final String which) {
        TextView b = text(label, 13, 0xFFEDEDED, false);
        b.setGravity(Gravity.CENTER);
        b.setBackground(box(BTN, dp(7), BTN_EDGE, dp(1)));
        b.setOnClickListener(v -> PageHost.clickButton(which));
        return b;
    }

    private TextView clearButton() {
        TextView b = text("🗑", 13, 0xFFEDEDED, false);
        b.setGravity(Gravity.CENTER);
        b.setBackground(box(BTN, dp(7), BTN_EDGE, dp(1)));
        b.setOnClickListener(v -> clearLines());
        return b;
    }

    private LinearLayout.LayoutParams buttonParams(int leftDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(30), dp(30));
        lp.leftMargin = dp(leftDp);
        return lp;
    }

    private int dp(float v) {
        return (int) (v * d + 0.5f);
    }

    private GradientDrawable box(int fill, int radiusPx, int stroke, int strokePx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radiusPx);
        if (stroke != 0) g.setStroke(strokePx, stroke);
        return g;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }
}
