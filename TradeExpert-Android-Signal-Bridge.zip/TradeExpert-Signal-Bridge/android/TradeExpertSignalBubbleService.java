package com.tradeexpert.signalbridge;
import android.app.*;
import android.content.Intent;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.lang.ref.WeakReference;
public class TradeExpertSignalBubbleService extends Service {
 private static WeakReference<TradeExpertSignalBubbleService> current=new WeakReference<>(null);
 private final Handler handler=new Handler(Looper.getMainLooper());
 private WindowManager wm;
 private TextView bubble,feed;
 private View panel;
 private ScrollView scroll;
 private final StringBuilder history=new StringBuilder();
 private static final int GOLD=Color.rgb(245,197,24);
 private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 public static void deliver(String text,boolean signal){TradeExpertSignalBubbleService s=current.get();if(s!=null)s.handler.post(()->s.receive(text,signal));}
 @Override public void onCreate(){
  super.onCreate();if(!Settings.canDrawOverlays(this)){stopSelf();return;}
  String channel="tradeexpert-signals";
  if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel(channel,"TradeExpert signal bubble",NotificationManager.IMPORTANCE_LOW));
  Notification.Builder n=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,channel):new Notification.Builder(this);
  n.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("TradeExpert bubble enabled").setContentText("Waiting for app signal updates").setOngoing(true);
  Intent launch=getPackageManager().getLaunchIntentForPackage(getPackageName());
  if(launch!=null)n.setContentIntent(PendingIntent.getActivity(this,0,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
  startForeground(7341,n.build());wm=(WindowManager)getSystemService(WINDOW_SERVICE);current=new WeakReference<>(this);
  bubble=label("TE",16);bubble.setGravity(Gravity.CENTER);bubble.setBackground(surface());bubble.setContentDescription("Open TradeExpert signal console");
  WindowManager.LayoutParams p=params(dp(56),dp(56));
  bubble.setOnClickListener(v->{if(panel==null)open();else collapse();});drag(bubble,bubble,p);
  try{wm.addView(bubble,p);}catch(RuntimeException e){stopSelf();}
 }
 private GradientDrawable surface(){GradientDrawable d=new GradientDrawable();d.setColor(Color.rgb(5,5,5));d.setCornerRadius(dp(8));d.setStroke(dp(1),GOLD);return d;}
 private TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(GOLD);t.setTextSize(size);t.setPadding(dp(10),dp(8),dp(10),dp(8));return t;}
 private WindowManager.LayoutParams params(int w,int h){
  WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
  p.gravity=Gravity.TOP|Gravity.LEFT;p.x=dp(8);p.y=Math.max(0,Math.min(dp(120),getResources().getDisplayMetrics().heightPixels-h));return p;
 }
 private void open(){
  LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setBackground(surface());
  LinearLayout row=new LinearLayout(this);TextView title=label("TradeExpert · SIGNAL CONSOLE",12);row.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));
  TextView close=label("×",22);close.setContentDescription("Collapse console");close.setOnClickListener(v->collapse());row.addView(close);box.addView(row);
  scroll=new ScrollView(this);feed=label(history.toString(),11);feed.setTypeface(Typeface.MONOSPACE);scroll.addView(feed);box.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  box.addView(label("Powered by TradeExpert",10));
  WindowManager.LayoutParams p=params(Math.min(dp(304),getResources().getDisplayMetrics().widthPixels-dp(16)),Math.min(dp(360),getResources().getDisplayMetrics().heightPixels-dp(24)));
  drag(title,box,p);panel=box;try{wm.addView(box,p);}catch(RuntimeException e){panel=null;feed=null;scroll=null;}
 }
 private void receive(String text,boolean signal){
  if(!Settings.canDrawOverlays(this)){stopSelf();return;}if(text==null||text.isEmpty())return;
  history.append(">> ").append(text.length()>2000?text.substring(0,2000):text).append("\n\n");
  if(history.length()>24000)history.delete(0,history.length()-20000);
  if(signal&&bubble!=null){bubble.setText("SIG");bubble.setContentDescription("New TradeExpert signal received");}
  if(panel!=null&&feed!=null){feed.setText(history.toString());scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));}
 }
 private void drag(View handle,View window,WindowManager.LayoutParams p){handle.setOnTouchListener(new View.OnTouchListener(){
  float sx,sy;int x,y;boolean moved;
  public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){
   case MotionEvent.ACTION_DOWN:sx=e.getRawX();sy=e.getRawY();x=p.x;y=p.y;moved=false;return true;
   case MotionEvent.ACTION_MOVE:float dx=e.getRawX()-sx,dy=e.getRawY()-sy;if(Math.abs(dx)+Math.abs(dy)>dp(6))moved=true;
    p.x=Math.max(0,Math.min(getResources().getDisplayMetrics().widthPixels-p.width,x+(int)dx));p.y=Math.max(0,Math.min(getResources().getDisplayMetrics().heightPixels-p.height,y+(int)dy));wm.updateViewLayout(window,p);return true;
   case MotionEvent.ACTION_UP:if(!moved)v.performClick();return true;
   case MotionEvent.ACTION_CANCEL:return true;
  }return false;}
 });}
 private void collapse(){if(panel!=null){wm.removeView(panel);panel=null;feed=null;scroll=null;}if(bubble!=null)bubble.setText("TE");}
 @Override public int onStartCommand(Intent i,int flags,int id){return START_NOT_STICKY;}
 @Override public IBinder onBind(Intent i){return null;}
 @Override public void onDestroy(){current.clear();handler.removeCallbacksAndMessages(null);if(wm!=null){collapse();if(bubble!=null&&bubble.isAttachedToWindow())wm.removeView(bubble);}stopForeground(true);super.onDestroy();}
}
