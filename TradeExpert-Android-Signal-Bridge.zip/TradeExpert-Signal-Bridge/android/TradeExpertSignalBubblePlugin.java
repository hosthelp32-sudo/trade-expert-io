package com.tradeexpert.signalbridge;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
@CapacitorPlugin(name="TradeExpertSignalBubble")
public class TradeExpertSignalBubblePlugin extends Plugin {
 @PluginMethod public void permission(PluginCall c){JSObject o=new JSObject();o.put("granted",Settings.canDrawOverlays(getContext()));c.resolve(o);}
 @PluginMethod public void requestPermission(PluginCall c){getActivity().startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getContext().getPackageName())));c.resolve();}
 @PluginMethod public void start(PluginCall c){
  if(!Settings.canDrawOverlays(getContext())){c.reject("Allow Display over other apps first");return;}
  try{Intent i=new Intent(getContext(),TradeExpertSignalBubbleService.class);if(Build.VERSION.SDK_INT>=26)getContext().startForegroundService(i);else getContext().startService(i);c.resolve();}
  catch(Exception e){c.reject("Enable the bubble while the Android app is open",e);}
 }
 @PluginMethod public void event(PluginCall c){TradeExpertSignalBubbleService.deliver(c.getString("text",""),Boolean.TRUE.equals(c.getBoolean("signal",false)));c.resolve();}
 @PluginMethod public void stop(PluginCall c){getContext().stopService(new Intent(getContext(),TradeExpertSignalBubbleService.class));c.resolve();}
}
