# TradeExpert signal-to-Android-bubble source package

For an EXISTING full TradeExpert Capacitor Android project. Not a standalone app, not an APK, and not a replacement backend. This is a NEW plugin independent of the earlier FloatingConsole package.

## How signals arrive
Platform SendSignalCard / mentor self-host EA -> existing ea-self-host function -> signals table -> existing BotConsoleProvider realtime/poll listener -> console receipt marker -> AndroidSignalBridge -> native bubble changes TE to SIG. Tap bubble to read the growing feed. Signal receipt is NOT a broker fill. This package only displays messages; it never places orders or adds a duplicate trading listener.

## Integrate into your GitHub project
1. Git pull your full TradeExpert project. Keep compatible Capacitor core/CLI/Android versions. Use Android Studio with compileSdk/targetSdk 34+.
2. Copy web/androidSignalBridge.ts to src/lib/androidSignalBridge.ts. Copy web/AndroidSignalBridge.tsx to src/components/ea-app/AndroidSignalBridge.tsx.
3. Import AndroidSignalBridge in EALayout.tsx. Mount <AndroidSignalBridge /> once beside <GlobalBotOverlay />, INSIDE BotConsoleProvider. Existing console/context/formatter files are required.
4. Put both Java files in android/app/src/main/java/com/tradeexpert/signalbridge/.
5. Register the plugin in your existing MainActivity before super.onCreate (keep your actual MainActivity package):

```java
@Override public void onCreate(android.os.Bundle savedInstanceState) {
 registerPlugin(com.tradeexpert.signalbridge.TradeExpertSignalBubblePlugin.class);
 super.onCreate(savedInstanceState);
}
```

6. Merge manifest-additions.xml at the marked locations. Android 13+ POST_NOTIFICATIONS should be requested through your app's normal permissions UI. Overlay permission is separate. Notification denial may hide the service notification from the notification drawer.
7. Add explicit Enable/Disable settings actions with your existing Button:

```tsx
import { enableSignalBubble, disableSignalBubble } from '@/lib/androidSignalBridge';
// Enable button: await enableSignalBubble();
// If false, return from Android Settings and tap Enable again.
// Disable button: await disableSignalBubble();
```

Start the foreground service only while the Android app is visible. Show errors through existing toast UI. The bridge never starts the service from an incoming background signal.
8. npm install; npm run build; npx cap sync android; npx cap open android. Build/install an APK in Android Studio. Future updates: git pull, build, npx cap sync.

## Real-device checks required
Enable Display over other apps. Start the licensed bot, configure symbols and connect the account. Send a fresh platform signal for that bot: TE must change to SIG, tap to read actual direction/symbol/levels. Repeat from self-host. Drag bubble/header, collapse and disable. Verify trade requests/counts do not increase due to this adapter. Test switching apps and force-stop separately.

## Limitations
The bubble can stay above other apps, but messages still come from the existing JavaScript listener. Android can suspend that listener or kill the app. A foreground overlay service does NOT guarantee background signal delivery. Reliable delivery with the app suspended/closed needs additional native authenticated messaging or server push integration; neither is included here. After force-stop this service does not restart itself. Enable again from the app.

Current provider status behavior is preserved, including its upstream limitations: open receipt markers are forwarded; modify/close receipt markers do not prove the broker completed changes. The plugin independently verifies no fills. Keep server license/ownership enforcement; never embed private keys or trading passwords.

Native display is compact black/gold text, draggable bubble and panel with Powered by TradeExpert. It does not reproduce portrait/video/typewriter visuals pixel-for-pixel. Browser console is unchanged. Android-only; not supported on iPhone or plain HTML.

Source inspected and packaged only; no APK compilation or live trading/device test performed. Google Play may require special-use foreground-service declarations and review.

Read the Capacitor guide https://capacitorjs.com/docs/getting-started and Lovable mobile-app blog guidance at https://lovable.dev/blog (search Capacitor).
