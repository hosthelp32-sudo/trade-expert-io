import { Capacitor, registerPlugin } from '@capacitor/core';
interface BubblePlugin {
  permission(): Promise<{granted:boolean}>;
  requestPermission(): Promise<void>;
  start(): Promise<void>;
  event(options:{text:string;signal:boolean}): Promise<void>;
  stop(): Promise<void>;
}
const plugin=registerPlugin<BubblePlugin>('TradeExpertSignalBubble');
export const isAndroidBubble=()=>Capacitor.isNativePlatform() && Capacitor.getPlatform()==='android';
export async function enableSignalBubble(){
  if(!isAndroidBubble())return false;
  if(!(await plugin.permission()).granted){await plugin.requestPermission();return false;}
  await plugin.start();return true;
}
export async function disableSignalBubble(){if(isAndroidBubble())await plugin.stop();}
export async function forwardConsoleLine(text:string,signal:boolean){if(isAndroidBubble())await plugin.event({text,signal});}
