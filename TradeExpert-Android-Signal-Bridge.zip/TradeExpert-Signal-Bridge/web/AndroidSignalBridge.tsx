import {useEffect,useRef} from 'react';
import {useBotConsole} from '@/contexts/BotConsoleContext';
import {formatConsoleMessage} from '@/lib/consoleMessage';
import {forwardConsoleLine} from '@/lib/androidSignalBridge';
export default function AndroidSignalBridge(){
 const {consoleLogs}=useBotConsole();
 const last=useRef<(typeof consoleLogs)[number]|undefined>();
 const ready=useRef(false);
 const queue=useRef<Promise<void>>(Promise.resolve());
 useEffect(()=>{
  if(!ready.current){ready.current=true;last.current=consoleLogs[consoleLogs.length-1];return;}
  if(!consoleLogs.length){last.current=undefined;return;}
  const previous=last.current?consoleLogs.indexOf(last.current):-1;
  const fresh=consoleLogs.slice(previous+1);
  last.current=consoleLogs[consoleLogs.length-1];
  for(const log of fresh){
   queue.current=queue.current.then(()=>forwardConsoleLine(formatConsoleMessage(log.msg),log.msg.includes('━━━ SIGNAL RECEIVED')))
    .catch(()=>{/* Overlay failure must not affect order execution. */});
  }
 },[consoleLogs]);
 return null;
}
