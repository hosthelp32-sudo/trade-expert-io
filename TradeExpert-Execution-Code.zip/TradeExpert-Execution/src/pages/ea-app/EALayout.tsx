// EA App Layout wrapper
import { useEffect } from "react";
import { Outlet } from "react-router-dom";
import { EAAppSettingsProvider, useEAAppSettings } from "@/contexts/EAAppSettingsContext";
import { BotConsoleProvider } from "@/contexts/BotConsoleContext";
import GlobalBotOverlay from "@/components/ea-app/GlobalBotOverlay";
import BackgroundVideoPeek from "@/components/ea-app/BackgroundVideoPeek";

import { ReleaseBanner } from "@/components/ReleaseBanner";
import UpdatePrompt from "@/components/UpdatePrompt";
import SubscriptionNotice from "@/components/ea-app/SubscriptionNotice";
import "./ea-font.css";


const EALayoutInner = () => {
  // Hydrate the user's symbol allow-list from their account. iOS home-screen
  // apps have their own storage bucket, so without this the installed app
  // starts with an empty allow-list and cloud hosting refuses to trade.
  useEffect(() => {
    import("@/lib/symbolConfigs").then(({ loadSymbolConfigs }) => { void loadSymbolConfigs(); });
    // Warm up the speech engine + arm the Android gesture unlock so the app
    // talks on Android exactly like it does on iOS.
    import("@/utils/speak").then(({ warmUpSpeech }) => warmUpSpeech());
  }, []);

  const { interfaceStyle, accentColor, accentSecondary, glass, colorSpeed } = useEAAppSettings();

  const isV3 = interfaceStyle === "V3 Neon";
  const glassDisabled = interfaceStyle !== "V5 Aurora";
  // Slower colorSpeed = longer duration. Map 0.1..1 → 14s..3s
  const dur = Math.max(2, 16 - (colorSpeed || 0.3) * 14);
  // 2-in-1 / duo theme: primary fills surfaces, secondary is text/borders
  const isDuo = !!accentSecondary;
  const isSnow = accentColor.toLowerCase() === "#ffffff" && isDuo;

  // Pure accent background — clear color (blue stays blue, red stays red, etc.)
  const bg = accentColor;
  // Derive readable foreground from accent luminance
  const hex = accentColor.replace("#", "");
  const r = parseInt(hex.slice(0, 2), 16) || 0;
  const g = parseInt(hex.slice(2, 4), 16) || 0;
  const b = parseInt(hex.slice(4, 6), 16) || 0;
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  const autoFg = luminance > 0.6 ? "#0a0a0a" : "#ffffff";
  const fg = isDuo ? (accentSecondary as string) : autoFg;
  const themeAttr = isSnow ? "snow" : isDuo ? "duo" : "dark";
  return (
    <div
      className="ea-app-font min-h-screen flex flex-col items-center justify-center"
      data-ea-running={glass.animatedBorders ? "on" : "off"}
      data-ea-glass={glass.glassMorphism && !glassDisabled ? "on" : "off"}
      data-ea-theme={themeAttr}
      style={{
        backgroundColor: "#000000",
        color: fg,
        fontFamily: "var(--ea-font)",
        ["--ea-running-dur" as any]: `${dur}s`,
        ["--ea-bg" as any]: bg,
        ["--ea-fg" as any]: fg,
      }}
    >
      <div
        className={`${isV3 || interfaceStyle === "V5 Aurora" ? "w-full" : "w-full max-w-md mx-auto"} min-h-screen flex flex-col relative`}
        style={{ backgroundColor: "#000000" }}
      >
        <ReleaseBanner />
        <SubscriptionNotice />
        <Outlet />
      </div>
      <GlobalBotOverlay />
      <BackgroundVideoPeek />
      <UpdatePrompt />

    </div>
  );
};

const EALayout = () => {
  return (
    <EAAppSettingsProvider>
      <BotConsoleProvider>
        <EALayoutInner />
      </BotConsoleProvider>
    </EAAppSettingsProvider>
  );
};

export default EALayout;
