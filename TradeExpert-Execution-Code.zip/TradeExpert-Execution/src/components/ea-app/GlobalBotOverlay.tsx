import { useState, useRef, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { GripHorizontal, X, Square, Play, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useBotConsole } from "@/contexts/BotConsoleContext";
import { useEAAppSettings } from "@/contexts/EAAppSettingsContext";
import { getMTCredentials } from "@/utils/mtCredentials";
import "./bot-console.css";
import { formatConsoleMessage } from "@/lib/consoleMessage";
import botAvatarDefault from "@/assets/tradeexpert-logo.png";

const MIN_W = 260;
const MIN_H = 300;
const DEFAULT_W = 304;
const DEFAULT_H = 420;

// Theme — frame color follows user-selected accent; fallback to gold
const GOLD_FALLBACK = "#f5c518";

// Typewriter speed (ms per character) — quick terminal feel like the reference clip
const TYPE_SPEED = 26;
// Short pause between lines so the feed reads as a live terminal
const LINE_PAUSE = 180;

type LogItem = { msg: string; type: string; color?: string };

// Sequential typewriter console — types one line at a time, slowly,
// only advancing to the next line once the current one is fully written.
const SequentialConsole = ({
  logs,
  gold,
  colorFor,
}: {
  logs: LogItem[];
  gold: string;
  colorFor: (log: LogItem) => string;
}) => {
  const [done, setDone] = useState(0); // fully-typed lines
  const [shown, setShown] = useState(0); // chars shown of current line

  // Reset when logs are cleared / shrink
  useEffect(() => {
    if (logs.length < done) {
      setDone(0);
      setShown(0);
    }
  }, [logs.length, done]);

  const currentMessage = logs[done] ? formatConsoleMessage(logs[done].msg) : undefined;

  // Drive the typing of the current line. Depending on the message string
  // instead of the whole logs array prevents a newly queued line from
  // restarting the line that is already being written.
  useEffect(() => {
    if (!currentMessage) return;
    const isSeparator = currentMessage.includes("━━━");

    if (isSeparator) {
      const t = setTimeout(() => setDone((d) => d + 1), LINE_PAUSE);
      return () => clearTimeout(t);
    }

    setShown(0);
    let i = 0;
    let timer: ReturnType<typeof setTimeout>;
    const writeNext = () => {
      i += 1;
      setShown(i);
      timer = setTimeout(
        i >= currentMessage.length ? () => setDone((d) => d + 1) : writeNext,
        i >= currentMessage.length ? LINE_PAUSE : TYPE_SPEED,
      );
    };
    timer = setTimeout(writeNext, TYPE_SPEED);
    return () => clearTimeout(timer);
  }, [currentMessage, done]);

  const renderLine = (log: LogItem, i: number, text: string, typing: boolean) => {
    if (log.msg.includes("━━━")) {
      const label = log.msg.replace(/━/g, "").trim();
      return <div key={i} className="bot-console-status py-1 text-[10px] font-bold">{label}</div>;
    }

    const bare = log.msg.startsWith("~");
    const body = bare ? text.replace(/^~/, "") : text;
    return (
      <div key={i} className={`bot-console-line ${log.type === "success" ? "bot-console-line-success" : log.type === "warn" ? "bot-console-line-warning" : ""} grid min-w-0 items-start gap-x-2 text-[11px] leading-[1.8] ${bare ? "grid-cols-1" : "grid-cols-[auto_minmax(0,1fr)]"}`}>
        {!bare && <span className="bot-console-status select-none">&gt;&gt;</span>}
        <span className="min-w-0 whitespace-pre-wrap break-words [overflow-wrap:anywhere]">
          {body}{typing && <span className="bot-console-caret ml-0.5 inline-block h-3 w-1.5 translate-y-0.5" />}
        </span>
      </div>
    );
  };

  return (
    <>
      {logs.slice(0, done).map((log, i) => renderLine(log, i, formatConsoleMessage(log.msg), i === logs.length - 1))}
      {done < logs.length &&
        renderLine(
          logs[done],
          done,
          logs[done].msg.includes("━━━") ? logs[done].msg : (currentMessage || "").slice(0, shown),
          !logs[done].msg.includes("━━━"),
        )}
    </>
  );
};

const GlobalBotOverlay = () => {
  const { accentColor } = useEAAppSettings();
  const GOLD = accentColor || GOLD_FALLBACK;
  const GOLD_DIM = accentColor || GOLD_FALLBACK;
  const {
    botRunning, setBotRunning, showStartPopup, setShowStartPopup, showConsole, setShowConsole,
    consoleLogs, setConsoleLogs, botImageUrl, botName,
  } = useBotConsole();

  const imgSrc = botImageUrl || botAvatarDefault;
  // Position & size state
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const [size, setSize] = useState({ w: DEFAULT_W, h: DEFAULT_H });
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [centered, setCentered] = useState(false);

  useEffect(() => {
    if (showConsole && !centered) {
      const w = Math.min(DEFAULT_W, window.innerWidth - 16);
      const h = Math.min(DEFAULT_H, window.innerHeight - 24);
      setSize({ w, h });
      setPos({
        x: Math.max(0, (window.innerWidth - w) / 2),
        y: Math.max(0, (window.innerHeight - h) / 2),
      });
      setCentered(true);
    }
  }, [showConsole, centered]);

  // Drag
  const dragRef = useRef<{ pointerId: number; startX: number; startY: number; posX: number; posY: number; width: number; height: number } | null>(null);
  const onDragPointerDown = useCallback((e: React.PointerEvent) => {
    if (isFullscreen || !e.isPrimary || e.button !== 0) return;
    e.stopPropagation();
    e.preventDefault();
    const bounds = e.currentTarget.closest('[role="dialog"]')?.getBoundingClientRect();
    dragRef.current = { pointerId: e.pointerId, startX: e.clientX, startY: e.clientY, posX: pos.x, posY: pos.y, width: bounds?.width ?? size.w, height: bounds?.height ?? size.h };
    e.currentTarget.setPointerCapture(e.pointerId);
  }, [pos, size, isFullscreen]);

  const onDragPointerMove = useCallback((e: React.PointerEvent) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== e.pointerId) return;
    setPos({
      x: Math.max(0, Math.min(window.innerWidth - drag.width, drag.posX + e.clientX - drag.startX)),
      y: Math.max(0, Math.min(window.innerHeight - drag.height, drag.posY + e.clientY - drag.startY)),
    });
  }, []);

   const onDragPointerEnd = useCallback((e: React.PointerEvent) => {
    if (dragRef.current?.pointerId !== e.pointerId) return;
    dragRef.current = null;
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
  }, []);

  useEffect(() => {
    const fitToViewport = () => {
      if (isFullscreen) {
        setSize({ w: window.innerWidth, h: window.innerHeight });
        return;
      }
      setSize((current) => ({ w: Math.min(current.w, window.innerWidth - 16), h: Math.min(current.h, window.innerHeight - 24) }));
      setPos((current) => ({ x: Math.max(0, Math.min(current.x, window.innerWidth - size.w)), y: Math.max(0, Math.min(current.y, window.innerHeight - size.h)) }));
    };
    window.addEventListener("resize", fitToViewport);
    return () => window.removeEventListener("resize", fitToViewport);
  }, [size, isFullscreen]);

  // Resize
  const resizeRef = useRef<{ startX: number; startY: number; w: number; h: number } | null>(null);
  const onResizePointerDown = useCallback((e: React.PointerEvent) => {
    if (isFullscreen) return;
    e.stopPropagation();
    e.preventDefault();
    resizeRef.current = { startX: e.clientX, startY: e.clientY, w: size.w, h: size.h };
    const onMove = (ev: PointerEvent) => {
      if (!resizeRef.current) return;
      const dx = ev.clientX - resizeRef.current.startX;
      const dy = ev.clientY - resizeRef.current.startY;
      setSize({
        w: Math.min(window.innerWidth - pos.x, Math.max(MIN_W, resizeRef.current.w + dx)),
        h: Math.min(window.innerHeight - pos.y, Math.max(MIN_H, resizeRef.current.h + dy)),
      });
    };
    const onUp = () => {
      resizeRef.current = null;
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  }, [size, pos, isFullscreen]);

  const toggleFullscreen = () => {
    if (isFullscreen) {
      const w = Math.min(DEFAULT_W, window.innerWidth - 16);
      const h = Math.min(DEFAULT_H, window.innerHeight - 24);
      setSize({ w, h });
      setPos({
        x: Math.max(0, (window.innerWidth - w) / 2),
        y: Math.max(0, (window.innerHeight - h) / 2),
      });
      setIsFullscreen(false);
    } else {
      setPos({ x: 0, y: 0 });
      setSize({ w: window.innerWidth, h: window.innerHeight });
      setIsFullscreen(true);
    }
  };

  // MT account connection state
  const [hasAccount, setHasAccount] = useState(false);
  useEffect(() => {
    getMTCredentials(true).then((creds) => setHasAccount(!!creds));
  }, []);
  useEffect(() => {
    if (!showConsole) return;
    getMTCredentials(true).then((creds) => setHasAccount(!!creds));
    const id = setInterval(() => {
      getMTCredentials(true).then((creds) => setHasAccount(!!creds));
    }, 10_000);
    return () => clearInterval(id);
  }, [showConsole]);

  // Console feed grows with its content, then scrolls at the cap
  const consoleRef = useRef<HTMLDivElement>(null);
  const feedInnerRef = useRef<HTMLDivElement>(null);
  const FEED_HEADER_H = 0;
  const MIN_FEED_CONTENT = 68;
  const maxFeed = isFullscreen
    ? Math.max(320, window.innerHeight * 0.72)
    : Math.max(44, size.h - 270);
  const [contentH, setContentH] = useState(MIN_FEED_CONTENT);

  useEffect(() => {
    const el = feedInnerRef.current;
    if (!el) return;
    const measure = () => setContentH(Math.max(MIN_FEED_CONTENT, el.scrollHeight));
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, [showConsole]);

  const feedHeight = Math.min(maxFeed, FEED_HEADER_H + contentH);
  const atMaxHeight = FEED_HEADER_H + contentH >= maxFeed;

  // Auto-scroll to latest once the box is capped
  useEffect(() => {
    if (atMaxHeight && consoleRef.current) {
      consoleRef.current.scrollTo({
        top: consoleRef.current.scrollHeight,
        behavior: "smooth",
      });
    }
  }, [contentH, atMaxHeight]);


  // The reference console is monochrome: every line follows the interface
  // accent, even when the underlying trading event carries a semantic colour.
  const colorFor = () => GOLD;


  return (
    <>
      <AnimatePresence>
        {showStartPopup && (
          <motion.div initial={{ scale: 0.3, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.3, opacity: 0 }} className="fixed bottom-20 right-4 z-50">
            <Button variant="ghost" size="icon" aria-label="Open bot console" onClick={() => setShowConsole(true)} className="bot-console-bubble h-14 w-14 overflow-hidden rounded-full p-0">
              <img src={imgSrc} alt={botName} className="h-full w-full object-cover" />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {showConsole && (
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} transition={{ duration: 0.18 }}
            className="bot-console fixed z-[60] flex flex-col overflow-hidden" role="dialog" aria-label="Bot console"
            style={{ left: pos.x, top: pos.y, width: isFullscreen ? "100vw" : size.w, height: isFullscreen ? "100dvh" : "auto", maxHeight: isFullscreen ? "100dvh" : size.h }}>
            <div className="bot-console-portrait relative shrink-0 overflow-hidden cursor-grab active:cursor-grabbing touch-none select-none"
              style={{ height: isFullscreen ? "40vh" : 232 }}
              title="Drag to move" aria-label="Move bot console by image"
              onPointerDown={onDragPointerDown} onPointerMove={onDragPointerMove} onPointerUp={onDragPointerEnd} onPointerCancel={onDragPointerEnd} onLostPointerCapture={onDragPointerEnd}>
              <img src={imgSrc} alt={botName} draggable={false} className="pointer-events-none h-full w-full object-cover object-center" />
              <div className="absolute inset-x-0 top-0 z-10 flex h-10 items-center justify-between px-2 cursor-grab touch-none"
                title="Drag to move" aria-label="Move bot console" onDoubleClick={toggleFullscreen}
                onPointerDown={onDragPointerDown} onPointerMove={onDragPointerMove} onPointerUp={onDragPointerEnd} onPointerCancel={onDragPointerEnd} onLostPointerCapture={onDragPointerEnd}>
                <GripHorizontal className="bot-console-status h-4 w-4" aria-hidden="true" />
                <Button type="button" variant="ghost" size="icon" aria-label="Close bot console" className="bot-console-control h-7 w-7 rounded-full" onClick={() => setShowConsole(false)} onPointerDown={(e) => e.stopPropagation()}><X className="h-4 w-4" /></Button>
              </div>
              <div className="absolute inset-x-0 bottom-0 z-10 px-4 pb-4">
                <h2 className="bot-console-name mb-2 break-words text-[20px] font-bold leading-tight">{botName}</h2>
                <div className="bot-console-status flex items-center gap-2 text-[9px] font-bold uppercase">
                  <span className="bot-console-dot h-1.5 w-1.5 shrink-0 rounded-full" />
                  {hasAccount ? "Account connected" : "Account not connected"}
                </div>
              </div>
            </div>
            <motion.div ref={consoleRef} className="bot-console-feed w-full min-h-0 shrink-0" animate={{ height: feedHeight }} transition={{ duration: 0.18 }}
              style={{ overflowY: atMaxHeight ? "auto" : "hidden", overflowX: "hidden", overscrollBehavior: "contain" }}>
              <div ref={feedInnerRef} className="min-w-0 space-y-1 px-4 py-3">
                {consoleLogs.length === 0 && <span className="bot-console-caret inline-block h-3 w-1.5" />}
                <SequentialConsole logs={consoleLogs} gold={GOLD} colorFor={colorFor} />
              </div>
            </motion.div>
            <div className="bot-console-footer flex h-9 shrink-0 items-center justify-between gap-2 px-3">
              <span className="text-[8px]">Powered by TradeExpert</span>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" className="bot-console-control h-6 w-6 rounded" title={botRunning ? "Stop EA" : "Start EA"} aria-label={botRunning ? "Stop EA" : "Start EA"} onClick={() => { const next = !botRunning; setBotRunning(next); setShowStartPopup(next); }}>
                  {botRunning ? <Square className="h-2.5 w-2.5" /> : <Play className="h-2.5 w-2.5" />}
                </Button>
                <Button variant="ghost" size="icon" className="bot-console-control h-6 w-6 rounded" title="Clear console" aria-label="Clear console" onClick={() => setConsoleLogs([])}><Trash2 className="h-2.5 w-2.5" /></Button>
              </div>
            </div>
            {!isFullscreen && <div className="absolute bottom-0 right-0 h-3 w-3 cursor-nwse-resize touch-none" aria-label="Resize bot console" onPointerDown={onResizePointerDown} />}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default GlobalBotOverlay;
