import { useState } from "react";
import { motion } from "framer-motion";
import { Send, TrendingUp, TrendingDown, Bot } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const SendSignalCard = () => {
  const { user } = useAuth();
  const [symbol, setSymbol] = useState("");
  const [direction, setDirection] = useState<"BUY" | "SELL">("BUY");
  const [tp, setTp] = useState("");
  const [sl, setSl] = useState("");
  const [selectedEaId, setSelectedEaId] = useState("");
  const [sending, setSending] = useState(false);

  const { data: eas } = useQuery({
    queryKey: ["expert-advisors", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("expert_advisors")
        .select("id, name, symbol, ea_code")
        .eq("user_id", user!.id)
        .order("name");
      if (error) throw error;
      return data || [];
    },
    enabled: !!user,
  });

  // Get available symbols for the selected EA
  const selectedEa = eas?.find(e => e.id === selectedEaId);
  const eaSymbols = selectedEa?.symbol
    ? selectedEa.symbol.split(/[,\s;|]+/).map(s => s.trim()).filter(s => s.length > 0)
    : [];

  const handleSend = async () => {
    if (!user) return;
    if (!symbol.trim()) { toast.error("Enter a symbol"); return; }
    if (!selectedEaId) { toast.error("Select an EA to send signal to"); return; }

    const selectedEaObj = eas?.find(e => e.id === selectedEaId);
    if (!selectedEaObj?.ea_code) { toast.error("EA has no code configured"); return; }

    setSending(true);

    // Pull mentor's per-symbol lot size + number of trades from local setup
    let lotSize = "0.01";
    let numTrades = 1;
    try {
      const raw = localStorage.getItem("ea_allowed_symbols");
      if (raw) {
        const arr: Array<{ symbol: string; lotSize: number; maxTrades: number }> = JSON.parse(raw) || [];
        const canon = (s: string) => String(s || "").trim().toUpperCase()
          .replace(/\.(m|pro|raw|ecn|std|micro|mini|c|i|s)$/i, "")
          .replace(/[\/\-_\s]/g, "");
        const match = arr.find((c) => canon(c.symbol) === canon(symbol));
        if (match) {
          lotSize = String(match.lotSize || 0.01);
          numTrades = Math.max(1, Number(match.maxTrades) || 1);
        }
      }
    } catch { /* ignore */ }

    // Route through ea-self-host so signal reaches clients AND platform-hosted EAs
    const { data, error } = await supabase.functions.invoke("ea-self-host", {
      body: {
        ea_code: selectedEaObj.ea_code,
        action: "open",
        symbol: symbol.trim(),
        direction,
        take_profit: tp.trim() || "",
        stop_loss: sl.trim() || "",
        entry_price: "",
        lot_size: lotSize,
        num_trades: numTrades,
        master_ticket: "",
      },
    });


    if (error || (data && !data.success)) {
      toast.error(data?.error || "Failed to send signal");
    } else {
      toast.success(`Signal sent: ${direction} ${symbol.toUpperCase()} → ${selectedEaObj.name}`);
      setSymbol("");
      setTp("");
      setSl("");
    }
    setSending(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.35, duration: 0.4 }}
      className="rounded-2xl border border-border bg-card p-5 mt-6"
    >
      <div className="flex items-center gap-2 mb-4">
        <Send size={18} className="text-primary" />
        <h2 className="text-sm font-bold text-foreground tracking-wide">Send Signal to Clients</h2>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-3">
        {/* Target EA */}
        <div className="col-span-2">
          <label className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest mb-1 block">Send to EA</label>
          <Select value={selectedEaId} onValueChange={(id) => {
            setSelectedEaId(id);
            setSymbol(""); // Reset symbol when EA changes
          }}>
            <SelectTrigger className="rounded-xl bg-muted/50 border-border">
              <SelectValue placeholder="Choose an Expert Advisor" />
            </SelectTrigger>
            <SelectContent>
              {(eas || []).map((ea) => (
                <SelectItem key={ea.id} value={ea.id}>
                  <div className="flex items-center gap-2">
                    <Bot size={14} className="text-primary" />
                    {ea.name}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Symbol - restricted to EA's configured symbols */}
        <div className="col-span-2 sm:col-span-1">
          <label className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest mb-1 block">Symbol</label>
          {eaSymbols.length > 0 ? (
            <Select value={symbol} onValueChange={setSymbol}>
              <SelectTrigger className="rounded-xl bg-muted/50 border-border">
                <SelectValue placeholder="Select symbol" />
              </SelectTrigger>
              <SelectContent>
                {eaSymbols.map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : (
            <div className="px-3 py-2.5 rounded-xl bg-muted/50 border border-border text-muted-foreground/50 text-sm">
              {selectedEaId ? "No symbols configured on this EA" : "Select an EA first"}
            </div>
          )}
        </div>

        {/* Direction */}
        <div className="col-span-2 sm:col-span-1">
          <label className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest mb-1 block">Direction</label>
          <div className="flex gap-2">
            <button
              onClick={() => setDirection("BUY")}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl border text-sm font-bold transition-all ${
                direction === "BUY"
                  ? "bg-accent/15 border-accent/40 text-accent"
                  : "bg-muted/30 border-border text-muted-foreground"
              }`}
            >
              <TrendingUp size={14} />
              BUY
            </button>
            <button
              onClick={() => setDirection("SELL")}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl border text-sm font-bold transition-all ${
                direction === "SELL"
                  ? "bg-destructive/15 border-destructive/40 text-destructive"
                  : "bg-muted/30 border-border text-muted-foreground"
              }`}
            >
              <TrendingDown size={14} />
              SELL
            </button>
          </div>
        </div>

        {/* TP */}
        <div>
          <label className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest mb-1 block">Take Profit</label>
          <input
            type="text"
            value={tp}
            onChange={(e) => setTp(e.target.value)}
            placeholder="e.g. 105000"
            className="w-full px-3 py-2.5 rounded-xl bg-muted/50 border border-border text-foreground text-sm placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/40 transition-colors"
          />
        </div>

        {/* SL */}
        <div>
          <label className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest mb-1 block">Stop Loss</label>
          <input
            type="text"
            value={sl}
            onChange={(e) => setSl(e.target.value)}
            placeholder="e.g. 98000"
            className="w-full px-3 py-2.5 rounded-xl bg-muted/50 border border-border text-foreground text-sm placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/40 transition-colors"
          />
        </div>
      </div>

      <button
        onClick={handleSend}
        disabled={sending || !symbol.trim() || !selectedEaId}
        className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-bold text-sm transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-40 flex items-center justify-center gap-2"
      >
        <Send size={14} />
        {sending ? "Sending..." : "Send Signal"}
      </button>
    </motion.div>
  );
};

export default SendSignalCard;
