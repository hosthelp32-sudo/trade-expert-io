/** Presentation only: never infer a fill, connection, balance or profit. */
export function formatConsoleMessage(message: string): string {
  const clean = message.replace(/^~/, "");
  const opened = clean.match(/^\[EXECUTING\] (\d+)\/(\d+) TRADE PLACED :: (.+) (BUY|SELL) @ (.+)$/);
  if (opened) return `TRADE OPENED · ${opened[3]} ${opened[4]}\nEntry  ${opened[5]}\nConfirmed  ${opened[1]} of ${opened[2]} trades`;
  const levels = clean.match(/^\[LVL\] ENTRY (.+) \| SL (.+) \| TP (.+)$/);
  if (levels) return `Entry  ${levels[1]}\nSL  ${levels[2]}   |   TP  ${levels[3]}`;
  const signal = clean.match(/^\[SIGNAL\] (BUY|SELL) (.+)$/);
  if (signal) return `SIGNAL RECEIVED · ${signal[2]} ${signal[1]}`;
  const labels: Record<string, string> = {
    LINK: "ACCOUNT", LOT: "ORDER SIZE", LVL: "LEVELS", EXECUTING: "EXECUTION",
    SUCCESSFUL: "CONFIRMED", HOLD: "ON HOLD", MOD: "UPDATE", CLS: "CLOSE",
    OK: "CONFIRMED", DIR: "DIRECTION", SYMBOL: "SYMBOL", TP: "TP", SL: "SL",
    "LOT SIZE": "LOT SIZE", TRADES: "TRADES", ENTRY: "ENTRY", SENDING: "SENDING",
    RISK: "RISK", SYS: "STATUS",
  };
  return clean.replace(/^\[([^\]]+)\]\s*/, (_, label: string) => `${labels[label] || label} · `).replace(/ :: /g, " · ");
}