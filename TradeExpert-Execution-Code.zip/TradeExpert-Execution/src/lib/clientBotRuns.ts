// Helpers to register/unregister a user's "running" subscription so the backend
// (dispatch-signal) can place trades on their MetaTrader account even when the
// app is closed. The phone only records intent here; execution happens server-side.
import { supabase } from "@/integrations/supabase/client";
import { getDeviceFingerprint } from "@/utils/deviceFingerprint";

interface SymbolConfig {
  symbol: string;
  lotSize?: number;
  maxTrades?: number;
}

function readSymbolConfigs(): SymbolConfig[] {
  try {
    const raw = localStorage.getItem("ea_allowed_symbols");
    if (!raw) return [];
    const arr = JSON.parse(raw);
    if (!Array.isArray(arr)) return [];
    return arr
      .filter((c: any) => c && c.symbol)
      .map((c: any) => ({
        symbol: String(c.symbol).toUpperCase(),
        lotSize: Number(c.lotSize) || 0.01,
        maxTrades: Math.max(1, Number(c.maxTrades) || 1),
      }));
  } catch {
    return [];
  }
}

function buildComment(botName: string): string {
  const suffix = "~TradeExpert";
  const clean = String(botName || "")
    .replace(/[^a-zA-Z0-9 _\-]/g, "")
    .replace(/\s+/g, " ")
    .trim();
  if (!clean) return "TradeExpert";
  // MT4 caps comments at 31 chars — use the full name and let the edge
  // function sanitize, but keep the suffix intact so the comment is readable.
  const combined = `${clean}${suffix}`;
  return combined.length <= 31 ? combined : `${clean.slice(0, 31 - suffix.length)}${suffix}`;
}

/**
 * Mark all of the user's activated bots as "running" server-side. Once this is
 * set, dispatch-signal copies any matching mentor/signal-sender trade onto the
 * user's MT account regardless of whether their app is open.
 */
export async function registerRunningBots(botName: string): Promise<void> {
  try {
    const { data: u } = await supabase.auth.getUser();
    const userId = u?.user?.id;

    const stored = localStorage.getItem("ea_bots");
    if (!stored) return;
    const bots = JSON.parse(stored);
    if (!Array.isArray(bots) || bots.length === 0) return;

    const symbolConfigs = readSymbolConfigs();

    // Cutoff: only signals created AT OR AFTER this moment get copied. This
    // guarantees pressing Start never replays a previously-missed signal.
    const startedAt = new Date().toISOString();

    const rows = bots
      .map((b: any) => {
        const eaId = b.ea_id || b.ea?.id;
        const eaCode = b.ea_code || b.ea?.ea_code || "";
        if (!eaId) return null;
        const actualBotName = b.ea_name || b.ea?.name || b.name || botName;
        return {
          ...(userId ? { user_id: userId } : {}),
          ea_id: eaId,
          ea_code: eaCode,
          status: "running",
          symbol_configs: symbolConfigs,
          comment: buildComment(actualBotName),
          started_at: startedAt,
        };
      })
      .filter(Boolean);

    if (rows.length === 0) return;
    if (userId) {
      await supabase.from("client_bot_runs").upsert(rows as any, { onConflict: "user_id,ea_id" });
      return;
    }

    const paidEmail = (localStorage.getItem("ea_paid_email") || "").trim().toLowerCase();
    if (!paidEmail || !paidEmail.includes("@")) return;
    await supabase.functions.invoke("connect-mt-account", {
      body: {
        action: "register_bot_runs",
        paidEmail,
        device_id: await getDeviceFingerprint(),
        bots: rows.map((row: any) => ({ ea_id: row.ea_id, ea_code: row.ea_code, comment: row.comment })),
        symbol_configs: symbolConfigs,
        started_at: startedAt,
      },
    });
  } catch (e) {
    console.warn("registerRunningBots failed", e);
  }
}

/** Mark all of the user's running subscriptions as stopped. */
export async function unregisterRunningBots(): Promise<void> {
  try {
    const { data: u } = await supabase.auth.getUser();
    const userId = u?.user?.id;
    if (!userId) {
      const paidEmail = (localStorage.getItem("ea_paid_email") || "").trim().toLowerCase();
      if (!paidEmail || !paidEmail.includes("@")) return;
      await supabase.functions.invoke("connect-mt-account", {
        body: { action: "unregister_bot_runs", paidEmail, device_id: await getDeviceFingerprint() },
      });
      return;
    }
    await supabase
      .from("client_bot_runs")
      .update({ status: "stopped" })
      .eq("user_id", userId)
      .eq("status", "running");
  } catch (e) {
    console.warn("unregisterRunningBots failed", e);
  }
}
