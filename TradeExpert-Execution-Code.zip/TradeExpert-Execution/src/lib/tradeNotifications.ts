// Local push notifications for bot trade executions.
import { toast } from "sonner";

// Uses the browser Notification API (works in the installed PWA too).

const KEY = "ea_push_notifications";

export const pushEnabled = (): boolean => {
  if (typeof window === "undefined") return false;
  // Default ON — users expect trade alerts unless they explicitly turn them off.
  return localStorage.getItem(KEY) !== "0";
};

export const setPushEnabled = (v: boolean) => {
  localStorage.setItem(KEY, v ? "1" : "0");
};

export const requestPushPermission = async (): Promise<boolean> => {
  if (typeof window === "undefined" || !("Notification" in window)) return false;
  if (Notification.permission === "granted") return true;
  if (Notification.permission === "denied") return false;
  try {
    const res = await Notification.requestPermission();
    return res === "granted";
  } catch {
    return false;
  }
};

const show = async (title: string, body: string) => {
  if (typeof window === "undefined") return;
  if (!pushEnabled()) return;

  // Always surface an in-app pop-up so the alert is never silently dropped
  // (foreground tabs, iOS PWAs, or denied OS permission).
  toast(title, { description: body, duration: 8000 });

  if (!("Notification" in window)) return;
  if (Notification.permission === "default") {
    try {
      await Notification.requestPermission();
    } catch { /* ignore */ }
  }
  if (Notification.permission !== "granted") return;
  const options: NotificationOptions = {
    body,
    icon: "/icons/icon-192.png",
    badge: "/icons/icon-192.png",
    tag: `ea-trade-${Date.now()}`,
  };
  try {
    const reg = await navigator.serviceWorker?.getRegistration?.();
    if (reg) {
      await reg.showNotification(title, options);
      return;
    }
  } catch { /* fall through */ }
  try {
    new Notification(title, options);
  } catch { /* ignore */ }
};

export type TradeNotice = {
  symbol?: string | null;
  direction?: string | null;
  entry?: string | number | null;
  stopLoss?: string | number | null;
  takeProfit?: string | number | null;
  lot?: string | number | null;
  trades?: number | null;
};

const fmt = (v: unknown) => {
  if (v === null || v === undefined || v === "") return "—";
  const n = Number(v);
  return Number.isFinite(n) ? String(n) : String(v);
};

export const notifyTradeTaken = (t: TradeNotice) => {
  const sym = String(t.symbol || "").toUpperCase();
  void show(`Plug ${sym}`, `Trade taken on ${sym} — plug ${sym} on your MT chart.`);
};

export const notifySignal = (t: TradeNotice) => {
  const sym = String(t.symbol || "").toUpperCase();
  void show(`Plug ${sym}`, `Signal on ${sym} — plug ${sym} on your MT chart.`);
};

/** Fired once trades are confirmed placed on the MT account. */
export const notifyTradesPlaced = (count: number, symbol?: string | null, direction?: string | null) => {
  const sym = symbolAsOnSymbolsPage(String(symbol || ""));
  const dir = String(direction || "").toUpperCase();
  void show(
    `${count} trade${count > 1 ? "s" : ""} placed`,
    `${dir ? dir + " " : ""}${sym} — successfully placed on your MetaTrader account.`,
  );
};


export const notifyBotStarted = (botName?: string) => {
  void show(
    botName ? `${botName} started` : "Bot started",
    "Searching the market for the next signal...",
  );
};

export const notifyBotStopped = (botName?: string) => {
  void show(
    botName ? `${botName} stopped` : "Bot stopped",
    "No new trades will be taken until you start again.",
  );
};

/** A monitored trade was closed automatically because the market reversed. */
export const notifyTradeAutoClosed = (symbol?: string | null, direction?: string | null) => {
  const sym = symbolAsOnSymbolsPage(String(symbol || ""));
  const dir = String(direction || "").toUpperCase();
  void show(
    `${sym} closed — market reversed`,
    `Your ${dir ? dir + " " : ""}${sym} position was closed automatically. Bot stopped — press Start to run again.`,
  );
};


/**
 * Resolve a symbol to the exact label the user saved on the Symbols page
 * (e.g. "US30.std" instead of "US30"), so notifications match what they see.
 */
export const symbolAsOnSymbolsPage = (symbol: string): string => {
  const raw = String(symbol || "").trim();
  if (!raw) return "";
  try {
    const saved: string[] = JSON.parse(localStorage.getItem("ea_allowed_symbols") || "[]");
    const norm = (s: string) => String(s).toUpperCase().replace(/[^A-Z0-9]/g, "");
    const hit = saved.find((s) => norm(s) === norm(raw));
    if (hit) return hit;
  } catch {
    /* ignore */
  }
  return raw.toUpperCase();
};

/** Cloud hosting is OFF on this device: tell the user which symbol to plug. */
export const notifyPlugSymbol = (symbol: string, eta?: Date) => {
  const sym = symbolAsOnSymbolsPage(symbol);
  const time = eta
    ? eta.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false })
    : "";
  void show(
    `Plug ${sym} now`,
    `A signal on ${sym} is expected in about 5 minutes${time ? ` (~${time})` : ""}. Plug ${sym} on your MT chart.`,
  );
};


/** Cloud hosting cannot start because the user picked no symbols. */
export const notifyNoSymbols = () => {
  void show(
    "Add a symbol first",
    "Cloud hosting can't run without symbols. Open Symbols and add at least one pair.",
  );
};
