import { createContext, useContext, useState, useEffect, useCallback, useRef, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getMTCredentials, getConnectedAccounts } from "@/utils/mtCredentials";
import { speak as speakCrossPlatform } from "@/utils/speak";
import { notifyTradesPlaced } from "@/lib/tradeNotifications";
import { toast } from "sonner";


interface LogEntry {
  time: string;
  msg: string;
  type: "info" | "success" | "warn";
  color?: string;
}

interface ActiveSignalInfo {
  symbol: string;
  direction: string;
  tp: string;
  sl: string;
}

interface BotConsoleContextType {
  botRunning: boolean;
  setBotRunning: (v: boolean) => void;
  showStartPopup: boolean;
  setShowStartPopup: (v: boolean) => void;
  showConsole: boolean;
  setShowConsole: (v: boolean) => void;
  consoleLogs: LogEntry[];
  setConsoleLogs: React.Dispatch<React.SetStateAction<LogEntry[]>>;
  addLog: (msg: string, type?: "info" | "success" | "warn", color?: string) => void;
  pendingSignal: any;
  setPendingSignal: (v: any) => void;
  botImageUrl: string;
  setBotImageUrl: (v: string) => void;
  botName: string;
  setBotName: (v: string) => void;
  tradeLotSize: number;
  setTradeLotSize: (v: number) => void;
  tradeCount: number;
  setTradeCount: (v: number) => void;
  activeSignal: ActiveSignalInfo | null;
}

const BotConsoleContext = createContext<BotConsoleContextType | null>(null);

export const useBotConsole = () => {
  const ctx = useContext(BotConsoleContext);
  if (!ctx) throw new Error("useBotConsole must be used within BotConsoleProvider");
  return ctx;
};

// ── Symbol mapping: normalize broker-specific suffixes ──
function normalizeSymbol(symbol: string): string {
  // Strip common broker suffixes like .m, m, .pro, .raw, micro, etc.
  return symbol.replace(/\.(m|pro|raw|ecn|std|micro|mini)$/i, "")
               .replace(/(m|micro|mini)$/i, (match, p1) => {
                 // Only strip if the base is a known pair pattern
                 const base = symbol.slice(0, -match.length);
                 if (base.length >= 6) return "";
                 return match;
               })
               .toUpperCase();
}

function symbolMatches(masterSymbol: string, clientSymbol: string): boolean {
  return normalizeSymbol(masterSymbol) === normalizeSymbol(clientSymbol);
}

/** Human-readable bot name: keeps real spacing ("COTEX SCALPER EA"). */
export function prettyBotName(botName: string): string {
  return String(botName || "")
    .replace(/[_-]+/g, " ")
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .replace(/\s+/g, " ")
    .trim();
}

function buildTradeComment(botName: string): string {
  const suffix = "~TradeExpert";
  const cleanName = prettyBotName(botName)
    .replace(/[^a-zA-Z0-9 _\-]/g, "")
    .replace(/\s+/g, " ")
    .trim();

  if (!cleanName) return "TradeExpert";

  // MT comments are capped at 31 chars; preserve the complete brand suffix.
  const combined = `${cleanName}${suffix}`;
  return combined.length <= 31
    ? combined
    : `${cleanName.slice(0, 31 - suffix.length)}${suffix}`;
}


function buildSpokenBotName(botName: string): string {
  return botName
    .replace(/EA\b/gi, " E A")
    .replace(/MT5\b/gi, " M T 5")
    .replace(/MT4\b/gi, " M T 4")
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

// ── Trade tracking: maps master_ticket → client ticket ──
function getTradeMap(): Record<string, string> {
  try {
    return JSON.parse(localStorage.getItem("ea_trade_map") || "{}");
  } catch { return {}; }
}

function setTradeMap(map: Record<string, string>) {
  localStorage.setItem("ea_trade_map", JSON.stringify(map));
}

export const BotConsoleProvider = ({ children }: { children: ReactNode }) => {
  // Restore the running state across app switches / reloads — only the user
  // pressing Stop should ever turn the bot off.
  const [botRunning, setBotRunning] = useState(() => {
    try { return localStorage.getItem("ea_bot_running") === "1"; } catch { return false; }
  });
  const [showStartPopup, setShowStartPopup] = useState(() => {
    try { return localStorage.getItem("ea_bot_running") === "1"; } catch { return false; }
  });
  const [showConsole, setShowConsole] = useState(false);

  const [consoleLogs, setConsoleLogs] = useState<LogEntry[]>([]);
  const [pendingSignal, setPendingSignal] = useState<any>(null);
  const [botImageUrl, setBotImageUrl] = useState("");
  const [botName, setBotName] = useState("Bot");
  const [tradeLotSize, setTradeLotSize] = useState(() => Number(localStorage.getItem("ea_lot_size")) || 0.01);
  const [tradeCount, setTradeCount] = useState(() => Number(localStorage.getItem("ea_trade_count")) || 1);
  const [activeSignal, setActiveSignal] = useState<ActiveSignalInfo | null>(null);
  const botRunningRef = useRef(botRunning);
  const prevBotRunningRef = useRef(botRunning);

  const executeSignalRef = useRef<((s: any) => void) | null>(null);
  const processedSignalKeysRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    botRunningRef.current = botRunning;
    // Persist a simple "started" flag so the global SignalAutoExecutor only
    // places trades while the bot is explicitly running (never when idle).
    try { localStorage.setItem("ea_bot_running", botRunning ? "1" : "0"); } catch { /* ignore */ }
  }, [botRunning]);

  // Track when the bot was started — used to ignore any pre-existing signals.
  // Persisted so returning to the app keeps the original start time.
  const botStartedAtRef = useRef<number>(Number(localStorage.getItem("ea_bot_started_at")) || 0);

  // Clear console + pending signals when bot is switched off.
  // On switch-on we do NOT replay old hosted positions or queued signals —
  // the user must trigger a fresh action (chart analysis, manual signal, or self-host)
  // before any trade is sent.
  useEffect(() => {
    if (prevBotRunningRef.current && !botRunning) {
      setConsoleLogs([]);
      setPendingSignal(null);
      botStartedAtRef.current = 0;
      try { localStorage.removeItem("ea_bot_started_at"); } catch { /* ignore */ }
      // Drop any queued AI/analysis signal so it can't fire on next start
      try { localStorage.removeItem("ea_signal_auto_start"); } catch { /* ignore */ }
      // Reset dedupe so future fresh signals are not blocked
      processedSignalKeysRef.current.clear();
    }
    if (botRunning && !botStartedAtRef.current) {
      botStartedAtRef.current = Date.now();
      try { localStorage.setItem("ea_bot_started_at", String(botStartedAtRef.current)); } catch { /* ignore */ }
      // NOTE: do NOT clear ea_signal_auto_start here — a chart-analysis signal
      // queued just before pressing Start must still fire once the bot is on.
    }

    prevBotRunningRef.current = botRunning;
  }, [botRunning]);



  const addLog = useCallback((msg: string, type: "info" | "success" | "warn" = "info", color?: string) => {
    const now = new Date();
    const time = now.toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" });
    setConsoleLogs((prev) => [...prev, { time, msg, type, color }]);
  }, []);

  const speak = useCallback((text: string) => {
    void speakCrossPlatform(text);
  }, []);


  // ── Place a NEW trade on MetaTrader ──
  const placeOpenTrade = useCallback(async (signal: any) => {
    try {
      // Force refresh — a freshly-connected account may not be in the cache yet
      let creds = await getMTCredentials();
      if (!creds?.uuid) creds = await getMTCredentials(true);
      if (!creds?.uuid) {
        // Last resort: any connected account on this device/profile.
        try {
          const accounts = await getConnectedAccounts();
          const active = accounts.find((a) => a.isConnected) || accounts[0];
          if (active?.uuid) creds = { uuid: active.uuid, apiKey: "connected" } as any;
        } catch { /* ignore */ }
      }
      if (!creds?.uuid) {
        addLog("[LINK] NO TRADING ACCOUNT LINKED :: CONNECT METATRADER", "warn", "#fbbf24");
        return;
      }
      const { uuid, apiKey } = creds;


      // Check allowed symbols (stored as SymbolConfig[])
      const allowedSymbols: { symbol: string; lotSize: number; platform: string; maxTrades: number }[] = 
        JSON.parse(localStorage.getItem("ea_allowed_symbols") || "[]");
      const sym = signal.symbol || "";
      
      const matchedConfig = allowedSymbols.find(s => symbolMatches(sym, s.symbol));
      // Manual/AI-Analysis signals bypass the symbol allowlist (the user explicitly chose the symbol)
      const isManual = !!signal.manual;
      if (!isManual && allowedSymbols.length > 0 && !matchedConfig) {
        // Silently ignore — do not show any error or speak
        return;
      }

      const dir = signal.direction || "BUY";
      const tp = signal.take_profit || signal.tp || "0";
      const sl = signal.stop_loss || signal.sl || "0";
      const comment = buildTradeComment(botName);
      const masterTicket = signal.master_ticket || "";
      // Trade count: the user's per-pair setting (e.g. 9 on this pair) is the
      // source of truth when configured. Cloud-hosted signals arrive with
      // num_trades=1 — never let that silently clamp the configured 9 down to 1.
      const localMaxTrades = Number(matchedConfig?.maxTrades) || 0;
      const signalTrades = Number(signal.num_trades ?? signal.numTrades) || 0;
      const requestedTrades = localMaxTrades > 0
        ? Math.max(localMaxTrades, signalTrades)               // per-pair config wins, never below signal
        : Math.max(signalTrades, Number(tradeCount) || 1);     // no per-pair config → signal/global default
      const numTrades = Math.max(1, Number.isFinite(requestedTrades) ? requestedTrades : 1);
      const lotSize = Number(signal.lot_size ?? signal.lotSize ?? matchedConfig?.lotSize ?? tradeLotSize) || 0.01;

      const maxRetries = 10;
      const openedPositions: Array<{ symbol: string; direction: string; entry: string; stopLoss: string; takeProfit: string; lots: string; ticket?: string }> = [];

      // Detect "MetaTrader terminal offline / not connected" — keep retrying silently, no scary logs
      const isOfflineErr = (msg: string | undefined) => {
        const m = String(msg || "").toLowerCase();
        return (
          m.includes("not connected") ||
          m.includes("not_connected") ||
          m.includes("not_conntected") ||
          m.includes("conntected") ||
          m.includes("metatrader terminal is offline") ||
          m.includes("trading node is warming up") ||
          m.includes("timeout_no_response_from_node") ||
          m.includes("node_not_available") ||
          m.includes("failed to send a request") ||
          m.includes("failed to fetch") ||
          m.includes("networkerror") ||
          m.includes("network error") ||
          m.includes("load failed")
        );
      };
      // Server already accepted this trade on a previous attempt — treat as success
      const isAlreadyProcessed = (msg: string | undefined) => {
        const m = String(msg || "").toLowerCase();
        return m.includes("request_already_processed") || m.includes("already processed") || m.includes("duplicate");
      };

      // ── Signal announcement: symbol + direction, lot size, levels ──
      const dirUpperHdr = String(dir).toUpperCase();
      const dirColorHdr = dirUpperHdr.includes("BUY") ? "#22c55e" : "#ef4444";
      const entryHint = signal.entry_price || signal.entry || "MARKET";
      addLog(`[SIGNAL] ${dirUpperHdr} ${sym}`, "success", dirColorHdr);
      addLog(`[LOT] ${lotSize} LOT :: ${numTrades} TRADE${numTrades > 1 ? "S" : ""}`, "info", "#fbbf24");
      addLog(`[LVL] ENTRY ${entryHint} | SL ${sl} | TP ${tp}`, "info", "#fde047");

      // Fire each trade in parallel, paced 2s apart so MetaTrader receives one every 2s
      const tradePromises: Promise<void>[] = [];
      for (let i = 0; i < numTrades; i++) {
        const idx = i;
        const p = (async () => {
          let success = false;
          let attempt = 0;
          let offlineNotified = false;
          let marketClosedHit = false;
          while (!success && attempt <= maxRetries) {
            if (attempt > 0) {
              await new Promise(r => setTimeout(r, Math.min(1500 + attempt * 800, 6000)));
            }
            const { data, error } = await supabase.functions.invoke("copy-trade", {
              body: {
                uuid, apiKey, action: "open",
                symbol: sym, direction: dir,
                takeProfit: tp, stopLoss: sl,
                volume: lotSize, comment,
                openPrice: signal.entry_price || signal.entry || undefined,
                master_ticket: signal.master_ticket || "",
                request_key: `${signal.id || signal.master_ticket || sym}-${idx + 1}`,
              },
            });
            if (error) {
              if (isAlreadyProcessed(error.message)) {
                success = true;
                break;
              }
              attempt++;
              continue;
            }
            if (data?.success) {
              const entryPrice = data.result?.price || data.result?.openPrice || signal.entry_price || signal.entry || "market";
              const dirUpper = String(dir).toUpperCase();
              const dirColor = dirUpper.includes("BUY") ? "#22c55e" : "#ef4444";
              addLog(`[EXECUTING] ${idx + 1}/${numTrades} TRADE PLACED :: ${sym} ${dirUpper} @ ${entryPrice}`, "success", dirColor);
              const clientTicket = data.result?.ticket ? String(data.result.ticket) : undefined;
              if (masterTicket && clientTicket) {
                const map = getTradeMap();
                map[masterTicket] = clientTicket;
                setTradeMap(map);
              }
              openedPositions.push({
                symbol: sym,
                direction: dir,
                entry: String(entryPrice),
                stopLoss: String(sl ?? ""),
                takeProfit: String(tp ?? ""),
                lots: String(lotSize),
                ticket: clientTicket,
              });
              success = true;
            } else {
              if (isAlreadyProcessed(data?.error)) {
                success = true;
                break;
              }
              const errMsg = String(data?.error || "").toLowerCase();
              if (errMsg.includes("market is closed") || errMsg.includes("market closed")) {
                marketClosedHit = true;
                addLog(`[HOLD] TRADE ${idx + 1} ON HOLD :: ${sym} MARKET CLOSED`, "warn", "#fbbf24");
                break; // no point retrying a closed market
              } else if (isOfflineErr(data?.error)) {
                offlineNotified = true;
              }
              attempt++;
            }
          }
        })();

        tradePromises.push(p);

        // Pace dispatches: 2s spacing between consecutive trade requests
        if (i < numTrades - 1) {
          await new Promise(r => setTimeout(r, 2000));
        }
      }
      // Wait for all trades to settle (for email + speech summary)
      await Promise.all(tradePromises);

      if (openedPositions.length > 0) {
        if (openedPositions.length >= numTrades) {
          addLog(
            `[SUCCESSFUL] ALL ${numTrades} TRADE${numTrades > 1 ? "S" : ""} SUCCESSFULLY PLACED :: ${String(dir).toUpperCase()} ${sym}`,
            "success",
            "#22c55e",
          );
        } else {
          addLog(
            `[SUCCESSFUL] ${openedPositions.length}/${numTrades} TRADES PLACED :: ${String(dir).toUpperCase()} ${sym} @ ${lotSize} LOT`,
            "success",
            "#22c55e",
          );
        }
        speak(`${openedPositions.length} trade${openedPositions.length > 1 ? "s" : ""} placed on ${sym}`);
        notifyTradesPlaced(openedPositions.length, sym, String(dir).toUpperCase());
      }



      // ── Email the trader (license owner) when at least one trade opened ──
      if (openedPositions.length > 0) {
        try {
          const stored = localStorage.getItem("ea_bots");
          const activeIdx = parseInt(localStorage.getItem("ea_active_bot") || "0", 10);
          const arr = stored ? JSON.parse(stored) : [];
          const active = arr?.[activeIdx];
          const recipientEmail = String(active?.license?.email || "").trim();
          const clientName = String(active?.owner?.display_name || "").trim() || undefined;
          const eaName = String(active?.ea?.name || botName || "TradeExpert EA");

          if (recipientEmail && recipientEmail.includes("@")) {
            const primary = openedPositions[0];
            const idemBase = primary.ticket || `${sym}-${Date.now()}`;
            // Fire-and-forget — never block the trade flow on email delivery
            supabase.functions.invoke("send-transactional-email", {
              body: {
                templateName: "trade-execution",
                recipientEmail,
                idempotencyKey: `trade-exec-${idemBase}`,
                templateData: {
                  clientName,
                  symbol: primary.symbol,
                  direction: primary.direction,
                  entry: primary.entry,
                  stopLoss: primary.stopLoss,
                  takeProfit: primary.takeProfit,
                  lots: primary.lots,
                  positionsCount: openedPositions.length,
                  positions: openedPositions,
                  eaName,
                  executedAt: new Date().toLocaleString(),
                },
              },
            }).catch((err) => console.warn("trade-execution email failed:", err));
          }
        } catch (mailErr) {
          console.warn("trade-execution email setup failed:", mailErr);
        }
      }

      speak(`You are trading with ${buildSpokenBotName(botName)}. ${numTrades} trade${numTrades > 1 ? "s" : ""} opened. ${dir} ${sym}`);
    } catch {
      /* silent — nothing confirmed, so nothing is written to the console */
    }

  }, [addLog, botName, speak, tradeLotSize, tradeCount]);

  // ── MODIFY trade SL/TP ──
  const placeModifyTrade = useCallback(async (signal: any) => {
    try {
      const creds = await getMTCredentials();
      if (!creds) return;
      const { uuid, apiKey } = creds;
      if (!uuid || !apiKey) return;

      const masterTicket = signal.master_ticket || "";
      const map = getTradeMap();
      const clientTicket = map[masterTicket];

      if (!clientTicket) {
        return;
      }

      const tp = signal.take_profit || signal.tp || "0";
      const sl = signal.stop_loss || signal.sl || "0";

      addLog(`[MOD] UPDATING LEVELS :: TP ${tp} | SL ${sl}`, "info");

      const { data, error } = await supabase.functions.invoke("copy-trade", {
        body: {
          uuid, apiKey, action: "modify",
          ticket: clientTicket,
          takeProfit: tp, stopLoss: sl,
        },
      });

      if (error) return;

      if (data?.success) {
        addLog(`[OK] LEVELS UPDATED`, "success");
      }
    } catch {
      /* silent */
    }

  }, [addLog]);

  // ── CLOSE trade ──
  const placeCloseTrade = useCallback(async (signal: any) => {
    try {
      const creds = await getMTCredentials();
      if (!creds) return;
      const { uuid, apiKey } = creds;
      if (!uuid || !apiKey) return;

      const masterTicket = signal.master_ticket || "";
      const map = getTradeMap();
      const clientTicket = map[masterTicket];

      if (!clientTicket) {
        return;
      }

      addLog(`[CLS] CLOSING POSITION...`, "info");

      const { data, error } = await supabase.functions.invoke("copy-trade", {
        body: {
          uuid, apiKey, action: "close",
          ticket: clientTicket,
        },
      });

      if (error) return;

      if (data?.success) {
        addLog(`[OK] POSITION CLOSED`, "success");
        // Remove from trade map
        delete map[masterTicket];
        setTradeMap(map);
      }

      speak(`Trade closed. ${signal.symbol || ""}`);
    } catch {
      /* silent */
    }

  }, [addLog, speak]);

  // Lock: only one open signal active at a time. Cleared on close.
  const activeSignalRef = useRef<ActiveSignalInfo | null>(null);
  useEffect(() => { activeSignalRef.current = activeSignal; }, [activeSignal]);

  // ── Execute any signal by action type ──
  const executeSignal = useCallback((signal: any) => {
    const action = (signal.action || "open").toLowerCase();
    // Cloud / manual signals always carry a unique id. Anything without an id
    // gets a time-based key so a repeat of the same symbol+direction is never
    // silently dropped by de-duplication.
    const signalKey = signal.id
      ? `${action}:${signal.id}`
      : signal.master_ticket
        ? `${action}:${signal.master_ticket}`
        : `${action}:${signal.symbol}-${signal.direction}-${signal.created_at || Date.now()}`;
    if (processedSignalKeysRef.current.has(signalKey)) return;
    processedSignalKeysRef.current.add(signalKey);

    // One-signal-at-a-time lock applies to mentor/self-host feeds only.
    // Cloud-hosted + manual signals are user-triggered and must always execute.
    if ((action === "open" || action === "") && activeSignalRef.current && !signal.manual) {
      addLog(`[HOLD] NEW SETUP PARKED :: POSITION STILL OPEN`, "warn", "#fbbf24");
      return;
    }

    // Cloud hosting: the console opens fresh so the very first line the user
    // sees is "SIGNAL RECEIVED".
    if (signal.fresh_console) setConsoleLogs([]);


    if (!signal.silent) {
      setShowStartPopup(true);
      setShowConsole(true);
    }

    const dir = signal.direction || signal.signal || "";
    const sym = signal.symbol || "";
    const tp = signal.take_profit || signal.tp || "";
    const sl = signal.stop_loss || signal.sl || "";

    const lot = signal.lot_size || signal.lotSize || "";
    const style = String(signal.trade_type || signal.tradeType || "").toUpperCase();
    const styleLabel = style === "SWING" ? "SWING TRADE" : style === "SCALP" ? "SCALP TRADE" : "";
    const detail = (label: string) => {
      const parts = [`${label} ${dir} ${sym}`.trim()];
      if (styleLabel) parts.push(styleLabel);
      if (tp) parts.push(`TP ${tp}`);
      if (sl) parts.push(`SL ${sl}`);
      if (lot) parts.push(`Lot ${lot}`);
      return parts.join("  ·  ");
    };

    const nameLabel = prettyBotName(signal.ea_name || botName).toUpperCase();
    const banner = nameLabel ? `━━━ SIGNAL RECEIVED · ${nameLabel} ━━━` : "━━━ SIGNAL RECEIVED ━━━";

    if (action === "open") {
      setActiveSignal({ symbol: sym, direction: dir, tp: tp || "N/A", sl: sl || "N/A" });
      speak(`New signal received. ${dir} ${sym}`);
      addLog(banner, "success");
      addLog(detail("OPEN"), "success");
      placeOpenTrade(signal);
    } else if (action === "modify") {
      addLog(banner, "info");
      addLog(detail("MODIFY"), "info");
      speak(`Trade modified. ${sym}`);
      placeModifyTrade(signal);
    } else if (action === "close") {
      setActiveSignal(null);
      addLog(banner, "warn");
      addLog(detail("CLOSE"), "warn");
      speak(`Trade closed. ${sym}`);
      placeCloseTrade(signal);
    } else {
      setActiveSignal({ symbol: sym, direction: dir, tp: tp || "N/A", sl: sl || "N/A" });
      speak(`New signal received. ${dir} ${sym}`);
      addLog(banner, "success");
      addLog(detail(""), "success");
      placeOpenTrade(signal);
    }
  }, [addLog, placeOpenTrade, placeModifyTrade, placeCloseTrade, speak, tradeLotSize, botName]);

  // Expose executeSignal via ref for the start-replay loop above
  useEffect(() => { executeSignalRef.current = executeSignal; }, [executeSignal]);

  // Listen for signal from AI analysis (localStorage).
  // Only fire if the bot is already running AND the signal was created after the
  // current start. We never queue signals to fire on a future start.
  useEffect(() => {
    const check = () => {
      const signalData = localStorage.getItem("ea_signal_auto_start");
      if (!signalData) return;
      // Don't consume until bot is running — let it sit until user starts.
      if (!botRunningRef.current) return;
      localStorage.removeItem("ea_signal_auto_start");
      try {
        const signal = JSON.parse(signalData);
        signal.manual = true;
        executeSignal(signal);
      } catch { /* ignore */ }
    };
    check();
    const interval = setInterval(check, 1000);
    return () => clearInterval(interval);
  }, [executeSignal]);


  // Does this incoming signal belong to one of the user's activated bots?
  const signalMatchesUserBot = useCallback((signal: any) => {
    try {
      const activatedBots = JSON.parse(localStorage.getItem("ea_bots") || "[]");
      return activatedBots.some((bot: any) => {
        const botEaId = bot.ea_id || bot.ea?.id;
        return botEaId && botEaId === signal.ea_id;
      });
    } catch {
      return false;
    }
  }, []);

  // Route a signal that arrived from a mentor's PC (self-host) or the signal
  // sender. Actual order placement is handled SERVER-SIDE by dispatch-signal
  // (so trades fire even when the app is closed). While the app is open we also
  // call dispatch-signal as a safe fallback; server idempotency prevents doubles.
  const routeIncomingSignal = useCallback((signal: any) => {
    if (!botRunningRef.current) return;
    if (!signalMatchesUserBot(signal)) return;

    const action = (signal.action || "open").toLowerCase();
    const signalKey = `${action}:${signal.id || signal.master_ticket || `${signal.symbol}-${signal.direction}-${signal.created_at || ""}`}`;
    if (processedSignalKeysRef.current.has(signalKey)) return;
    processedSignalKeysRef.current.add(signalKey);

    const dir = signal.direction || "";
    const sym = signal.symbol || "";
    const tp = signal.take_profit || "";
    const sl = signal.stop_loss || "";
    const entry = signal.entry_price || signal.entry || "";

    // Resolve the CLIENT's own per-symbol selection (lot size + number of trades)
    // so the console reflects exactly what will be placed on their account.
    let clientLot = signal.lot_size || "";
    let clientTrades = Number(signal.num_trades) || 0;
    try {
      const raw = localStorage.getItem("ea_allowed_symbols");
      if (raw) {
        const arr: Array<{ symbol: string; lotSize: number; maxTrades: number }> = JSON.parse(raw) || [];
        const match = arr.find((c) => symbolMatches(sym, c.symbol));
        if (match) {
          clientLot = String(match.lotSize ?? clientLot);
          clientTrades = Math.max(clientTrades, Number(match.maxTrades) || 1);
        }
      }
    } catch { /* ignore */ }

    if (action === "modify") {
      addLog("━━━ SIGNAL RECEIVED ━━━", "info");
      addLog(`[MOD] ${dir} ${sym}`.trim(), "info");
      return;
    }
    if (action === "close") {
      setActiveSignal(null);
      addLog("━━━ SIGNAL RECEIVED ━━━", "warn");
      addLog(`[CLS] ${dir} ${sym}`.trim(), "warn");
      return;
    }

    // open (display only — actual execution is server-side via dispatch-signal,
    // which applies each client's own symbol/lot/trade selection).
    setShowStartPopup(true);
    setShowConsole(true);
    setActiveSignal({ symbol: sym, direction: dir, tp: tp || "N/A", sl: sl || "N/A" });
    speak(`New signal received. ${dir} ${sym}`);
    const dirUpper = String(dir).toUpperCase();
    const dirColor = dirUpper.includes("BUY") ? "#22c55e" : "#ef4444";
    addLog("━━━ SIGNAL RECEIVED ━━━", "success");
    addLog(`[DIR] ${dirUpper}`.trim(), "info", dirColor);
    addLog(`[SYMBOL] ${sym}`, "info", "#e2e8f0");
    addLog(`[TP] ${tp || "--"}`, "info", "#22c55e");
    addLog(`[SL] ${sl || "--"}`, "info", "#ef4444");
    addLog(`[LOT SIZE] ${clientLot || "0.01"}`, "info", "#60a5fa");
    addLog(`[TRADES] ${clientTrades || 1}`, "info", "#60a5fa");
    addLog(`[ENTRY] ${entry || "MARKET"}`, "info", "#94a3b8");
    addLog(`[SENDING] ${clientTrades || 1} TRADE${(clientTrades || 1) > 1 ? "S" : ""} TO TERMINAL`, "info", "#fbbf24");
    if (signal.id) {
      supabase.functions.invoke("dispatch-signal", {
        body: { signal_id: signal.id },
      }).then(({ data, error }) => {
        if (error) return;
        const placed = Number(data?.placed) || 0;
        const requested = Number(data?.requested) || clientTrades || 1;
        const usedSymbol = data?.results?.find((r: any) => r?.symbol)?.symbol || sym;
        const usedLot = data?.results?.find((r: any) => r?.lot)?.lot ?? clientLot ?? "0.01";
        if (placed > 0) {
          addLog(
            `[SUCCESSFUL] ${placed}/${requested} TRADE${placed > 1 ? "S" : ""} PLACED :: ${dirUpper} ${usedSymbol} @ ${usedLot} LOT`,
            "success",
            "#22c55e",
          );
          speak(`${placed} trade${placed > 1 ? "s" : ""} placed on ${usedSymbol}`);
          toast.success(`${placed} trade${placed > 1 ? "s" : ""} placed`, {
            description: `${dirUpper} ${usedSymbol} · Lot ${usedLot}`,
          });
          notifyTradesPlaced(placed, usedSymbol, dirUpper);
        }
      }).catch(() => { /* silent */ });

    }


  }, [signalMatchesUserBot, addLog, speak]);

  // Listen for realtime signals from mentors.
  // Only execute signals that arrive AFTER the bot was started in this session.
  useEffect(() => {
    const channel = supabase
      .channel("signals-realtime")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "signals" },
        (payload) => routeIncomingSignal(payload.new as any),
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [routeIncomingSignal]);

  // Reliability fallback: while the bot is running and the app is active, poll the
  // signals table for any trades from the mentor's PC / signal sender that the
  // realtime channel may have missed (network blip, reconnect, etc.) and place
  // them. Dedupe ensures no double-execution alongside the realtime listener.
  useEffect(() => {
    let cancelled = false;
    let polling = false;
    const poll = async () => {
      if (cancelled || polling || !botRunningRef.current) return;
      polling = true;
      let botIds: string[] = [];
      try {
        const activatedBots = JSON.parse(localStorage.getItem("ea_bots") || "[]");
        botIds = activatedBots
          .map((b: any) => b.ea_id || b.ea?.id)
          .filter(Boolean);
      } catch { /* ignore */ }
      if (botIds.length === 0) {
        polling = false;
        return;
      }
      const sinceMs = botStartedAtRef.current || Date.now();
      const since = new Date(sinceMs - 2000).toISOString();
      try {
        const { data } = await supabase
          .from("signals")
          .select("id, ea_id, symbol, direction, take_profit, stop_loss, action, entry_price, lot_size, master_ticket, num_trades, created_at")
          .in("ea_id", botIds)
          .gte("created_at", since)
          .order("created_at", { ascending: true })
          .limit(50);
        if (cancelled || !data) return;
        for (const sig of data) routeIncomingSignal(sig);
      } catch { /* ignore */ }
      finally { polling = false; }
    };
    const interval = setInterval(poll, 15_000);
    return () => { cancelled = true; clearInterval(interval); };
  }, [routeIncomingSignal]);


  // Boot sequence
  const runBootSequence = useCallback((onComplete?: () => void) => {
    const timers: ReturnType<typeof setTimeout>[] = [];
    
    // Fetch credentials async (force refresh so newly-connected accounts show up immediately)
    getMTCredentials(true).then((credentials) => {
      const connected = Boolean(credentials?.uuid);
      const bootLogs: { msg: string; type: "info" | "success" | "warn"; delay: number }[] = [
        { msg: `${prettyBotName(botName)} · CONSOLE READY`, type: "info", delay: 0 },
        { msg: connected ? "TRADING ACCOUNT LINKED" : "NO ACCOUNT LINKED · CONNECT METATRADER", type: connected ? "info" : "warn", delay: 200 },
        { msg: connected ? "AWAITING A NEW TRADING SIGNAL" : "TRADE EXECUTION REQUIRES A LINKED ACCOUNT", type: "info", delay: 400 },
        { msg: "ONLY CONFIRMED TRADES APPEAR AS OPENED", type: "info", delay: 600 },
      ];


      bootLogs.forEach(({ msg, type, delay }) => {
        timers.push(setTimeout(() => addLog(msg, type), delay));
      });

      if (onComplete) {
        timers.push(setTimeout(onComplete, 1200));
      }
    });

    return () => timers.forEach(clearTimeout);
  }, [addLog, botName]);

  // A cloud/scanner trade that closed on a market reversal stops the bot: the
  // user must plug the bot in again before anything new is opened.
  useEffect(() => {
    const onForceStop = (e: Event) => {
      const detail = (e as CustomEvent)?.detail || {};
      const sym = String(detail.symbol || "").toUpperCase();
      addLog(`[RISK] MARKET REVERSED${sym ? ` :: ${sym}` : ""} :: POSITION CLOSED`, "warn");
      addLog("[SYS] ENGINE STOPPED :: PLUG BOT AGAIN TO RESUME", "warn");
      setBotRunning(false);
    };
    window.addEventListener("ea-bot-force-stop", onForceStop as EventListener);
    return () => window.removeEventListener("ea-bot-force-stop", onForceStop as EventListener);
  }, [addLog]);

  // Bot running logic

  useEffect(() => {
    if (botRunning) {
      speak(`Bot started. You are trading with ${buildSpokenBotName(botName)}.`);
      // Never auto-fire a trade on start — user must trigger via chart analysis,
      // manual signal, or self-host after the bot is running.
      setPendingSignal(null);
      // Register this bot as "running" server-side so the backend executes
      // incoming trades on the user's MT account even when the app is closed.
      import("@/lib/clientBotRuns").then(({ registerRunningBots }) => {
        registerRunningBots(botName);
      });
      const cleanupBoot = runBootSequence();
      return cleanupBoot;
    } else {
      setActiveSignal(null);
      // Stop server-side execution for this user.
      import("@/lib/clientBotRuns").then(({ unregisterRunningBots }) => {
        unregisterRunningBots();
      });
      if (consoleLogs.length > 0) {
        addLog("[SYS] ENGINE STOPPED :: STANDBY", "warn");
        speak("Bot stopped, time to rest");
      }
    }
  }, [botRunning]);

  return (
    <BotConsoleContext.Provider value={{
      botRunning, setBotRunning,
      showStartPopup, setShowStartPopup,
      showConsole, setShowConsole,
      consoleLogs, setConsoleLogs,
      addLog,
      pendingSignal, setPendingSignal,
      botImageUrl, setBotImageUrl,
      botName, setBotName,
      tradeLotSize, setTradeLotSize: (v: number) => { setTradeLotSize(v); localStorage.setItem("ea_lot_size", String(v)); },
      activeSignal,
      tradeCount, setTradeCount: (v: number) => { setTradeCount(v); localStorage.setItem("ea_trade_count", String(v)); },
    }}>
      {children}
    </BotConsoleContext.Provider>
  );
};
