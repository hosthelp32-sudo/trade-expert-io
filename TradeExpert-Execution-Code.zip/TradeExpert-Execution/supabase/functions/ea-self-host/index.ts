import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const {
      ea_code,
      action = "open",
      symbol,
      direction,
      take_profit,
      stop_loss,
      entry_price,
      lot_size,
      num_trades,
      master_ticket,
      close_price,
    } = body;


    if (!ea_code) {
      return new Response(
        JSON.stringify({ success: false, error: "Missing ea_code" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Connectivity self-check from the self-host EA — no side effects.
    if (String(action).toLowerCase() === "ping") {
      return new Response(
        JSON.stringify({ success: true, message: "TradeExpert link OK" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }


    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceKey);

    // Look up EA by code
    const { data: ea, error: eaError } = await supabase
      .from("expert_advisors")
      .select("id, user_id, name, symbol")
      .eq("ea_code", ea_code.toUpperCase())
      .single();

    if (eaError || !ea) {
      return new Response(
        JSON.stringify({ success: false, error: "Invalid EA code" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Symbol alias map for cross-broker normalization
    const SYMBOL_ALIASES: Record<string, string[]> = {
      "XAUUSD": ["GOLD", "XAUUSD", "GOLDUS", "XAUUSD.m", "GOLDm", "GOLD.m", "XAU/USD", "XAUUSD.raw", "XAUUSD.pro", "XAUUSD.ecn"],
      "XAGUSD": ["SILVER", "XAGUSD", "SILVERUS", "XAG/USD"],
      "EURUSD": ["EURUSD", "EUR/USD"],
      "GBPUSD": ["GBPUSD", "GBP/USD"],
      "USDJPY": ["USDJPY", "USD/JPY"],
      "USDCHF": ["USDCHF", "USD/CHF"],
      "AUDUSD": ["AUDUSD", "AUD/USD"],
      "USDCAD": ["USDCAD", "USD/CAD"],
      "NZDUSD": ["NZDUSD", "NZD/USD"],
      "GBPJPY": ["GBPJPY", "GBP/JPY"],
      "EURJPY": ["EURJPY", "EUR/JPY"],
      "BTCUSD": ["BTCUSD", "BTC/USD", "BITCOIN"],
      "ETHUSD": ["ETHUSD", "ETH/USD", "ETHEREUM"],
      "US30": ["US30", "DJ30", "DOW", "DOW30", "US30.m", "DJ30.m"],
      "NAS100": ["NAS100", "USTEC", "NAS100.m", "USTEC.m", "NASDAQ"],
      "US500": ["US500", "SP500", "SPX500", "US500.m"],
      "XBRUSD": ["XBRUSD", "BRENT", "UKOIL", "BRENT.m"],
      "XTIUSD": ["XTIUSD", "WTI", "USOIL", "CRUDEOIL", "WTI.m"],
    };

    const normalizeSymbolToCanonical = (sym: string): string => {
      const upper = sym.trim().toUpperCase()
        .replace(/\.(m|pro|raw|ecn|std|micro|mini)$/i, "")
        .replace(/[\/\-_\s]/g, "");
      for (const [canonical, aliases] of Object.entries(SYMBOL_ALIASES)) {
        if (aliases.some(a => a.toUpperCase().replace(/[\/\-_.\s]/g, "") === upper) || upper === canonical) {
          return canonical;
        }
      }
      // Fallback: strip common suffixes
      return upper.replace(/(m|micro|mini)$/i, (match) => {
        const base = upper.slice(0, -match.length);
        return base.length >= 6 ? "" : match;
      });
    };

    // Validate symbol against EA's allowed symbols
    if (symbol && ea.symbol) {
      const allowedSymbols = ea.symbol.split(/[,\s;|]+/).map((s: string) => s.trim().toUpperCase()).filter((s: string) => s.length > 0);
      const signalCanonical = normalizeSymbolToCanonical(symbol);
      
      const isAllowed = allowedSymbols.some((s: string) => {
        const allowedCanonical = normalizeSymbolToCanonical(s);
        return allowedCanonical === signalCanonical;
      });

      if (!isAllowed) {
        console.log(`Symbol ${symbol} (canonical: ${signalCanonical}) not in EA allowed list: ${ea.symbol} — silently ignored`);
        return new Response(
          JSON.stringify({ success: true, message: `Signal ignored (symbol not configured)` }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    const act = action.toLowerCase();

    // Helper to insert a signal for a given EA
    const insertSignal = async (targetEaId: string, targetUserId: string) => {
      if (act === "open") {
        return supabase.from("signals").insert({
          user_id: targetUserId,
          ea_id: targetEaId,
          symbol: (symbol || "").trim(),
          direction: (direction || "BUY").toUpperCase(),
          take_profit: take_profit || "",
          stop_loss: stop_loss || "",
          action: "open",
          entry_price: entry_price || "",
          lot_size: lot_size || "0.01",
          num_trades: Math.max(1, Number(num_trades) || 1),
          master_ticket: master_ticket || "",
          status: "active",
        });
      } else if (act === "modify") {
        return supabase.from("signals").insert({
          user_id: targetUserId,
          ea_id: targetEaId,
          symbol: (symbol || "").trim(),
          direction: (direction || "MODIFY").toUpperCase(),
          take_profit: take_profit || "",
          stop_loss: stop_loss || "",
          action: "modify",
          entry_price: entry_price || "",
          lot_size: lot_size || "",
          master_ticket: master_ticket || "",
          status: "active",
        });
      } else if (act === "close") {
        return supabase.from("signals").insert({
          user_id: targetUserId,
          ea_id: targetEaId,
          symbol: (symbol || "").trim(),
          direction: (direction || "CLOSE").toUpperCase(),
          take_profit: "",
          stop_loss: "",
          action: "close",
          entry_price: "",
          lot_size: lot_size || "",
          master_ticket: master_ticket || "",
          close_price: close_price || "",
          status: "closed",
        });
      }
      return { error: { message: `Unknown action: ${act}` } };
    };

    if (!["open", "modify", "close"].includes(act)) {
      return new Response(
        JSON.stringify({ success: false, error: `Unknown action: ${action}` }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Insert signal for the original EA
    const { error: signalError } = await insertSignal(ea.id, ea.user_id);
    if (signalError) {
      console.error("Signal insert error:", signalError);
      return new Response(
        JSON.stringify({ success: false, error: "Failed to broadcast signal" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`${act.toUpperCase()}: ${direction || ""} ${symbol || ""} ticket=${master_ticket || ""} via ${ea.name}`);

    // NOTE: signals are NEVER fanned out to other hosted EAs. Each bot only
    // receives signals produced for that bot (cloud-bot-tick handles every
    // hosted EA independently), which prevents cross-bot signal bleeding.


    return new Response(
      JSON.stringify({ success: true, message: `Signal broadcasted: ${act} ${symbol || ""}` }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("ea-self-host error:", err);
    return new Response(
      JSON.stringify({ success: false, error: "Server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
