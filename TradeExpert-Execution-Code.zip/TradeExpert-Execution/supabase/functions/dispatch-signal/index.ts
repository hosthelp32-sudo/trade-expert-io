// Server-side trade dispatcher.
// Runs whenever a signal is inserted (DB trigger via pg_net) and on a 1-min cron
// safety net. For every user who pressed "Trade" (a running row in
// client_bot_runs) and follows the signal's EA, it places the trade on their
// connected MetaTrader account via the copy-trade function — WHETHER OR NOT
// their phone/app is open. Per-user idempotency (signal_dispatch_log) guarantees
// no trade is ever placed twice.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// ── Canonical symbol matching (mirror of copy-trade / ea-self-host) ──
const SYMBOL_ALIASES: Record<string, string[]> = {
  XAUUSD: ["XAUUSD", "GOLD", "GOLDUS", "XAU/USD"],
  XAGUSD: ["XAGUSD", "SILVER", "SILVERUS", "XAG/USD"],
  EURUSD: ["EURUSD", "EUR/USD"],
  GBPUSD: ["GBPUSD", "GBP/USD"],
  USDJPY: ["USDJPY", "USD/JPY"],
  USDCHF: ["USDCHF", "USD/CHF"],
  AUDUSD: ["AUDUSD", "AUD/USD"],
  USDCAD: ["USDCAD", "USD/CAD"],
  NZDUSD: ["NZDUSD", "NZD/USD"],
  GBPJPY: ["GBPJPY", "GBP/JPY"],
  EURJPY: ["EURJPY", "EUR/JPY"],
  BTCUSD: ["BTCUSD", "BITCOIN", "BTC/USD"],
  ETHUSD: ["ETHUSD", "ETHEREUM", "ETH/USD"],
  US30: ["US30", "DJ30", "DOW", "DOW30"],
  NAS100: ["NAS100", "USTEC", "NASDAQ"],
  US500: ["US500", "SP500", "SPX500"],
  XBRUSD: ["XBRUSD", "BRENT", "UKOIL"],
  XTIUSD: ["XTIUSD", "WTI", "USOIL", "CRUDEOIL"],
};

// Broker decorations that get appended/prepended to the real instrument name.
const BROKER_TOKENS = [
  "MICRO", "MINI", "CASH", "SPOT", "PRO", "RAW", "ECN", "STD", "MIC", "M", "C", "S", "I", "Z", "R", "E",
];

function aliasMatch(v: string): string | null {
  for (const [c, aliases] of Object.entries(SYMBOL_ALIASES)) {
    if (c === v) return c;
    if (aliases.some((a) => a.toUpperCase().replace(/[\/\-_.\s]/g, "") === v)) return c;
  }
  return null;
}

function canon(raw: string): string {
  // Strip separators, leading dots and any broker decoration so that
  // ".US30.MIC", "US30CASH", "US30m" and "US30" all resolve to US30, and
  // "GOLDMICRO" / "XAUUSD.S" / "XAUUSDm" all resolve to XAUUSD.
  let u = String(raw || "").trim().toUpperCase().replace(/[\/\-_\s.]/g, "");
  const direct = aliasMatch(u);
  if (direct) return direct;

  let changed = true;
  while (changed && u.length > 2) {
    changed = false;
    for (const t of BROKER_TOKENS) {
      if (u.length - t.length >= 3 && u.endsWith(t)) {
        const stripped = u.slice(0, -t.length);
        const m = aliasMatch(stripped);
        if (m) return m;
        u = stripped;
        changed = true;
        break;
      }
    }
  }
  return aliasMatch(u) || u;
}


interface SymbolConfig { symbol: string; lotSize?: number; maxTrades?: number }

function buildTradeComment(botName: unknown): string {
  const suffix = "~TradeExpert";
  const clean = String(botName || "")
    .replace(/[^a-zA-Z0-9 _\-]/g, "")
    .replace(/\s+/g, " ")
    .trim();
  if (!clean) return "TradeExpert";
  const combined = `${clean}${suffix}`;
  return combined.length <= 31
    ? combined
    : `${clean.slice(0, 31 - suffix.length)}${suffix}`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const sbUrl = Deno.env.get("SUPABASE_URL")!;
  const svc = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const sb = createClient(sbUrl, svc);

  const callCopyTrade = async (payload: Record<string, unknown>) => {
    const r = await fetch(`${sbUrl}/functions/v1/copy-trade`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${svc}`,
        "apikey": svc,
      },
      body: JSON.stringify(payload),
    });
    let data: any = null;
    try { data = await r.json(); } catch { /* ignore */ }
    return data || { success: false, error: `HTTP ${r.status}` };
  };

  interface DispatchResult {
    user_id: string;
    status: string;
    requested: number;
    placed: number;
    symbol?: string;
    lot?: number;
  }

  // Place one signal for one running subscriber.
  const dispatchToSubscriber = async (signal: any, run: any): Promise<DispatchResult> => {
    const userId = run.user_id;
    const skip = (status: string): DispatchResult => ({ user_id: userId, status, requested: 0, placed: 0 });

    // Cutoff guard: never copy a signal that was created BEFORE this subscriber
    // pressed Start. Missed/previous signals must not be replayed.
    const startedAt = run.started_at ? Date.parse(run.started_at) : 0;
    const signalAt = signal.created_at ? Date.parse(signal.created_at) : 0;
    if (startedAt && signalAt && signalAt < startedAt) return skip("skipped_before_start");

    // Idempotency lock: first writer wins; everyone else skips.
    const { error: logErr } = await sb
      .from("signal_dispatch_log")
      .insert({ signal_id: signal.id, user_id: userId, status: "pending" });
    if (logErr) return skip("already_dispatched"); // unique violation or transient

    const finish = async (status: string) => {
      await sb.from("signal_dispatch_log")
        .update({ status })
        .eq("signal_id", signal.id)
        .eq("user_id", userId);
    };
    const allowRetry = async () => {
      // Remove the lock so the cron safety net retries on the next pass.
      await sb.from("signal_dispatch_log")
        .delete()
        .eq("signal_id", signal.id)
        .eq("user_id", userId);
    };

    // Connected MT account for this subscriber. Prefer a copy-trade-enabled
    // account, but fall back to ANY connected account so trades still execute
    // for users who never toggled copy-trade on.
    const { data: creds } = await sb
      .from("mt_credentials")
      .select("mt_uuid, is_connected, connection_status, copy_trade_enabled, created_at")
      .eq("user_id", userId)
      .order("created_at", { ascending: false });
    const usable = (creds || []).filter(
      (c: any) => c.mt_uuid && c.is_connected !== false && c.connection_status !== "invalid",
    );
    const cred = usable.find((c: any) => c.copy_trade_enabled) || usable[0];
    if (!cred?.mt_uuid) {
      await finish("skipped_no_account");
      return skip("skipped_no_account");
    }
    const uuid = cred.mt_uuid;

    const action = String(signal.action || "open").toLowerCase();
    const symbol = String(signal.symbol || "").trim();

    // ── modify / close: route on the stored client ticket ──
    if (action === "modify" || action === "close") {
      const { data: map } = await sb
        .from("client_trade_map")
        .select("client_ticket")
        .eq("user_id", userId)
        .eq("master_ticket", signal.master_ticket || "")
        .maybeSingle();
      if (!map?.client_ticket) { await finish("skipped_no_ticket"); return skip("skipped_no_ticket"); }
      const res = await callCopyTrade({
        uuid,
        owner_user_id: userId,
        action,
        ticket: map.client_ticket,
        takeProfit: signal.take_profit || "0",
        stopLoss: signal.stop_loss || "0",
      });
      if (action === "close" && res?.success) {
        await sb.from("client_trade_map").delete()
          .eq("user_id", userId).eq("master_ticket", signal.master_ticket || "");
      }
      await finish(res?.success ? "done" : "error");
      return { user_id: userId, status: res?.success ? "done" : "error", requested: 1, placed: res?.success ? 1 : 0 };
    }

    // ── open: apply this subscriber's per-symbol config + allowlist ──
    // A trade is ONLY placed when the user has explicitly STARTED the bot AND
    // CHOSEN this symbol. If they configured no symbols (empty allowlist) or the
    // signal's symbol is not in their selection, nothing is sent to their account.
    const configs: SymbolConfig[] = Array.isArray(run.symbol_configs) ? run.symbol_configs : [];
    if (configs.length === 0) { await finish("skipped_no_symbols"); return skip("skipped_no_symbols"); }
    const matched = configs.find((c) => canon(c.symbol) === canon(symbol));
    if (!matched) { await finish("skipped_symbol"); return skip("skipped_symbol"); }

    // Always trade the EXACT symbol the mentor chose when sending the signal
    // (e.g. "US30.std") — never swap it for the client's local config name.
    const orderSymbol = String(symbol || matched.symbol || "").trim();

    const localMax = Number(matched?.maxTrades) || 0;
    const signalCount = Number(signal.num_trades) || 0;
    const numTrades = Math.max(1, localMax, signalCount);
    const volume = Number(matched?.lotSize ?? signal.lot_size) || 0.01;
    const tp = signal.take_profit || "0";
    const sl = signal.stop_loss || "0";
    // The EA record is authoritative. Never trust an old/generic client value
    // such as "bot~TradeExpert" for a cloud-hosted trade comment.
    const comment = buildTradeComment(signal.ea_name) || run.comment || "TradeExpert";
    const direction = String(signal.direction || "BUY").toUpperCase();

    let placed = 0;
    let firstTicket = "";
    let lastError = "";
    for (let i = 0; i < numTrades; i++) {
      const res = await callCopyTrade({
        uuid,
        owner_user_id: userId,
        action: "open",
        symbol: orderSymbol,
        direction,
        volume,
        takeProfit: tp,
        stopLoss: sl,
        comment,
        master_ticket: signal.master_ticket || "",
        openPrice: signal.entry_price || undefined,
        request_key: `${signal.id}-${userId}-${i + 1}`,
      });
      if (res?.success) {
        placed++;
        const ticket = res.result?.ticket || res.result?.id;
        if (!firstTicket && ticket) firstTicket = String(ticket);
      } else {
        lastError = String(res?.error || "");
      }
      if (i < numTrades - 1) await new Promise((r) => setTimeout(r, 1500));
    }

    if (placed === 0) {
      // Nothing went through (terminal offline, etc.) — let the cron retry later.
      await allowRetry();
      console.error("dispatch open failed", { userId, orderSymbol, lastError });
      return { user_id: userId, status: "retry", requested: numTrades, placed: 0, symbol: orderSymbol, lot: volume };
    }

    if (firstTicket && signal.master_ticket) {
      await sb.from("client_trade_map").upsert(
        { user_id: userId, master_ticket: String(signal.master_ticket), client_ticket: firstTicket, symbol: orderSymbol },
        { onConflict: "user_id,master_ticket" },
      );
    }
    await sb.from("client_bot_runs")
      .update({ last_signal_at: new Date().toISOString() })
      .eq("id", run.id);
    await finish("done");
    return { user_id: userId, status: "done", requested: numTrades, placed, symbol: orderSymbol, lot: volume };
  };

  const processSignal = async (signal: any): Promise<DispatchResult[]> => {
    if (!signal?.ea_id) return [];
    const { data: ea } = await sb
      .from("expert_advisors")
      .select("name")
      .eq("id", signal.ea_id)
      .maybeSingle();
    const namedSignal = { ...signal, ea_name: ea?.name || signal.ea_name || "" };
    const { data: runs } = await sb
      .from("client_bot_runs")
      .select("id, user_id, ea_id, symbol_configs, comment, started_at")
      .eq("ea_id", signal.ea_id)
      .eq("status", "running");
    if (!runs || runs.length === 0) return [];
    return await Promise.all(runs.map((run) => dispatchToSubscriber(namedSignal, run)));
  };


  try {
    const body = await req.json().catch(() => ({}));

    // Mode A: a single freshly-inserted signal (DB trigger).
    if (body?.signal_id) {
      const { data: signal } = await sb
        .from("signals").select("*").eq("id", body.signal_id).maybeSingle();
      if (!signal) {
        return new Response(JSON.stringify({ ok: true, subscribers: 0 }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const results = await processSignal(signal);
      const placed = results.reduce((a, r) => a + r.placed, 0);
      const requested = results.reduce((a, r) => a + r.requested, 0);
      return new Response(JSON.stringify({
        ok: true,
        subscribers: results.length,
        placed,
        requested,
        results,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Mode B: cron safety net — recent signals that may have been missed.
    const sinceMs = Date.now() - 5 * 60 * 1000;
    const { data: signals } = await sb
      .from("signals")
      .select("*")
      .gte("created_at", new Date(sinceMs).toISOString())
      .not("ea_id", "is", null)
      .order("created_at", { ascending: true })
      .limit(200);

    let total = 0;
    for (const sig of signals || []) total += (await processSignal(sig)).length;


    return new Response(JSON.stringify({ ok: true, signals: signals?.length || 0, dispatched: total }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: any) {
    console.error("dispatch-signal error:", err);
    return new Response(JSON.stringify({ ok: false, error: String(err?.message || err) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
