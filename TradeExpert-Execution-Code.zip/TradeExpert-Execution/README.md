# TradeExpert signal execution and pop-out console code

Current source files from the TradeExpert project. This is a focused source package for an existing copy of the project, not a standalone HTML app or a complete repository.

## Files
- `src/components/ea-app/GlobalBotOverlay.tsx`: draggable portrait, floating icon, pop-out console, sequential typewriter writing, Start/Stop/Clear and Powered by TradeExpert footer.
- `src/components/ea-app/bot-console.css`: scoped console design, accent, warning and success styles.
- `src/lib/consoleMessage.ts`: readable message formatting, separate from trading logic.
- `src/contexts/BotConsoleContext.tsx`: receives matching bot signals through realtime and polling, opens the console and routes execution.
- `src/lib/clientBotRuns.ts`: registers/stops running bots for server execution.
- `src/lib/tradeNotifications.ts`: trade alerts.
- `src/components/SendSignalCard.tsx`: signal sender.
- `supabase/functions/ea-self-host/index.ts`: accepts self-host/sender signals and inserts them.
- `supabase/functions/dispatch-signal/index.ts`: server dispatch to eligible client accounts.
- `src/pages/ea-app/EALayout.tsx`: mounts the provider and console across app screens.

## How the app reacts
1. Start the activated bot and configure its symbols, lot size and trade count; connect the trading account.
2. The sender calls `supabase.functions.invoke("ea-self-host", { body: { ea_code, action: "open", symbol, direction, take_profit, stop_loss, entry_price, lot_size, num_trades, master_ticket } })`.
3. The self-host function inserts a signal for that EA. The existing database insert trigger invokes server dispatch.
4. The provider listens for new signals belonging to an activated bot while it is running. For an open signal, it opens the console and writes direction, symbol, levels, lot, trade count and sending status.
5. Execution confirmations are separate from receipt. A received/sending line is not proof that a trade opened.

## Integration
Copy these files to the matching paths in your existing TradeExpert GitHub repository. Keep the project's existing dependencies, UI components, settings/auth providers, generated backend client, trading-account utilities, assets, database tables, permissions and signal trigger. The included package.json describes project dependencies; it does not make this focused package independently runnable.

Server functions also depend on the existing copy-trade function and shared helpers in the full repository. Do not deploy this package alone as a replacement backend. Never put private API keys, trading passwords or service credentials in GitHub or browser code.

The current EA layout uses BotConsoleProvider as its signal listener. Do not also mount another independent auto-execution listener: duplicate execution paths can submit extra orders. This download intentionally excludes the legacy SignalAutoExecutor.

## Limitations
This export preserves existing code without changes. It has not been tested here with a real sender and live trading account. External trading-provider availability and account access are still required. Some current status/confirmation handling needs account-specific verification; do not interpret every console line or dispatch summary as a verified fill on this particular account. Modify/close receipt lines alone do not confirm completed changes.

The pop-out window is inside the website/app. Floating above other Android apps requires the separate native Android overlay package.
