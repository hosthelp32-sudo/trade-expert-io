(function () {
  if (window.__teBridge) return;
  window.__teBridge = true;

  // 0) The chart scanner's result: when it found a signal, send it to the app (the signal card shows the why)
  var _fetch = window.fetch;
  if (_fetch) {
    window.fetch = function (input, init) {
      var p = _fetch.apply(this, arguments);
      try {
        var url = typeof input === 'string' ? input : (input && input.url) || '';
        // the chart scanner's EXECUTE TRADE: when the trades are placed, tell the app (the console shows them)
        if (url.indexOf('/functions/v1/copy-trade') > -1 && init && typeof init.body === 'string') {
          var sent = null;
          try { sent = JSON.parse(init.body); } catch (e) {}
          if (sent && sent.action === 'open' && sent.source === 'ai_scanner') {
            p.then(function (res) {
              return res.clone().json();
            }).then(function (j) {
              var placed = Number(j && j.result && j.result.placed) || 0;
              if (!j || j.success === false || placed <= 0) return;
              try {
                AndroidNotify.tradeExecuted(JSON.stringify({
                  symbol: sent.symbol || '', direction: String(sent.direction || '').toUpperCase(),
                  stopLoss: sent.stopLoss, takeProfit: sent.takeProfit, placed: placed
                }));
              } catch (e) {}
            }).catch(function () {});
          }
        }
      } catch (e) {}
      return p;
    };
  }

  // 1) The web app's bot switch: the page saves "1" (ON) or "0" (OFF) in ea_bot_running.
  var lastOn = null;
  function checkBot() {
    var on = false;
    try { on = localStorage.getItem('ea_bot_running') === '1'; } catch (e) {}
    if (on === lastOn) return;
    lastOn = on;
    try { AndroidNotify.botState(on); } catch (e) {}
  }

  // 2) The web console: its name, picture and lines (the same lines and order as on the page).
  var lastConsole = '', lastOpenTry = 0;
  function botInfo() {
    try {
      var bots = JSON.parse(localStorage.getItem('ea_bots') || '[]');
      var b = bots[parseInt(localStorage.getItem('ea_active_bot') || '0', 10) || 0] || {};
      var ea = b.ea || {};
      var img = ea.image_url || ea.image || ea.logo_url || ea.picture || ea.img || b.image_url || b.img || b.picture || '';
      return { name: String(ea.name || b.name || 'BOT'), img: String(img || '') };
    } catch (e) { return { name: 'BOT', img: '' }; }
  }
  function pageImage() {
    var ims = document.querySelectorAll('img.object-cover');
    for (var i = 0; i < ims.length; i++) {
      var src = String(ims[i].src || '');
      if (src && src.indexOf('data:') !== 0 && ims[i].width > 120) return src;
    }
    return '';
  }
  function reportConsole() {
    try {
      var info = botInfo();
      if (!info.img) info.img = pageImage();
      // the page's own console is not used: the app's card writes its own lines
      var root = null;
      var lines = [];
      var feed = root ? root.querySelector('.min-w-0.space-y-1.px-3\\.5') : null;
      if (feed) {
        var kids = feed.children;
        for (var i = 0; i < kids.length; i++) {
          var el = kids[i];
          var cls = String(el.className || '');
          if (cls.indexOf('my-2 flex items-center gap-2') > -1) {
            // separator line, e.g. "SIGNAL RECEIVED · NIGHT FILLPER"
            var label = String(el.textContent || '').replace(/\s+/g, ' ').trim();
            if (label) lines.push({ t: label, sep: true });
            continue;
          }
          if (cls.indexOf('grid') < 0) continue;     // only the console line rows
          var raw = String(el.textContent || '');
          var bare = raw.charAt(0) !== '>';           // bare lines have no ">" (like "Connected")
          var t = raw.replace(/^[>\s]+/, '').trim();
          if (t) lines.push({ t: t, b: bare });
        }
        if (lines.length > 40) lines = lines.slice(-40);
      }
      // the app's colour (the card and the bubble follow it), and its colour speed
      var accent = '', secondary = '', speed = 0.3;
      try {
        accent = localStorage.getItem('ea_accent_color') || '';
        var sec = localStorage.getItem('ea_accent_secondary');
        secondary = (sec && sec !== 'null') ? sec : '';
        speed = parseFloat(localStorage.getItem('ea_color_speed')) || 0.3;
      } catch (e) {}
      var data = JSON.stringify({ name: info.name, img: info.img, running: lastOn === true, lines: lines,
                                  accent: accent, secondary: secondary, speed: speed,
                                  account: accountOn === true });
      if (data !== lastConsole) {
        // sent as the page writes it: the card types the same letters, one by one
        lastConsole = data;
        AndroidNotify.consoleData(data);
      }
    } catch (e) {}
  }


  // 3) New signals: a notification for each signal created after the page opened
  var REST = 'https://zueqlxkqwigjlpgazeiz.supabase.co/rest/v1/';
  var ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp1ZXFseGtxd2lnamxwZ2F6ZWl6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI5NTU1MTgsImV4cCI6MjA4ODUzMTUxOH0.ZH9u7B90bndQVe_VT5cxmU1XCHL-yqfiBhtHn0T3ZfE';
  var seen = {}, since = new Date().toISOString(), firstRun = true;
  var accountOn = null;
  function session() {
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (k && k.indexOf('auth-token') > -1) {
          var o = JSON.parse(localStorage.getItem(k));
          var t = o.access_token || (o.currentSession && o.currentSession.access_token);
          var u = (o.user && o.user.id) || (o.currentSession && o.currentSession.user && o.currentSession.user.id);
          if (t && u) return { token: t, uid: u };
        }
      }
    } catch (e) {}
    return null;
  }
  function activeEa() {
    try {
      var bots = JSON.parse(localStorage.getItem('ea_bots') || '[]');
      var b = bots[parseInt(localStorage.getItem('ea_active_bot') || '0', 10) || 0];
      return (b && (b.ea_id || (b.ea && b.ea.id))) || '';
    } catch (e) { return ''; }
  }
  function pollSignals() {
    var s = session(), ea = activeEa();
    if (!s || !ea) return;
    fetch(REST + 'signals?select=id,symbol,direction,action,lot_size,entry_price,created_at&ea_id=eq.' + ea +
          '&created_at=gt.' + encodeURIComponent(since) + '&order=created_at.asc&limit=10',
          { headers: { apikey: ANON, Authorization: 'Bearer ' + s.token } })
      .then(function (r) { return r.ok ? r.json() : []; })
      .then(function (rows) {
        if (!Array.isArray(rows)) return;
        rows.forEach(function (r) {
          if (seen[r.id]) return;
          seen[r.id] = 1;
          if (r.created_at && r.created_at > since) since = r.created_at;
          if (firstRun) return;
          var title = ((r.action || 'SIGNAL') + ' ' + (r.symbol || '') + ' ' + (r.direction || '')).trim();
          var body = 'Lot ' + (r.lot_size || '-') + (r.entry_price ? ' \u00b7 @ ' + r.entry_price : '');
          try { AndroidNotify.show(title, body); } catch (e) {}
        });
        firstRun = false;
      })
      .catch(function () {});
  }
  setInterval(pollSignals, 4000);
  setTimeout(pollSignals, 1500);

  // 4) Whether the MetaTrader account is connected (the page's own "Account connected" state)
  function checkAccount() {
    var s = session();
    if (!s) return;
    fetch(REST + 'mt_credentials?select=is_connected&user_id=eq.' + s.uid,
          { headers: { apikey: ANON, Authorization: 'Bearer ' + s.token } })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (rows) {
        if (!Array.isArray(rows)) return;
        // the web app counts an account as connected unless its flag is false (a missing flag = connected)
        accountOn = rows.some(function (r) { return r && r.is_connected !== false; });
      })
      .catch(function () {});
  }
  setInterval(checkAccount, 10000);
  setTimeout(checkAccount, 2000);

  setInterval(checkBot, 1000);
  setInterval(reportConsole, 300);
  checkBot();
})();
