# Closed-app signals (Firebase push)

1. Firebase console: create a project, add an Android app with package `com.tradeexpert.app`,
   download `google-services.json` and put it in `app/` (do not commit it to a public repo).
2. Build as usual. Without the file the app still builds; the push part just stays off.
3. Platform side: send DATA messages with priority "high" to the phone's FCM token, with keys
   symbol, direction, stopLoss, takeProfit. Never put the Firebase service account key in GitHub
   or in chat; store it only in the platform's secret store.
4. The phone's token is saved on the phone (SharedPreferences "fcm"). It must also reach the
   platform, which needs an endpoint or table to store it. That part is not built yet.
5. Limits: a force-stopped app receives nothing until it is opened again. The pop-out closes
   after its signal is done; the bubble only returns if the bot is switched on. The trade itself
   is not placed while the app is closed.
