package com.tradeexpert.app;

import android.content.Intent;
import android.os.Build;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONObject;

import java.util.Map;

/**
 * Mentor signals pushed while the app is closed. The platform sends a DATA message (with
 * priority high); it opens the bubble service, which shows the signal in the pop-out.
 */
public class TradeExpertFcmService extends FirebaseMessagingService {

    @Override
    public void onNewToken(String token) {
        // kept on the phone; the platform needs this token to address the phone
        getSharedPreferences("fcm", MODE_PRIVATE).edit().putString("token", token).apply();
    }

    @Override
    public void onMessageReceived(RemoteMessage message) {
        Map<String, String> d = message.getData();
        if (d == null || d.isEmpty()) return;
        try {
            JSONObject sig = new JSONObject();
            sig.put("phase", "received");
            sig.put("symbol", d.containsKey("symbol") ? d.get("symbol") : "");
            sig.put("direction", d.containsKey("direction") ? d.get("direction").toUpperCase() : "");
            sig.put("stopLoss", d.containsKey("stopLoss") ? d.get("stopLoss") : JSONObject.NULL);
            sig.put("takeProfit", d.containsKey("takeProfit") ? d.get("takeProfit") : JSONObject.NULL);
            sig.put("why", "");

            Intent i = new Intent(this, BubbleService.class);
            i.putExtra("signal", sig.toString());
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } catch (Exception ignored) {
        }
    }
}
