package com.tradeexpert.app;

import android.app.Activity;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.FrameLayout;
import android.webkit.WebChromeClient;

/**
 * Trade Expert on screen. The page itself lives in the background service (PageHost), so the bot,
 * the console and the signals keep running when the app is closed.
 */
public class MainActivity extends Activity {

    /** The open screen (the page's file chooser opens from here). */
    static MainActivity current;
    private FrameLayout container;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        container = new FrameLayout(this);
        container.setBackgroundColor(Color.parseColor("#FF0A0D14"));
        setContentView(container);

        // the floating display over other apps: ask for permission once, then start the service
        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }
        startForegroundService(new Intent(this, BubbleService.class));

        // the camera button of the scanner
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 42);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PageHost.REQ_FILE && PageHost.pendingFiles != null) {
            android.net.Uri[] picked = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            PageHost.pendingFiles.onReceiveValue(picked);
            PageHost.pendingFiles = null;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        current = this;
        if (PageHost.web == null || PageHost.web.getParent() != container) {
            PageHost.attach(PageHost.get(this), container);
        }
        PageHost.setVisible(true);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (current == this) current = null;
        PageHost.setVisible(false);
        // the page keeps running in the service; only the screen lets go of it
        if (PageHost.web != null) {
            PageHost.detach(PageHost.web);
            // keep the page's scripts and timers running in the background: a trade sent from the
            // chart scanner still reports to the pop-out console after the app is left
            PageHost.web.onResume();
            PageHost.web.resumeTimers();
            PageHost.keepOnWindow(this);
        }
    }

    @Override
    public void onBackPressed() {
        if (PageHost.web != null && PageHost.web.canGoBack()) {
            PageHost.web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
